package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.StatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7706;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * EMC Tablet hub.
 *   Top row: Buy / Sell / XP Shop / Services (one big button each).
 *   Buy: every item that has an EMC price. Pick a category or type in the search box, click an item,
 *        press Buy 1 / 16 / 64 / Max. Buttons you can't afford are greyed out. Server validates everything.
 */
public class TabletScreen extends class_437 {
    // Creative-inventory layout: icon tabs on top, 9 x 5 slot grid with a scrollbar, search box, buy panel on the right.
    private static final int W = 340, H = 218, COLS = 9, ROWS = 5, PER = COLS * ROWS;
    private static final int GRID_Y = 96, RX = 194, MAX_TABS = 12, TAB_W = 27, SB_W = 8;
    private static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA;
    private static final int[] PAL = {Fx.CYAN, Fx.GREEN, Fx.GOLD, Fx.PURPLE, 0xFF7070, 0x70B0FF, 0xFFA040, 0x80E0C0};
    private static final int[] AMOUNTS = {1, 16, 64};

    private record Entry(String key, class_1799 stack, String name, long value, int color) {}

    private long emc;
    private final List<Entry> buyAll = new ArrayList<>();                 // every priced item, creative order
    private final List<List<Entry>> byGroup = new ArrayList<>();          // one list per creative tab, creative order
    private final List<class_1761> groups = new ArrayList<>();            // the creative tabs shown as icon tabs
    private final List<Entry> filtered = new ArrayList<>();
    private final List<GlowButton> cells = new ArrayList<>();
    private final List<GlowButton> tabs = new ArrayList<>();
    private final GlowButton[] buyBtn = new GlowButton[3];
    private GlowButton maxBtn;
    private class_342 search;
    private String query = "";
    private Entry sel;
    private int scroll = 0, tab = 0, left, top;

    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;
    private final float openT = Fx.t();
    private float pageT = Fx.t();

    public TabletScreen(StatePayload s) {
        super(class_2561.method_43470("EMC Tablet"));
        loadItems();
        emc = s.emc();
        ClientEmc.balance = emc;
    }

    /** Every item with a price, laid out like the creative inventory: same tabs, same order. */
    private void loadItems() {
        buyAll.clear(); byGroup.clear(); groups.clear();
        Map<class_1792, Entry> byItem = new HashMap<>();
        for (Map.Entry<class_2960, Long> e : ClientEmc.all().entrySet()) {
            class_2960 id = e.getKey();
            if (e.getValue() <= 0 || !class_7923.field_41178.method_10250(id)) continue;
            class_1792 it = class_7923.field_41178.method_63535(id);
            class_1799 st = new class_1799(it);
            if (st.method_7960()) continue;
            byItem.put(it, new Entry(id.toString(), st, it.method_63680().getString(), com.uemc.emc.Fees.buyUnit(e.getValue()), Fx.CYAN));
        }
        java.util.Set<class_1792> used = new java.util.HashSet<>();
        try {
            var mc = class_310.method_1551();
            if (mc.field_1724 != null) {
                var h = mc.field_1724.field_3944;
                class_7706.method_47330(h.method_45735(), false, h.method_29091());   // fill the creative tabs, same as opening the creative screen
                int g = 0;
                for (class_1761 grp : class_7706.method_47335()) {
                    if (groups.size() >= MAX_TABS - 1) break;
                    List<Entry> list = new ArrayList<>();
                    for (class_1799 st : grp.method_47313()) {
                        Entry en = byItem.get(st.method_7909());
                        if (en == null || list.stream().anyMatch(x -> x.key.equals(en.key))) continue;
                        Entry colored = new Entry(en.key, en.stack, en.name, en.value, PAL[g % PAL.length]);
                        list.add(colored);
                        if (used.add(st.method_7909())) buyAll.add(colored);
                    }
                    if (!list.isEmpty()) { groups.add(grp); byGroup.add(list); g++; }
                }
            }
        } catch (Throwable t) {
            com.uemc.UniversalEmc.LOG.warn("Could not read creative tabs, listing by name", t);
        }
        // anything the creative tabs do not show goes at the end of "All", A-Z
        List<Entry> rest = new ArrayList<>();
        for (Map.Entry<class_1792, Entry> e : byItem.entrySet()) if (!used.contains(e.getKey())) rest.add(e.getValue());
        rest.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        buyAll.addAll(rest);
    }

    /** New balance from the server (after every buy). */
    public void update(StatePayload s) {
        emc = s.emc();
        ClientEmc.balance = emc;
        syncBuy();
    }

    /** What the Sell and XP screens do when you press their Back button: reopen the tablet. */
    private static void backToTablet() {
        class_310.method_1551().method_1507(null);
        ClientPlayNetworking.send(new ActionPayload(11, "", 0));
    }

    private GlowButton nav(String label, String tip, int i, int color, Runnable r) {
        GlowButton b = GlowButton.of(label, left + 8 + i * 66, top + 22, 62, 20, x -> r.run());
        b.accent = color;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        return b;
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - W) / 2;
        top = (field_22790 - H) / 2;

        GlowButton buy = nav("Buy", "Buy any item that has an EMC price", 0, Fx.CYAN, () -> {});
        buy.selected = true;
        nav("Sell", "Sell items from your inventory (or everything in one click)", 1, Fx.GOLD,
                () -> class_310.method_1551().method_1507(new SellScreen(TabletScreen::backToTablet)));
        nav("XP Shop", "Buy or sell XP levels", 2, Fx.GREEN,
                () -> class_310.method_1551().method_1507(new XpShopScreen(TabletScreen::backToTablet)));
        nav("Services", "Enchanting table, repair, teleport, time and tool upgrades", 3, Fx.PURPLE,
                () -> class_310.method_1551().method_1507(new ServicesScreen()));

        tabs.clear();
        for (int i = 0; i <= groups.size(); i++) {
            final int idx = i;
            GlowButton b = GlowButton.of("", left + 8 + i * TAB_W, top + 46, TAB_W - 1, 24, x -> { tab = idx; scroll = 0; pageT = Fx.t(); refilter(); });
            b.accent = i == 0 ? Fx.CYAN : PAL[(i - 1) % PAL.length];
            String nm = i == 0 ? "All items" : groups.get(i - 1).method_7737().getString();
            b.method_47400(class_7919.method_47407(class_2561.method_43470(nm)));
            tabs.add(b);
            method_37063(b);
        }

        search = new class_342(field_22793, left + 8, top + 74, COLS * 18, 16, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; scroll = 0; pageT = Fx.t(); refilter(); });
        method_37063(search);

        cells.clear();
        for (int i = 0; i < PER; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % COLS) * 18, top + GRID_Y + (i / COLS) * 18, x -> pick(idx));
            cells.add(b);
            method_37063(b);
        }

        int py = top + GRID_Y + ROWS * 18 + 6;
        method_37063(GlowButton.of("^", left + 8, py, 24, 18, b -> scrollBy(-1)));
        method_37063(GlowButton.of("v", left + 36, py, 24, 18, b -> scrollBy(1)));

        int bx = left + RX;
        for (int i = 0; i < 3; i++) {
            final int n = AMOUNTS[i];
            buyBtn[i] = GlowButton.of("", bx + (i % 2) * 72, top + 120 + (i / 2) * 26, 68, 22, b -> buyNow(n));
            method_37063(buyBtn[i]);
        }
        maxBtn = GlowButton.of("", bx + 72, top + 146, 68, 22, b -> {
            if (sel != null) buyNow(maxAmount());
        });
        method_37063(maxBtn);

        GlowButton conv = GlowButton.of("Sell offhand item", bx, top + 176, 140, 20, b -> ClientPlayNetworking.send(new ActionPayload(2, "", 1)));
        conv.method_47400(class_7919.method_47407(class_2561.method_43470("Turns the item in your offhand into EMC")));
        conv.accent = Fx.GOLD;
        method_37063(conv);

        refilter();
    }

    private int rowsTotal() { return Math.max(1, (filtered.size() + COLS - 1) / COLS); }
    private int maxScroll() { return Math.max(0, rowsTotal() - ROWS); }

    private void scrollBy(int d) {
        int n = Math.max(0, Math.min(maxScroll(), scroll + d));
        if (n != scroll) { scroll = n; refilter(); }
    }

    private void refilter() {
        filtered.clear();
        String q = query.trim().toLowerCase();
        List<Entry> base = tab == 0 || tab - 1 >= byGroup.size() ? buyAll : byGroup.get(tab - 1);
        for (Entry e : base) {
            if (q.isEmpty() || e.name.toLowerCase().contains(q) || e.key.contains(q)) filtered.add(e);
        }
        if (scroll > maxScroll()) scroll = maxScroll();
        for (int i = 0; i < cells.size(); i++) {
            GlowButton c = cells.get(i);
            int idx = scroll * COLS + i;
            c.field_22763 = idx < filtered.size();
            if (idx < filtered.size()) {
                Entry e = filtered.get(idx);
                c.accent = e.color;
                c.method_47400(class_7919.method_47407(class_2561.method_43470(e.name + "\n" + Fx.num(e.value) + " EMC")));
            } else c.method_47400(null);
        }
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).selected = i == tab;
        syncBuy();
    }

    /** Mouse wheel scrolls the grid one row at a time, like the creative inventory. */
    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        if (v != 0) { scrollBy(v > 0 ? -1 : 1); return true; }
        return super.method_25401(mx, my, h, v);
    }

    private void pick(int idx) {
        int i = scroll * COLS + idx;
        if (i < filtered.size()) { sel = filtered.get(i); syncBuy(); }
    }

    private int maxAmount() {
        if (sel == null || sel.value <= 0) return 0;
        return (int) Math.min(2304, emc / sel.value);
    }

    private void buyNow(int n) {
        if (sel != null && n > 0) ClientPlayNetworking.send(new ActionPayload(1, sel.key, n));
    }

    /** Buy buttons: say what they cost, grey out what you can't afford. */
    private void syncBuy() {
        if (maxBtn == null) return;
        for (int i = 0; i < 3; i++) {
            int n = AMOUNTS[i];
            GlowButton b = buyBtn[i];
            b.method_25355(class_2561.method_43470("Buy " + n));
            if (sel == null) {
                b.field_22763 = false;
                b.accent = Fx.GREEN;
                b.method_47400(class_7919.method_47407(class_2561.method_43470("Click an item first")));
                continue;
            }
            long cost = sel.value * n;
            boolean ok = emc >= cost;
            b.field_22763 = ok;
            b.accent = ok ? Fx.GREEN : Fx.RED;
            b.method_47400(class_7919.method_47407(class_2561.method_43470(ok
                    ? "Buy " + n + " for " + Fx.num(cost) + " EMC"
                    : "Need " + Fx.num(cost) + " EMC")));
        }
        int m = maxAmount();
        maxBtn.method_25355(class_2561.method_43470(m > 0 ? "Max x" + m : "Max"));
        maxBtn.field_22763 = m > 0;
        maxBtn.accent = Fx.GOLD;
        maxBtn.method_47400(sel == null ? class_7919.method_47407(class_2561.method_43470("Click an item first"))
                : class_7919.method_47407(class_2561.method_43470(m > 0
                        ? "Buy " + m + " for " + Fx.num(sel.value * m) + " EMC (everything you can afford)"
                        : "You can't afford one")));
    }

    private void txt(class_332 c, String s, int x, int y, int color) {
        c.method_51439(field_22793, class_2561.method_43470(s), x, y, color, true);
    }

    /** Do not pause the (single-player) server while this screen is open: a paused server does not sync your inventory, so sold items would stay on screen. */
    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, Fx.CYAN, openT);
        ctx.method_25296(left + RX - 6, top + 74, left + RX - 5, top + H - 8, Fx.argb(0, Fx.CYAN), Fx.argb(200, Fx.CYAN));
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        Fx.title(ctx, field_22793, "EMC TABLET", left + 8, top + 8, Fx.CYAN);

        if (lastBal != Long.MIN_VALUE && emc != lastBal) {
            Fx.pop(emc - lastBal);
            if (sel != null) Fx.burst(left + RX + 14, top + 86, emc < lastBal ? Fx.GREEN : Fx.GOLD);
        }
        lastBal = emc;
        String bal = "EMC " + Fx.num(counter.get(emc));
        int bxr = left + W - 8 - field_22793.method_1727(bal);
        Fx.orb(ctx, bxr - 9, top + 12, Fx.CYAN);
        Fx.glowText(ctx, field_22793, bal, bxr, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, field_22793, left + W - 8, top + 18);

        // creative-style icon tabs
        for (int i = 0; i < tabs.size(); i++) {
            GlowButton t = tabs.get(i);
            class_1799 icon = i == 0 ? new class_1799(class_7923.field_41178.method_63535(class_2960.method_60654("minecraft:chest"))) : groups.get(i - 1).method_7747();
            if (!icon.method_7960()) Fx.item(ctx, icon, t.method_46426() + 5, t.method_46427() + 4, t.method_49606(), i == tab, 1f, t.accent);
        }

        for (int i = 0; i < cells.size(); i++) {
            int idx = scroll * COLS + i;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + GRID_Y + (i / COLS) * 18 + 1;
            float appear = Fx.ease(Fx.since(pageT) * 4f - ((i % COLS) + (i / COLS)) * 0.08f);
            Fx.item(ctx, e.stack, x, y, cells.get(i).method_49606(), e == sel, appear, e.color);
        }

        // scrollbar
        int sbx = left + 8 + COLS * 18 + 3, sby = top + GRID_Y, sbh = ROWS * 18;
        ctx.method_25294(sbx, sby, sbx + SB_W, sby + sbh, 0xFF05090D);
        ctx.method_25294(sbx + 1, sby + 1, sbx + SB_W - 1, sby + sbh - 1, 0xFF111A22);
        int ms = maxScroll();
        int hh = ms == 0 ? sbh - 2 : Math.max(14, (sbh - 2) * ROWS / rowsTotal());
        int hy = ms == 0 ? sby + 1 : sby + 1 + (sbh - 2 - hh) * scroll / ms;
        int hc = tab == 0 ? Fx.CYAN : PAL[(tab - 1) % PAL.length];
        ctx.method_25294(sbx + 1, hy, sbx + SB_W - 1, hy + hh, Fx.argb(ms == 0 ? 80 : 230, hc));

        int rows = rowsTotal();
        txt(ctx, "Row " + (Math.min(scroll + 1, rows)) + "/" + rows + "  -  " + filtered.size() + " items", left + 66, top + GRID_Y + ROWS * 18 + 11, GREY);
        if (filtered.isEmpty()) txt(ctx, "No items", left + 10, top + GRID_Y + 4, GREY);

        int bx = left + RX;
        if (sel == null) {
            txt(ctx, "Click an item to buy", bx, top + 80, GREY);
            txt(ctx, "Hover it to see the price", bx, top + 92, GREY);
        } else {
            Fx.showcase(ctx, sel.stack, bx + 14, top + 86, 1.6f, sel.color);
            txt(ctx, field_22793.method_27523(sel.name, 104), bx + 32, top + 74, WHITE);
            Fx.glowText(ctx, field_22793, Fx.num(sel.value) + " EMC", bx + 32, top + 88, Fx.CYAN);
            int can = maxAmount();
            txt(ctx, can > 0 ? "You can buy " + can : "Not enough EMC", bx + 32, top + 102, can > 0 ? 0xFF7FFFB0 : 0xFFFF7070);
        }
        Fx.drawBursts(ctx);
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

# Universal EMC (Fabric, Minecraft 1.21.11)

## Build
Needs JDK 21 + internet (Gradle wrapper included).

    ./build.sh        (Windows: build.bat)

Jar: `dist/universal-emc-0.2.0.jar`

## GitHub (builds the jar for you, no JDK needed)

    ./github.sh yourname/universal-emc            (private; add --public for public)

Then open the repo > Actions (build log) > Releases (download the jar).

## Install
Fabric Loader >= 0.18.0 + Fabric API 0.141.1+1.21.11 or newer in `mods/`, then drop the jar in.

## Items
- EMC Scanner, EMC Tablet (recipes in-game). The tablet can't be sold. Buy any item that has an EMC price: no scanning needed.
- Basic / Advanced / Ultimate Energy Converter (right-click with items)
- Enchanting Table (Tablet > Upgrades, or the Converter menu): pick any enchant, level 1-10 (X), pay in EMC. No other workstations.
- Upgrades (Tablet > Services > Upgrades): tools (Hammer, Vein Miner, Lumberjack, Auto-Repair) and ON/OFF perks (Haste, Speed, Jump, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger, Magnet, Strength, Slow Fall, Dolphin's Grace, Luck, Health Boost, Flight).
- Time & Weather (Tablet > Services > Time): skip the clock, run time x2 / x5 / x10 / x20 (you pay per second, crops and trees grow faster while it runs), pick clear / rain / storm.
- EMC HUD: balance on screen. `/emchud` toggles, `/emchud topright` moves it.

## Notes
Sources use intermediary names; build.gradle maps them via `-PmapMode=layered` (default) or `intermediary` (fallback).
If one name fails to resolve at first build, fix that one line.

package com.uemc.item;

import com.uemc.emc.EmcLogic;
import com.uemc.emc.EmcRegistry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import com.uemc.ModSounds;

/** Right-click: scans offhand item. Right-click block: scans that block. Both unlock the item. */
public class ScannerItem extends class_1792 {
    public ScannerItem(class_1793 settings) { super(settings); }

    private static void report(class_1657 p, class_1792 item, int count) {
        long v = EmcRegistry.get(item);
        if (v <= 0) {
            p.method_7353(class_2561.method_43470("[Scanner] " + class_7923.field_41178.method_10221(item) + ": no EMC value"), false);
            return;
        }
        boolean fresh = EmcLogic.discover(p, item);
        p.method_7353(class_2561.method_43470("[Scanner] " + class_7923.field_41178.method_10221(item) + ": " + v + " EMC"
                + (count > 1 ? " (x" + count + " = " + (v * count) + ")" : "")
                + (fresh ? " - NEW DISCOVERY" : "")), false);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        if (world.method_8608()) return class_1269.field_5812;
        class_1799 off = player.method_6079();
        if (off.method_7960()) {
            player.method_7353(class_2561.method_43470("[Scanner] Hold an item in offhand, or click a block."), false);
            return class_1269.field_5814;
        }
        report(player, off.method_7909(), off.method_7947());
        world.method_8396(null, player.method_24515(), ModSounds.SCANNER_SCAN, class_3419.field_15248, 0.6f, 1.2f);
        return class_1269.field_5812;
    }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        class_1937 w = ctx.method_8045();
        if (w.method_8608()) return class_1269.field_5812;
        class_1657 p = ctx.method_8036();
        if (p == null) return class_1269.field_5811;
        class_1792 item = w.method_8320(ctx.method_8037()).method_26204().method_8389();
        report(p, item, 1);
        if (w instanceof class_3218 sw) {
            class_2338 bp = ctx.method_8037();
            sw.method_8396(null, bp, ModSounds.SCANNER_SCAN, class_3419.field_15248, 0.6f, 1.0f);
            sw.method_65096(class_2398.field_29644, bp.method_10263() + 0.5, bp.method_10264() + 1.05, bp.method_10260() + 0.5, 14, 0.4, 0.05, 0.4, 0.05);
        }
        return class_1269.field_5812;
    }
}

package com.uemc.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Client copy of all EMC values (synced from server on join). */
public final class ClientEmc {
    private static volatile Map<class_2960, Long> VALUES = new HashMap<>();

    public static volatile long balance = 0;

    private ClientEmc() {}

    public static void set(Map<class_2960, Long> m) { VALUES = m; }
    public static void clear() { VALUES = new HashMap<>(); }

    /** Every item that has an EMC price (what the tablet's Buy list shows). */
    public static Map<class_2960, Long> all() { return VALUES; }

    /** Value of ONE item (damaged tools scale by durability, same as server). */
    public static long unit(class_1799 s) {
        if (s.method_7960()) return 0;
        long base = VALUES.getOrDefault(class_7923.field_41178.method_10221(s.method_7909()), 0L);
        if (base <= 0) return 0;
        if (s.method_7963() && s.method_7936() > 0) {
            long left = Math.max(0, s.method_7936() - s.method_7919());
            base = base * left / s.method_7936();
        }
        return base;
    }
}

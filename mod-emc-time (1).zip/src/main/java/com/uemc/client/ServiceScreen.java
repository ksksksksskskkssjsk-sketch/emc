package com.uemc.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** Base for tablet upgrade screens: animated panel, title wave, rolling EMC counter, +/- popups, fade-in. */
public abstract class ServiceScreen extends class_437 {
    protected static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA, CYAN = 0xFF00FFDD;
    /** Panel size. Subclasses may widen/heighten it in their constructor. */
    protected int W = 250, H = 190, left, top;
    protected int accent = Fx.CYAN;
    protected final float openT = Fx.t();
    private final String heading;
    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;

    protected ServiceScreen(String heading) {
        super(class_2561.method_43470(heading));
        this.heading = heading;
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - W) / 2;
        top = (field_22790 - H) / 2;
    }

    protected void txt(class_332 c, String s, int x, int y, int color) {
        c.method_51439(field_22793, class_2561.method_43470(s), x, y, color, true);
    }

    /** Do not pause the (single-player) server while this screen is open: a paused server does not sync your inventory, so sold items would stay on screen. */
    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, accent);
    }

    /** Subclasses draw their own content here (after widgets, before header/fade). */
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        drawContent(ctx, mx, my, delta);
        Fx.title(ctx, field_22793, heading, left + 8, top + 8, accent);
        long target = ClientEmc.balance;
        if (lastBal != Long.MIN_VALUE && target != lastBal) Fx.pop(target - lastBal);
        lastBal = target;
        String bal = "EMC " + Fx.num(counter.get(target));
        int bx = left + W - 8 - field_22793.method_1727(bal);
        Fx.orb(ctx, bx - 9, top + 12, accent);
        Fx.glowText(ctx, field_22793, bal, bx, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, field_22793, left + W - 8, top + 20);
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

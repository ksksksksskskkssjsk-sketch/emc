package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/**
 * Time & weather (Overworld).
 *   SKIP TO / SKIP FORWARD: jump the clock (FAST = watch the sky race past, INSTANT = jump).
 *   TIME SPEED: time keeps running x2 / x5 / x10 / x20 until you press 1x. You pay per real second.
 *               Crops, saplings and trees grow faster while it runs. The server does all the work.
 *   WEATHER: clear / rain / storm.
 */
public class TimeScreen extends ServiceScreen {
    private static boolean fast = true;   // remembered while the game runs
    /** Running time speed (index into Fees.SPEED_X), sent by the server. */
    static volatile int speed = 0;

    private static final int CL = 10, CR = 182, CW = 162;
    private static final int[] WX_COL = {Fx.GOLD, Fx.CYAN, Fx.PURPLE};

    private final Runnable back;
    private final GlowButton[] abs = new GlowButton[4], rel = new GlowButton[4], spd = new GlowButton[5], wx = new GlowButton[3];
    private GlowButton skipBtn;
    private long lastBal = Long.MIN_VALUE, lastTime = -1;
    private int lastSpeed = -1, lastWx = -1;
    private boolean synced = false;

    public TimeScreen(Runnable back) {
        super("TIME & WEATHER");
        this.back = back;
        W = 354;
        H = 242;
        accent = Fx.CYAN;
    }

    private long now() {
        class_310 mc = class_310.method_1551();
        return mc.field_1687 == null ? 0 : mc.field_1687.method_8532();
    }

    private static boolean overworld() {
        class_310 mc = class_310.method_1551();
        return mc.field_1687 != null && mc.field_1687.method_27983().method_29177().toString().equals("minecraft:overworld");
    }

    /** 0 clear, 1 rain, 2 storm (as the client sees the sky). */
    private static int weatherNow() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return 0;
        return mc.field_1687.method_8546() ? 2 : mc.field_1687.method_8419() ? 1 : 0;
    }

    private static int dayTick(long t) { return (int) (((t % 24000) + 24000) % 24000); }

    private static String clock(long t) {
        int d = dayTick(t);
        return String.format("%02d:%02d", (d / 1000 + 6) % 24, (d % 1000) * 60 / 1000);
    }

    private static String phase(long t) {
        int d = dayTick(t);
        return d < 12000 ? "Day" : d < 13000 ? "Sunset" : d < 23000 ? "Night" : "Sunrise";
    }

    private static void tip(GlowButton b, String s) { b.method_47400(class_7919.method_47407(class_2561.method_43470(s))); }

    private static void send(int action, int n) { ClientPlayNetworking.send(new ActionPayload(action, "", n)); }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; send(18, 0); }   // ask which speed is running
        for (int i = 0; i < 4; i++) {
            final int k = i;
            abs[i] = GlowButton.of("", left + CL, top + 84 + i * 21, CW, 19,
                    b -> ClientPlayNetworking.send(new ActionPayload(15, "abs" + (fast ? ":fast" : ":instant"), Fees.TIME_TARGETS[k])));
            abs[i].accent = Fx.CYAN;
            method_37063(abs[i]);
            rel[i] = GlowButton.of("", left + CR, top + 84 + i * 21, CW, 19,
                    b -> ClientPlayNetworking.send(new ActionPayload(15, "rel" + (fast ? ":fast" : ":instant"), Fees.TIME_HOURS[k] * 1000)));
            rel[i].accent = Fx.GOLD;
            method_37063(rel[i]);
        }
        for (int i = 0; i < 5; i++) {
            final int k = i;
            spd[i] = GlowButton.of("", left + CL + i * 33, top + 182, 30, 19, b -> send(16, k));
            method_37063(spd[i]);
        }
        for (int i = 0; i < 3; i++) {
            final int k = i;
            wx[i] = GlowButton.of("", left + CR + i * 55, top + 182, 52, 19, b -> send(17, k));
            wx[i].accent = WX_COL[i];
            method_37063(wx[i]);
        }
        skipBtn = GlowButton.of("", left + CL, top + 216, CW, 18, b -> { fast = !fast; refresh(); });
        skipBtn.accent = Fx.PURPLE;
        method_37063(skipBtn);
        GlowButton close = GlowButton.of("Back", left + CR, top + 216, CW, 18, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);
        refresh();
    }

    private void style(GlowButton b, String name, long delta, boolean ow) {
        long fee = Fees.timeCost(delta);
        if (!ow) { b.method_25355(class_2561.method_43470(name)); b.field_22763 = false; tip(b, "Time only moves in the Overworld"); return; }
        if (delta <= 0) { b.method_25355(class_2561.method_43470(name + "  (now)")); b.field_22763 = false; return; }
        boolean ok = fee <= ClientEmc.balance;
        b.method_25355(class_2561.method_43470(name + "  " + Fx.num(fee) + " EMC"));
        b.field_22763 = ok;
        tip(b, name + "\n" + (delta / 1000) + "h " + ((delta % 1000) * 60 / 1000) + "m  -  " + Fx.num(fee) + " EMC");
    }

    void refresh() {
        if (skipBtn == null) return;
        long t = now();
        boolean ow = overworld();
        int wxNow = weatherNow();
        lastBal = ClientEmc.balance;
        lastTime = t;
        lastSpeed = speed;
        lastWx = wxNow;

        for (int i = 0; i < 4; i++) {
            style(abs[i], Fees.TIME_NAMES[i], Fees.timeDelta(t, Fees.TIME_TARGETS[i]), ow);
            style(rel[i], "+" + Fees.TIME_HOURS[i] + (Fees.TIME_HOURS[i] == 1 ? " hour" : " hours"), Fees.TIME_HOURS[i] * 1000L, ow);
        }
        skipBtn.method_25355(class_2561.method_43470(fast ? "Skip: WATCH" : "Skip: INSTANT"));
        tip(skipBtn, fast ? "Watch the sky race forward (about 4 in-game hours per second)" : "Jump straight to the new time");

        for (int i = 0; i < Fees.SPEED_X.length; i++) {
            GlowButton b = spd[i];
            long fee = Fees.SPEED_FEE[i];
            boolean on = i == speed;
            b.method_25355(class_2561.method_43470(i == 0 ? "1x" : "x" + Fees.SPEED_X[i]));
            b.selected = on;
            b.accent = on ? Fx.GREEN : Fx.CYAN;
            b.field_22763 = i == 0 ? speed != 0 : (on || fee <= ClientEmc.balance);
            tip(b, i == 0 ? "Normal speed (stops a running speed)"
                    : "Time x" + Fees.SPEED_X[i] + "\n" + Fx.num(fee) + " EMC per second, paid by you while it runs\nCrops, saplings and trees grow faster too");
        }

        for (int i = 0; i < Fees.WEATHER_NAMES.length; i++) {
            GlowButton b = wx[i];
            long fee = Fees.WEATHER_FEE[i];
            boolean cur = i == wxNow;
            b.method_25355(class_2561.method_43470(Fees.WEATHER_NAMES[i]));
            b.selected = cur;
            b.field_22763 = ow && (cur || fee <= ClientEmc.balance);
            tip(b, !ow ? "Weather only changes in the Overworld"
                    : cur ? Fees.WEATHER_NAMES[i] + " is on now"
                    : Fees.WEATHER_NAMES[i] + "  -  " + Fx.num(fee) + " EMC\nLasts about " + (Fees.WEATHER_TICKS[i] / 1200) + " minutes");
        }
    }

    @Override
    public void method_25393() {
        long t = now();
        // prices only change when a new in-game hour starts, the balance moves, the speed changes or the sky changes
        if (ClientEmc.balance != lastBal || t / 1000 != lastTime / 1000 || speed != lastSpeed || weatherNow() != lastWx) refresh();
        lastTime = t;
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        long t = now();
        int d = dayTick(t);
        boolean night = d >= 13000 && d < 23000;
        Fx.showcase(ctx, Icons.stack("minecraft:clock"), left + 30, top + 48, 1.4f, night ? Fx.PURPLE : Fx.GOLD);
        txt(ctx, clock(t), left + 62, top + 28, WHITE);
        txt(ctx, phase(t) + "  -  day " + (t / 24000 + 1), left + 100, top + 28, night ? 0xFFB090FF : 0xFFE0B040);
        if (speed > 0) txt(ctx, "x" + Fees.SPEED_X[speed], left + W - 10 - field_22793.method_1727("x" + Fees.SPEED_X[speed]), top + 28, 0xFF50FF90);

        // sky strip: day / sunset / night / sunrise with a moving marker
        int bx = left + 62, by = top + 44, bw = W - 72, bh = 10;
        int[] edge = {0, 12000, 13000, 23000, 24000};
        int[] col = {0x5AA8E8, 0xE08040, 0x161C3C, 0xE0A060};
        for (int i = 0; i < 4; i++) {
            int x0 = bx + edge[i] * bw / 24000, x1 = bx + edge[i + 1] * bw / 24000;
            ctx.method_25296(x0, by, x1, by + bh, Fx.argb(255, Fx.mix(col[i], Fx.WHITE, 0.15f)), Fx.argb(255, col[i]));
        }
        Fx.ring(ctx, bx - 1, by - 1, bw + 2, bh + 2, Fx.argb(120, Fx.CYAN));
        int mxp = bx + d * bw / 24000;
        Fx.glow(ctx, mxp - 1, by - 2, 3, bh + 4, Fx.WHITE, 0.9f, 3);
        ctx.method_25294(mxp - 1, by - 3, mxp + 2, by + bh + 3, 0xFFFFFFFF);
        small(ctx, "6:00", bx, by + 13);
        small(ctx, "12:00", bx + bw / 4 - 8, by + 13);
        small(ctx, "18:00", bx + bw / 2 - 8, by + 13);
        small(ctx, "0:00", bx + bw * 3 / 4 - 6, by + 13);

        txt(ctx, "SKIP TO", left + CL, top + 72, 0xFF7A8A99);
        txt(ctx, "SKIP FORWARD  (" + Fx.num(Fees.TIME_HOUR_FEE) + " EMC / hour)", left + CR, top + 72, 0xFF7A8A99);
        txt(ctx, "TIME SPEED", left + CL, top + 170, 0xFF7A8A99);
        txt(ctx, "WEATHER", left + CR, top + 170, 0xFF7A8A99);

        StringBuilder sp = new StringBuilder();
        for (int i = 1; i < Fees.SPEED_X.length; i++) sp.append(i > 1 ? "   " : "").append('x').append(Fees.SPEED_X[i]).append(' ').append(Fees.SPEED_FEE[i]);
        if (speed > 0) small(ctx, "Running x" + Fees.SPEED_X[speed] + " - " + Fees.SPEED_FEE[speed] + " EMC/s - crops grow faster", left + CL, top + 205, 0xFF50FF90);
        else small(ctx, sp + "  EMC per second", left + CL, top + 205, 0xFF7A8A99);

        StringBuilder wf = new StringBuilder();
        for (int i = 0; i < Fees.WEATHER_NAMES.length; i++) wf.append(i > 0 ? "   " : "").append(Fees.WEATHER_NAMES[i]).append(' ').append(Fees.WEATHER_FEE[i]);
        small(ctx, wf + "  EMC", left + CR, top + 205, 0xFF7A8A99);
    }

    private void small(class_332 c, String s, int x, int y) { small(c, s, x, y, 0xFF7A8A99); }

    private void small(class_332 c, String s, int x, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.6f, 0.6f);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (x / 0.6f), (int) (y / 0.6f), color, false);
        m.popMatrix();
    }
}

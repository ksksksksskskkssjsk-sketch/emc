package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/** Fuel-free furnace. Smelts the item in your hand (then more of the same in your inventory) at the speed you pick. */
public class FurnaceScreen extends ServiceScreen {
    private int ticks = 0;
    private int activeTier = -1;
    private final java.util.List<GlowButton> tierBtns = new java.util.ArrayList<>();

    public FurnaceScreen() {
        super("FUEL-FREE FURNACE");
        H = 170;
        accent = Fx.ORANGE;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        tierBtns.clear();
        for (int i = 0; i < Fees.SMELT_NAMES.length; i++) {
            final int tier = i;
            double perSec = 20.0 / Fees.SMELT_INTERVAL[i] * Fees.SMELT_BATCH[i];
            GlowButton b = GlowButton.of(
                    Fees.SMELT_NAMES[i] + " - " + (perSec == Math.floor(perSec) ? String.valueOf((int) perSec) : String.valueOf(perSec)) + "/s - " + Fees.SMELT_FEE[i] + " EMC each",
                    left + 10, top + 52 + i * 22, 230, 18,
                    x -> { activeTier = tier; ClientPlayNetworking.send(new ActionPayload(8, "", tier)); });
            b.accent = Fx.mix(Fx.ORANGE, 0xFFE060, tier / 3f);
            tierBtns.add(b);
            b.method_47400(class_7919.method_47407(class_2561.method_43470("Fee per item. Smelting never earns you EMC.")));
            method_37063(b);
        }
        GlowButton stop = GlowButton.of("Stop", left + 10, top + 142, 112, 18, b -> { activeTier = -1; ClientPlayNetworking.send(new ActionPayload(9, "", 0)); });
        stop.accent = Fx.RED;
        method_37063(stop);
        GlowButton back = GlowButton.of("Back", left + 128, top + 142, 112, 18, b -> class_310.method_1551().method_1507(new ServicesScreen()));
        back.accent = Fx.GOLD;
        method_37063(back);
    }

    @Override
    public void method_25393() {
        for (int i = 0; i < tierBtns.size(); i++) tierBtns.get(i).selected = i == activeTier;
        if (++ticks % 40 == 0) ClientPlayNetworking.send(new ActionPayload(11, "", 0)); // refresh balance
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.flames(ctx, left + 2, top + H - 2, W - 4, activeTier < 0 ? 0.35f : 0.6f + 0.4f * activeTier / 3f);
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        class_310 mc = class_310.method_1551();
        class_1799 st = mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
        if (st.method_7960()) { txt(ctx, "Hold the item you want to smelt", left + 8, top + 28, GREY); return; }
        Fx.showcase(ctx, st, left + 18, top + 32, 1.0f, Fx.ORANGE);
        txt(ctx, field_22793.method_27523(st.method_7964().getString() + " x" + st.method_7947(), 200), left + 36, top + 28, WHITE);
    }
}

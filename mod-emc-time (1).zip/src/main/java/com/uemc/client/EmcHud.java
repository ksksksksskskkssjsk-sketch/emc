package com.uemc.client;

import com.uemc.UniversalEmc;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * On-screen EMC balance. Always visible in the world (hidden with F1, and while a UEMC screen is open).
 * Shows an animated balance, +/- popups when it changes, and the EMC value of the item in your hand.
 * Commands (client side): /emchud, /emchud on|off, /emchud topleft|topright|bottomleft|bottomright
 * Settings are saved in config/uemc_hud.properties.
 */
public final class EmcHud {
    private EmcHud() {}

    private static boolean enabled = true;
    private static int corner = 0; // 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right

    private static final Fx.Counter COUNTER = new Fx.Counter();
    private static long seen = Long.MIN_VALUE;

    private record Pop(long delta, float start) {}
    private static final List<Pop> POPS = new ArrayList<>();

    public static void init() {
        load();
        HudElementRegistry.attachElementAfter(VanillaHudElements.BOSS_BAR,
                class_2960.method_60655(UniversalEmc.ID, "emc_hud"), (ctx, tick) -> render(ctx));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
                ClientCommandManager.literal("emchud")
                        .executes(c -> { enabled = !enabled; save(); say(c.getSource(), enabled ? "EMC HUD on" : "EMC HUD off"); return 1; })
                        .then(ClientCommandManager.literal("on").executes(c -> { enabled = true; save(); say(c.getSource(), "EMC HUD on"); return 1; }))
                        .then(ClientCommandManager.literal("off").executes(c -> { enabled = false; save(); say(c.getSource(), "EMC HUD off"); return 1; }))
                        .then(ClientCommandManager.literal("topleft").executes(c -> place(c.getSource(), 0)))
                        .then(ClientCommandManager.literal("topright").executes(c -> place(c.getSource(), 1)))
                        .then(ClientCommandManager.literal("bottomleft").executes(c -> place(c.getSource(), 2)))
                        .then(ClientCommandManager.literal("bottomright").executes(c -> place(c.getSource(), 3)))));
    }

    private static int place(FabricClientCommandSource src, int c) {
        corner = c;
        enabled = true;
        save();
        say(src, "EMC HUD moved");
        return 1;
    }

    private static void say(FabricClientCommandSource src, String s) {
        src.sendFeedback(class_2561.method_43470(s));
    }

    /** Called when the server sends a new balance. */
    public static void onBalance(long emc) {
        if (seen != Long.MIN_VALUE && emc != seen) {
            POPS.add(new Pop(emc - seen, Fx.t()));
            if (POPS.size() > 6) POPS.remove(0);
        }
        seen = emc;
        ClientEmc.balance = emc;
    }

    /** Leaving a world: forget everything. */
    public static void reset() {
        seen = Long.MIN_VALUE;
        ClientEmc.balance = 0;
        POPS.clear();
    }

    // ---------- drawing ----------
    private static void render(class_332 ctx) {
        if (!enabled) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        if (mc.field_1755 instanceof ServiceScreen || mc.field_1755 instanceof TabletScreen
                || mc.field_1755 instanceof ConverterMenuScreen) return;
        class_327 tr = mc.field_1772;

        String line1 = "EMC " + Fx.num(COUNTER.get(ClientEmc.balance));
        String line2 = null;
        class_1799 hand = mc.field_1724.method_6047();
        long one = ClientEmc.unit(hand);
        if (one > 0) {
            int n = hand.method_7947();
            line2 = "Hand: " + Fx.num(one) + (n > 1 ? "  x" + n + " = " + Fx.num(one * n) : "");
        }

        int pad = 5, iconW = 12;
        int w = pad * 2 + iconW + Math.max(tr.method_1727(line1), line2 == null ? 0 : tr.method_1727(line2));
        int h = pad * 2 + 8 + (line2 == null ? 0 : 10);
        int sw = ctx.method_51421(), sh = ctx.method_51443();
        int x = (corner % 2 == 0) ? 6 : sw - 6 - w;
        int y = (corner < 2) ? 6 : sh - 6 - h;

        float tt = Fx.t();
        Fx.glow(ctx, x, y, w, h, Fx.CYAN, 0.4f + 0.15f * Fx.sin(tt * 2f), 3);
        ctx.method_25294(x, y, x + w, y + h, 0xC0081016);
        ctx.method_25296(x + 1, y + h - 8, x + w - 1, y + h - 1, Fx.argb(0, Fx.CYAN), Fx.argb(26, Fx.CYAN));
        Fx.ring(ctx, x, y, w, h, Fx.argb(140, Fx.CYAN));
        ctx.method_25296(x + 1, y + 1, x + w - 1, y + 4, Fx.argb(60, Fx.CYAN), Fx.argb(0, Fx.CYAN));
        Fx.chase(ctx, x, y, w, h, Fx.CYAN, 0.7f, 14);
        Fx.orb(ctx, x + pad + 4, y + pad + 4, Fx.CYAN);
        Fx.text(ctx, tr, line1, x + pad + iconW, y + pad, 0xFFFFFFFF);
        if (line2 != null) Fx.text(ctx, tr, line2, x + pad + iconW, y + pad + 10, 0xFFAAAAAA);

        // +/- popups slide out beside the box
        float now = Fx.t();
        POPS.removeIf(p -> now - p.start() > 1.6f || now < p.start());
        for (Pop p : POPS) {
            float age = now - p.start();
            String s = (p.delta() > 0 ? "+" : "-") + Fx.num(Math.abs(p.delta()));
            int px = (corner % 2 == 0) ? x + w + 6 : x - 6 - tr.method_1727(s);
            float e = Fx.ease(age / 1.6f);
            int py = (corner < 2) ? y + 2 + (int) (e * 14) : y + h - 10 - (int) (e * 14);
            int rgb = p.delta() > 0 ? Fx.GREEN : Fx.RED;
            if (age > 1.2f) Fx.text(ctx, tr, s, px, py, Fx.argb((int) (255 * (1.6f - age) / 0.4f), rgb));
            else Fx.popText(ctx, tr, s, px, py, age, 1.6f, rgb);
        }
    }

    // ---------- settings file ----------
    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("uemc_hud.properties");
    }

    private static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (var in = Files.newInputStream(f)) { p.load(in); }
            enabled = !"false".equals(p.getProperty("enabled", "true").trim());
            corner = Math.max(0, Math.min(3, Integer.parseInt(p.getProperty("corner", "0").trim())));
        } catch (IOException | RuntimeException e) {
            UniversalEmc.LOG.warn("Could not read EMC HUD settings", e);
        }
    }

    private static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Properties p = new Properties();
            p.setProperty("enabled", String.valueOf(enabled));
            p.setProperty("corner", String.valueOf(corner));
            try (var out = Files.newOutputStream(f)) { p.store(out, "Universal EMC HUD (corner: 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right)"); }
        } catch (IOException e) {
            UniversalEmc.LOG.warn("Could not save EMC HUD settings", e);
        }
    }
}

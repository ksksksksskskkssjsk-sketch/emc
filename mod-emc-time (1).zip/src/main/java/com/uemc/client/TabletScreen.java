package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.StatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * EMC Tablet hub.
 *   Top row: Buy / Sell / XP Shop / Services (one big button each).
 *   Buy: every item that has an EMC price. Pick a category or type in the search box, click an item,
 *        press Buy 1 / 16 / 64 / Max. Buttons you can't afford are greyed out. Server validates everything.
 */
public class TabletScreen extends class_437 {
    private static final int W = 292, H = 206, COLS = 7, ROWS = 5, PER = COLS * ROWS;
    private static final int GRID_Y = 86, RX = 144;
    private static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA;
    private static final String[] TABS = {"All", "Blocks", "Gear", "Food", "Mats"};
    private static final int[] CAT_RGB = {Fx.CYAN, Fx.GREEN, Fx.GOLD, 0xFF7070, Fx.PURPLE};
    private static final int[] AMOUNTS = {1, 16, 64};

    private record Entry(String key, class_1799 stack, String name, long value, int cat) {}

    private long emc;
    private final List<Entry> buyAll = new ArrayList<>();
    private final List<Entry> filtered = new ArrayList<>();
    private final List<GlowButton> cells = new ArrayList<>();
    private final List<GlowButton> tabs = new ArrayList<>();
    private final GlowButton[] buyBtn = new GlowButton[3];
    private GlowButton maxBtn;
    private class_342 search;
    private String query = "";
    private Entry sel;
    private int page = 0, tab = 0, left, top;

    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;
    private final float openT = Fx.t();
    private float pageT = Fx.t();

    public TabletScreen(StatePayload s) {
        super(class_2561.method_43470("EMC Tablet"));
        loadItems();
        emc = s.emc();
        ClientEmc.balance = emc;
    }

    private static int category(class_1799 st) {
        if (st.method_7963()) return 2;
        if (st.method_57826(class_9334.field_50075)) return 3;
        if (st.method_7909() instanceof class_1747) return 1;
        return 4;
    }

    /** Every item with a price (the client already got the full list when joining). */
    private void loadItems() {
        buyAll.clear();
        for (Map.Entry<class_2960, Long> e : ClientEmc.all().entrySet()) {
            class_2960 id = e.getKey();
            if (e.getValue() <= 0 || !class_7923.field_41178.method_10250(id)) continue;
            class_1792 it = class_7923.field_41178.method_63535(id);
            class_1799 st = new class_1799(it);
            if (st.method_7960()) continue;
            buyAll.add(new Entry(id.toString(), st, it.method_63680().getString(), e.getValue(), category(st)));
        }
        buyAll.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    /** New balance from the server (after every buy). */
    public void update(StatePayload s) {
        emc = s.emc();
        ClientEmc.balance = emc;
        syncBuy();
    }

    /** What the Sell and XP screens do when you press their Back button: reopen the tablet. */
    private static void backToTablet() {
        class_310.method_1551().method_1507(null);
        ClientPlayNetworking.send(new ActionPayload(11, "", 0));
    }

    private GlowButton nav(String label, String tip, int i, int color, Runnable r) {
        GlowButton b = GlowButton.of(label, left + 8 + i * 70, top + 22, 66, 20, x -> r.run());
        b.accent = color;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        return b;
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - W) / 2;
        top = (field_22790 - H) / 2;

        GlowButton buy = nav("Buy", "Buy any item that has an EMC price", 0, Fx.CYAN, () -> {});
        buy.selected = true;
        nav("Sell", "Sell items from your inventory (or everything in one click)", 1, Fx.GOLD,
                () -> class_310.method_1551().method_1507(new SellScreen(TabletScreen::backToTablet)));
        nav("XP Shop", "Buy or sell XP levels", 2, Fx.GREEN,
                () -> class_310.method_1551().method_1507(new XpShopScreen(TabletScreen::backToTablet)));
        nav("Services", "Enchanting table, furnace, repair, teleport and tool upgrades", 3, Fx.PURPLE,
                () -> class_310.method_1551().method_1507(new ServicesScreen()));

        tabs.clear();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            GlowButton b = GlowButton.of(TABS[i], left + 8 + i * 56, top + 46, 53, 16, x -> { tab = idx; page = 0; pageT = Fx.t(); refilter(); });
            b.accent = CAT_RGB[i];
            tabs.add(b);
            method_37063(b);
        }

        search = new class_342(field_22793, left + 8, top + 66, COLS * 18, 16, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; page = 0; pageT = Fx.t(); refilter(); });
        method_37063(search);

        cells.clear();
        for (int i = 0; i < PER; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % COLS) * 18, top + GRID_Y + (i / COLS) * 18, x -> pick(idx));
            cells.add(b);
            method_37063(b);
        }

        int py = top + 180;
        method_37063(GlowButton.of("<", left + 8, py, 24, 18, b -> { if (page > 0) { page--; pageT = Fx.t(); refilter(); } }));
        method_37063(GlowButton.of(">", left + 36, py, 24, 18, b -> { if ((page + 1) * PER < filtered.size()) { page++; pageT = Fx.t(); refilter(); } }));

        int bx = left + RX;
        for (int i = 0; i < 3; i++) {
            final int n = AMOUNTS[i];
            buyBtn[i] = GlowButton.of("", bx + (i % 2) * 72, top + 112 + (i / 2) * 26, 68, 22, b -> buyNow(n));
            method_37063(buyBtn[i]);
        }
        maxBtn = GlowButton.of("", bx + 72, top + 138, 68, 22, b -> {
            if (sel != null) buyNow(maxAmount());
        });
        method_37063(maxBtn);

        GlowButton conv = GlowButton.of("Sell offhand item", bx, top + 166, 140, 20, b -> ClientPlayNetworking.send(new ActionPayload(2, "", 1)));
        conv.method_47400(class_7919.method_47407(class_2561.method_43470("Turns the item in your offhand into EMC")));
        conv.accent = Fx.GOLD;
        method_37063(conv);

        refilter();
    }

    private void refilter() {
        filtered.clear();
        String q = query.trim().toLowerCase();
        for (Entry e : buyAll) {
            if (tab != 0 && e.cat != tab) continue;
            if (q.isEmpty() || e.name.toLowerCase().contains(q) || e.key.contains(q)) filtered.add(e);
        }
        int maxPage = Math.max(0, (filtered.size() - 1) / PER);
        if (page > maxPage) page = maxPage;
        for (int i = 0; i < cells.size(); i++) {
            GlowButton c = cells.get(i);
            int idx = page * PER + i;
            c.field_22763 = idx < filtered.size();
            if (idx < filtered.size()) {
                Entry e = filtered.get(idx);
                c.accent = CAT_RGB[e.cat];
                c.method_47400(class_7919.method_47407(class_2561.method_43470(e.name + "\n" + Fx.num(e.value) + " EMC")));
            } else c.method_47400(null);
        }
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).selected = i == tab;
        syncBuy();
    }

    private void pick(int idx) {
        int i = page * PER + idx;
        if (i < filtered.size()) { sel = filtered.get(i); syncBuy(); }
    }

    private int maxAmount() {
        if (sel == null || sel.value <= 0) return 0;
        return (int) Math.min(2304, emc / sel.value);
    }

    private void buyNow(int n) {
        if (sel != null && n > 0) ClientPlayNetworking.send(new ActionPayload(1, sel.key, n));
    }

    /** Buy buttons: say what they cost, grey out what you can't afford. */
    private void syncBuy() {
        if (maxBtn == null) return;
        for (int i = 0; i < 3; i++) {
            int n = AMOUNTS[i];
            GlowButton b = buyBtn[i];
            b.method_25355(class_2561.method_43470("Buy " + n));
            if (sel == null) {
                b.field_22763 = false;
                b.accent = Fx.GREEN;
                b.method_47400(class_7919.method_47407(class_2561.method_43470("Click an item first")));
                continue;
            }
            long cost = sel.value * n;
            boolean ok = emc >= cost;
            b.field_22763 = ok;
            b.accent = ok ? Fx.GREEN : Fx.RED;
            b.method_47400(class_7919.method_47407(class_2561.method_43470(ok
                    ? "Buy " + n + " for " + Fx.num(cost) + " EMC"
                    : "Need " + Fx.num(cost) + " EMC")));
        }
        int m = maxAmount();
        maxBtn.method_25355(class_2561.method_43470(m > 0 ? "Max x" + m : "Max"));
        maxBtn.field_22763 = m > 0;
        maxBtn.accent = Fx.GOLD;
        maxBtn.method_47400(sel == null ? class_7919.method_47407(class_2561.method_43470("Click an item first"))
                : class_7919.method_47407(class_2561.method_43470(m > 0
                        ? "Buy " + m + " for " + Fx.num(sel.value * m) + " EMC (everything you can afford)"
                        : "You can't afford one")));
    }

    private void txt(class_332 c, String s, int x, int y, int color) {
        c.method_51439(field_22793, class_2561.method_43470(s), x, y, color, true);
    }

    /** Do not pause the (single-player) server while this screen is open: a paused server does not sync your inventory, so sold items would stay on screen. */
    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, Fx.CYAN);
        ctx.method_25296(left + 139, top + 66, left + 140, top + H - 8, Fx.argb(0, Fx.CYAN), Fx.argb(200, Fx.CYAN));
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        Fx.title(ctx, field_22793, "EMC TABLET", left + 8, top + 8, Fx.CYAN);

        if (lastBal != Long.MIN_VALUE && emc != lastBal) Fx.pop(emc - lastBal);
        lastBal = emc;
        String bal = "EMC " + Fx.num(counter.get(emc));
        int bxr = left + W - 8 - field_22793.method_1727(bal);
        Fx.orb(ctx, bxr - 9, top + 12, Fx.CYAN);
        Fx.glowText(ctx, field_22793, bal, bxr, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, field_22793, left + W - 8, top + 18);

        float now = Fx.t();
        for (int i = 0; i < cells.size(); i++) {
            int idx = page * PER + i;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + GRID_Y + (i / COLS) * 18 + 1;
            float appear = Fx.ease((now - pageT) * 4f - ((i % COLS) + (i / COLS)) * 0.08f);
            Fx.item(ctx, e.stack, x, y, cells.get(i).method_49606(), e == sel, appear, CAT_RGB[e.cat]);
        }
        int pages = Math.max(1, (filtered.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 66, top + 185, GREY);
        if (filtered.isEmpty()) txt(ctx, "No items", left + 10, top + GRID_Y + 4, GREY);

        int bx = left + RX;
        if (sel == null) {
            txt(ctx, "Click an item to buy", bx, top + 72, GREY);
            txt(ctx, "Hover it to see the price", bx, top + 84, GREY);
        } else {
            Fx.showcase(ctx, sel.stack, bx + 14, top + 78, 1.6f, CAT_RGB[sel.cat]);
            txt(ctx, field_22793.method_27523(sel.name, 104), bx + 32, top + 66, WHITE);
            Fx.glowText(ctx, field_22793, Fx.num(sel.value) + " EMC", bx + 32, top + 80, Fx.CYAN);
            int can = maxAmount();
            txt(ctx, can > 0 ? "You can buy " + can : "Not enough EMC", bx + 32, top + 94, can > 0 ? 0xFF7FFFB0 : 0xFFFF7070);
        }
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

package com.uemc.client;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Button with animated hover glow, shine sweep and accent line. cell=true makes it an item slot. */
public class GlowButton extends class_4185 {
    private float hover = 0;
    public int accent = Fx.CYAN;
    public boolean cell = false;
    public boolean selected = false;

    private GlowButton(int x, int y, int w, int h, net.minecraft.class_2561 msg, class_4241 a) {
        super(x, y, w, h, msg, a, field_40754);
    }

    public static GlowButton of(String label, int x, int y, int w, int h, class_4241 a) {
        return new GlowButton(x, y, w, h, net.minecraft.class_2561.method_43470(label), a);
    }

    public static GlowButton slot(int x, int y, class_4241 a) {
        GlowButton b = new GlowButton(x, y, 18, 18, net.minecraft.class_2561.method_43473(), a);
        b.cell = true;
        return b;
    }

    private boolean wasSel = false, wasOn = true;
    private float flash = 0;

    @Override
    public void method_75752(class_332 c, int mx, int my, float delta) {
        float target = (method_49606() && field_22763) ? 1f : 0f;
        hover += (target - hover) * 0.28f;
        // flash when it becomes selected / becomes usable
        if ((selected && !wasSel) || (field_22763 && !wasOn)) flash = 1f;
        wasSel = selected;
        wasOn = field_22763;
        flash = Math.max(0f, flash - 0.06f);

        int x = method_46426(), y = method_46427(), w = method_25368(), h = method_25364();
        float t = Fx.t();
        int acc = accent;
        float breathe = selected ? 0.7f + 0.2f * Fx.sin(t * 4f) : 0f;
        float glowAmt = Math.max(Math.max(hover, breathe), flash);

        if (!cell && glowAmt > 0.03f && field_22763) Fx.glow(c, x, y, w, h, acc, glowAmt * 0.7f, 4);
        int borderA = !field_22763 ? 30 : cell ? (int) (50 + 160 * Math.max(hover, flash)) : (int) (70 + 170 * glowAmt);
        c.method_25294(x, y, x + w, y + h, Fx.argb(255, 0x05090D));
        int top = field_22763 ? Fx.mix(0x1F2D3A, Fx.mix(0x1F2D3A, acc, 0.38f), glowAmt) : 0x151C23;
        int bot = field_22763 ? Fx.mix(0x111A22, Fx.mix(0x111A22, acc, 0.24f), glowAmt) : 0x0D1218;
        c.method_25296(x + 1, y + 1, x + w - 1, y + h - 1, Fx.argb(255, top), Fx.argb(255, bot));
        if (flash > 0.02f) c.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, Fx.argb((int) (110 * flash), Fx.WHITE));
        Fx.ring(c, x, y, w, h, Fx.argb(borderA, acc));
        c.method_25294(x + 1, y + 1, x + w - 1, y + 2, 0x20FFFFFF);

        if (!cell && field_22763) {
            // accent line that fills from the left on hover and runs when selected
            int lw = (int) ((w - 4) * Math.max(Fx.smooth(hover), selected ? 1f : 0f));
            c.method_25294(x + 2, y + h - 2, x + 2 + lw, y + h - 1, Fx.argb((int) (90 + 165 * glowAmt), acc));
            if (selected && lw > 8) {
                int rx = x + 2 + (int) ((t * 60f) % lw);
                c.method_25294(rx, y + h - 2, Math.min(rx + 6, x + 2 + lw), y + h - 1, Fx.argb(255, Fx.WHITE));
            }
            if (selected) c.method_25294(x + 1, y + 2, x + 3, y + h - 2, Fx.argb(200, acc));
        }

        if (hover > 0.05f && field_22763) {
            float sx = (t * 80f) % (w + 30) - 15;
            int a = (int) Math.max(x + 1, x + sx), b = (int) Math.min(x + w - 1, x + sx + 10);
            if (b > a) c.method_25294(a, y + 1, b, y + h - 1, Fx.argb((int) (46 * hover), Fx.WHITE));
            if (cell) Fx.sparkle(c, x + w - 3, y + 3, 2, Fx.WHITE, hover * (0.5f + 0.5f * Fx.sin(t * 8f)));
        }

        if (!cell) {
            class_327 tr = class_310.method_1551().field_1772;
            String s = tr.method_27523(method_25369().getString(), w - 6);
            int col = !field_22763 ? 0xFF6A7580 : Fx.argb(255, Fx.mix(0xE8F4F8, Fx.WHITE, glowAmt));
            int tx = x + (w - tr.method_1727(s)) / 2, ty = y + (h - 8) / 2 - (hover > 0.6f ? 1 : 0);
            if (glowAmt > 0.3f && field_22763) Fx.glowText(c, tr, s, tx, ty, Fx.mix(0xE8F4F8, acc, 0.35f));
            else c.method_51439(tr, net.minecraft.class_2561.method_43470(s), tx, ty, col, true);
        }
    }
}

package com.uemc;

import com.uemc.block.ConverterBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModBlocks {
    public static final class_2248 CONVERTER_BASIC = converter("converter_basic", 16);
    public static final class_2248 CONVERTER_ADVANCED = converter("converter_advanced", 64);
    public static final class_2248 CONVERTER_ULTIMATE = converter("converter_ultimate", 256);

    public static final class_2248 MINE_PORTAL = portal("mine_portal");

    private static class_2248 portal(String name) {
        class_2960 id = class_2960.method_60655(UniversalEmc.ID, name);
        class_5321<class_2248> bk = class_5321.method_29179(class_7924.field_41254, id);
        class_5321<class_1792> ik = class_5321.method_29179(class_7924.field_41197, id);
        class_2248 b = class_2378.method_39197(class_7923.field_41175, bk, new com.uemc.block.MinePortalBlock(
                class_4970.class_2251.method_9637().method_63500(bk).method_9632(8.0f).method_9626(class_2498.field_11533)
                        .method_9631(s -> 12)));
        class_2378.method_39197(class_7923.field_41178, ik, new class_1747(b, new class_1792.class_1793().method_63686(ik).method_63685()));
        return b;
    }

    private static class_2248 converter(String name, int perUse) {
        class_2960 id = class_2960.method_60655(UniversalEmc.ID, name);
        class_5321<class_2248> bk = class_5321.method_29179(class_7924.field_41254, id);
        class_5321<class_1792> ik = class_5321.method_29179(class_7924.field_41197, id);
        class_2248 b = class_2378.method_39197(class_7923.field_41175, bk, new ConverterBlock(
                class_4970.class_2251.method_9637().method_63500(bk).method_9632(3.5f).method_9626(class_2498.field_11533)
                        .method_22488().method_9631(s -> s.method_11654(ConverterBlock.CHARGE) > 0 ? 4 + s.method_11654(ConverterBlock.CHARGE) : 3),
                perUse));
        class_2378.method_39197(class_7923.field_41178, ik, new class_1747(b, new class_1792.class_1793().method_63686(ik).method_63685()));
        return b;
    }

    public static void init() {}
}

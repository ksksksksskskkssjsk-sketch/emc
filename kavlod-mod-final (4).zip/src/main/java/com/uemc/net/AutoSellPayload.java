package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: is Auto-Sell on, and which item ids are on the player's list. */
public record AutoSellPayload(boolean on, List<String> ids) implements class_8710 {
    public static final class_8710.class_9154<AutoSellPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "auto_sell"));

    public static final class_9139<class_9129, AutoSellPayload> CODEC = new class_9139<>() {
        @Override
        public AutoSellPayload decode(class_9129 buf) {
            boolean on = buf.method_10816() != 0;
            int n = buf.method_10816();
            List<String> ids = new ArrayList<>(n);
            for (int i = 0; i < n; i++) ids.add(buf.method_10800(256));
            return new AutoSellPayload(on, ids);
        }

        @Override
        public void encode(class_9129 buf, AutoSellPayload p) {
            buf.method_10804(p.on ? 1 : 0);
            buf.method_10804(p.ids.size());
            for (String id : p.ids) buf.method_10814(id);
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

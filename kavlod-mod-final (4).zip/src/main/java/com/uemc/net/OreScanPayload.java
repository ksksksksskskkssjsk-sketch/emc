package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Server -> client: result of one Ore Scanner use.
 * origin = where the player stood. blips / near = flat lists of x,y,z offsets from the origin
 * (blips = a spread-out sample for the radar, near = the closest separate spots).
 */
public record OreScanPayload(String group, int size, int total, int ox, int oy, int oz,
                             List<Integer> blips, List<Integer> near) implements class_8710 {
    public static final class_8710.class_9154<OreScanPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "ore_scan"));

    private static final int XZ = 30_000_000, Y = 1024, REL = 64;

    private static List<Integer> readList(class_9129 buf) {
        int n = buf.method_10816();
        List<Integer> l = new ArrayList<>(n * 3);
        for (int i = 0; i < n * 3; i++) l.add(buf.method_10816() - REL);
        return l;
    }

    private static void writeList(class_9129 buf, List<Integer> l) {
        buf.method_10804(l.size() / 3);
        for (int v : l) buf.method_10804(v + REL);
    }

    public static final class_9139<class_9129, OreScanPayload> CODEC = new class_9139<>() {
        @Override
        public OreScanPayload decode(class_9129 buf) {
            String group = buf.method_10800(64);
            int size = buf.method_10816();
            int total = buf.method_10816();
            int ox = buf.method_10816() - XZ, oy = buf.method_10816() - Y, oz = buf.method_10816() - XZ;
            List<Integer> blips = readList(buf);
            List<Integer> near = readList(buf);
            return new OreScanPayload(group, size, total, ox, oy, oz, blips, near);
        }

        @Override
        public void encode(class_9129 buf, OreScanPayload p) {
            buf.method_10814(p.group);
            buf.method_10804(p.size);
            buf.method_10804(p.total);
            buf.method_10804(p.ox + XZ);
            buf.method_10804(p.oy + Y);
            buf.method_10804(p.oz + XZ);
            writeList(buf, p.blips);
            writeList(buf, p.near);
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: your current EMC balance (drives the on-screen HUD) and whether Auto-Repair (Repair screen) is on. */
public record BalancePayload(long emc, boolean autoFix, boolean mine) implements class_8710 {
    public static final class_8710.class_9154<BalancePayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "balance"));
    public static final class_9139<class_9129, BalancePayload> CODEC = new class_9139<>() {
        @Override public BalancePayload decode(class_9129 buf) { return new BalancePayload(buf.readLong(), buf.readBoolean(), buf.readBoolean()); }
        @Override public void encode(class_9129 buf, BalancePayload p) { buf.method_52974(p.emc); buf.writeBoolean(p.autoFix); buf.writeBoolean(p.mine); }
    };
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

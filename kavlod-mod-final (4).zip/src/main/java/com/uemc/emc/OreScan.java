package com.uemc.emc;

import com.uemc.net.OreScanPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ore Scanner (Tablet > Services). Costs EMC per scan, looks at already loaded blocks around the player and sends
 * the client a radar sample plus the nearest separate spots. Nothing is placed in the world.
 */
public final class OreScan {
    private OreScan() {}

    private static final int MAX_BLIPS = 1200, MAX_NEAR = 5, SPOT_GAP_SQ = 36;
    private static final long COOLDOWN_MS = 1500;
    private static final Map<UUID, Long> LAST = new HashMap<>();
    private static final Map<String, Set<class_2248>> BLOCKS = new HashMap<>();

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    private static Set<class_2248> blocks(OreGroups.Group g) {
        return BLOCKS.computeIfAbsent(g.id(), k -> {
            Set<class_2248> set = new HashSet<>();
            for (String b : g.blocks()) {
                class_2960 id = class_2960.method_12829(b);
                if (id != null && class_7923.field_41175.method_10250(id)) set.add(class_7923.field_41175.method_63535(id));
            }
            return set;
        });
    }

    public static void scan(class_3222 p, String groupId, int size) {
        OreGroups.Group g = OreGroups.find(groupId);
        if (g == null || size < 0 || size >= OreGroups.RADIUS.length) return;
        long now = System.currentTimeMillis();
        Long last = LAST.get(p.method_5667());
        if (last != null && now - last < COOLDOWN_MS) { msg(p, "Scanner is recharging"); return; }
        Set<class_2248> wanted = blocks(g);
        if (wanted.isEmpty()) { msg(p, g.name() + " is not available"); return; }
        long fee = OreGroups.COST[size];
        if (!EmcData.add(p.method_5667(), -fee)) { msg(p, "Not enough EMC (need " + String.format("%,d", fee) + ")"); return; }
        LAST.put(p.method_5667(), now);

        class_3218 w = p.method_51469();
        class_2338 c = p.method_24515();
        int r = OreGroups.RADIUS[size], r2 = r * r;
        List<int[]> hits = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
                for (int dy = -r; dy <= r; dy++) {
                    int d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) continue;
                    class_2338 q = new class_2338(c.method_10263() + dx, c.method_10264() + dy, c.method_10260() + dz);
                    if (wanted.contains(w.method_8320(q).method_26204())) hits.add(new int[]{dx, dy, dz, d2});
                }

        // radar sample: evenly spread over the whole scan, so far veins show up too
        List<Integer> blips = new ArrayList<>();
        int stride = Math.max(1, (hits.size() + MAX_BLIPS - 1) / MAX_BLIPS);
        for (int i = 0; i < hits.size(); i += stride) {
            int[] h = hits.get(i);
            blips.add(h[0]); blips.add(h[1]); blips.add(h[2]);
        }
        // nearest separate spots (skip blocks next to a spot already listed, so one vein is one line)
        hits.sort((a, b) -> Integer.compare(a[3], b[3]));
        List<Integer> near = new ArrayList<>();
        for (int[] h : hits) {
            boolean apart = true;
            for (int j = 0; j < near.size(); j += 3) {
                int ex = h[0] - near.get(j), ey = h[1] - near.get(j + 1), ez = h[2] - near.get(j + 2);
                if (ex * ex + ey * ey + ez * ez < SPOT_GAP_SQ) { apart = false; break; }
            }
            if (!apart) continue;
            near.add(h[0]); near.add(h[1]); near.add(h[2]);
            if (near.size() >= MAX_NEAR * 3) break;
        }

        ServerPlayNetworking.send(p, new OreScanPayload(g.id(), size, hits.size(), c.method_10263(), c.method_10264(), c.method_10260(), blips, near));
        p.method_51469().method_8396(null, p.method_24515(), com.uemc.ModSounds.SCANNER_SCAN, net.minecraft.class_3419.field_15248, 0.7f, 1.0f);
        msg(p, hits.isEmpty()
                ? "No " + g.name() + " within " + r + " blocks (-" + String.format("%,d", fee) + " EMC)"
                : g.name() + ": " + hits.size() + " found within " + r + " blocks (-" + String.format("%,d", fee) + " EMC)");
    }

    public static void forget(UUID id) { LAST.remove(id); }
}

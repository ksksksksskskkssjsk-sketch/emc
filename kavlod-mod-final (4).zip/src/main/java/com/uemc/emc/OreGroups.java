package com.uemc.emc;

/** Ore Scanner data shared by the server (what to look for, what it costs) and the client (buttons, colours). */
public final class OreGroups {
    private OreGroups() {}

    public record Group(String id, String name, String icon, int color, String[] blocks) {}

    private static Group g(String id, String name, String icon, int color, String... blocks) {
        return new Group(id, name, icon, color, blocks);
    }

    public static final Group[] ALL = {
            g("coal", "Coal", "minecraft:coal", 0xB8B8B8, "minecraft:coal_ore", "minecraft:deepslate_coal_ore"),
            g("iron", "Iron", "minecraft:raw_iron", 0xE8B898, "minecraft:iron_ore", "minecraft:deepslate_iron_ore"),
            g("copper", "Copper", "minecraft:raw_copper", 0xE07840, "minecraft:copper_ore", "minecraft:deepslate_copper_ore"),
            g("gold", "Gold", "minecraft:raw_gold", 0xFFD040, "minecraft:gold_ore", "minecraft:deepslate_gold_ore"),
            g("redstone", "Redstone", "minecraft:redstone", 0xFF3030, "minecraft:redstone_ore", "minecraft:deepslate_redstone_ore"),
            g("lapis", "Lapis", "minecraft:lapis_lazuli", 0x4070FF, "minecraft:lapis_ore", "minecraft:deepslate_lapis_ore"),
            g("diamond", "Diamond", "minecraft:diamond", 0x40F0E0, "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"),
            g("emerald", "Emerald", "minecraft:emerald", 0x30E060, "minecraft:emerald_ore", "minecraft:deepslate_emerald_ore"),
            g("quartz", "Quartz", "minecraft:quartz", 0xEEEEDD, "minecraft:nether_quartz_ore"),
            g("nether_gold", "N. Gold", "minecraft:gold_nugget", 0xFFB030, "minecraft:nether_gold_ore"),
            g("debris", "Debris", "minecraft:netherite_scrap", 0xC08060, "minecraft:ancient_debris"),
            g("blocks", "Blocks", "minecraft:netherite_block", 0xFF50FF,
                    "minecraft:gold_block", "minecraft:diamond_block", "minecraft:emerald_block", "minecraft:coal_block",
                    "minecraft:iron_block", "minecraft:copper_block", "minecraft:redstone_block", "minecraft:lapis_block",
                    "minecraft:quartz_block", "minecraft:netherite_block"),
    };

    /** Scan radius in blocks (kept at 32 or less so every chunk looked at is already loaded) and the EMC each scan costs. */
    public static final int[] RADIUS = {16, 24, 32};
    public static final long[] COST = {4_000L, 12_000L, 30_000L};

    public static Group find(String id) {
        for (Group x : ALL) if (x.id().equals(id)) return x;
        return null;
    }
}

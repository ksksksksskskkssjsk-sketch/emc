package com.uemc.emc;

import com.uemc.net.AutoSellPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Auto-Sell: a free option in the Sell menu (not an upgrade). The player picks item types;
 * whenever one of them is in the inventory it is sold for EMC. Enchanted and damageable gear is never sold,
 * and anything on the player's /emc protect list or the server's protect list is kept.
 */
public final class AutoSell {
    private AutoSell() {}

    public static final int MAX_ITEMS = 300;

    private static final List<String> ORES = List.of(
            "minecraft:coal", "minecraft:raw_iron", "minecraft:raw_copper", "minecraft:raw_gold", "minecraft:redstone",
            "minecraft:lapis_lazuli", "minecraft:diamond", "minecraft:emerald", "minecraft:quartz", "minecraft:gold_nugget",
            "minecraft:amethyst_shard", "minecraft:ancient_debris", "minecraft:netherite_scrap");
    private static final List<String> JUNK = List.of(
            "minecraft:cobblestone", "minecraft:cobbled_deepslate", "minecraft:dirt", "minecraft:gravel", "minecraft:andesite",
            "minecraft:diorite", "minecraft:granite", "minecraft:tuff", "minecraft:netherrack", "minecraft:rotten_flesh");

    private static int tick = 0;

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(AutoSell::tick);
    }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    public static void send(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<String> ids = new ArrayList<>(d.autoSellItems);
        Collections.sort(ids);
        ServerPlayNetworking.send(p, new AutoSellPayload(d.autoSell, ids));
    }

    public static void toggleOn(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        d.autoSell = !d.autoSell;
        msg(p, d.autoSell
                ? (d.autoSellItems.isEmpty() ? "Auto-Sell on (pick items to sell)" : "Auto-Sell on")
                : "Auto-Sell off");
        send(p);
    }

    /** Adds the item if it is not on the list, removes it if it is. Adding to an empty list switches Auto-Sell on. */
    public static void toggleItem(class_3222 p, String id) {
        class_2960 rl = class_2960.method_12829(id);
        if (rl == null || !class_7923.field_41178.method_10250(rl)) return;
        EmcData.Player d = EmcData.get(p.method_5667());
        String key = rl.toString();
        if (!d.autoSellItems.remove(key)) {
            if (!add(d, key)) { msg(p, "That item has no EMC value or the list is full"); send(p); return; }
            if (d.autoSellItems.size() == 1) d.autoSell = true;
            if (EmcLogic.isProtected(p.method_5667(), key)) msg(p, "It is on a protect list, so it will be kept");
        }
        send(p);
    }

    /** name = "ores", "junk" or "clear". */
    public static void preset(class_3222 p, String name) {
        EmcData.Player d = EmcData.get(p.method_5667());
        boolean wasEmpty = d.autoSellItems.isEmpty();
        int added = 0;
        if (name.equals("clear")) {
            d.autoSellItems.clear();
            msg(p, "Auto-Sell list cleared");
            send(p);
            return;
        }
        List<String> src = name.equals("ores") ? ORES : name.equals("junk") ? JUNK : List.of();
        for (String id : src) if (add(d, id)) added++;
        if (wasEmpty && added > 0) d.autoSell = true;
        msg(p, added > 0 ? "Added " + added + " items to Auto-Sell" : "Those items are already on your list");
        send(p);
    }

    /** True if the id was newly added (valid item, has an EMC value, list not full). */
    private static boolean add(EmcData.Player d, String id) {
        if (d.autoSellItems.size() >= MAX_ITEMS || d.autoSellItems.contains(id)) return false;
        class_2960 rl = class_2960.method_12829(id);
        if (rl == null || !class_7923.field_41178.method_10250(rl)) return false;
        class_1792 item = class_7923.field_41178.method_63535(rl);
        if (EmcRegistry.get(item) <= 0) return false;
        d.autoSellItems.add(id);
        return true;
    }

    private static void tick(MinecraftServer s) {
        if (++tick % 10 != 0) return;
        for (UUID id : EmcData.all()) {
            EmcData.Player d = EmcData.get(id);
            if (!d.autoSell || d.autoSellItems.isEmpty()) continue;
            class_3222 p = s.method_3760().method_14602(id);
            if (p == null || !p.method_5805()) continue;
            long gained = 0;
            int items = 0;
            for (int i = 0; i < 36; i++) {
                class_1799 st = p.method_31548().method_5438(i);
                if (st.method_7960() || st.method_7942() || st.method_7963()) continue;
                String sid = class_7923.field_41178.method_10221(st.method_7909()).toString();
                if (!d.autoSellItems.contains(sid) || EmcLogic.isProtected(id, sid)) continue;
                int n = st.method_7947();
                long g = EmcLogic.convert(p, st);
                if (g > 0) { gained += g; items += n; }
            }
            if (gained > 0) {
                msg(p, "+" + String.format("%,d", gained) + " EMC (auto-sold " + items + " items)");
                p.method_51469().method_8396(null, p.method_24515(), com.uemc.ModSounds.EMC_TRANSACT, net.minecraft.class_3419.field_15248, 0.35f, 1.4f);
            }
        }
    }
}

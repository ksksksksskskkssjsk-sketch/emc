package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** config/uemc.json. Created with defaults on first start. */
public final class Config {
    private Config() {}

    /** Auto-Sell never sells these. Plain word = matches any item id containing it; "namespace:item" = exact item. */
    public static List<String> protect = new ArrayList<>(List.of(
            "diamond", "netherite", "emerald", "ancient_debris", "nether_star", "beacon", "elytra", "totem",
            "trident", "heart_of_the_sea", "enchanted_golden_apple", "dragon", "shulker", "bundle", "wither", "end_crystal", "spawner", "trial_key"));
    /** No longer used (Auto-Sell is now a free item list in the Sell menu). Kept so old config files still load. */
    public static long cap1 = 10, cap2 = 100;

    private static Path file() { return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("uemc.json"); }

    public static long cap(int level) { return level <= 1 ? cap1 : level == 2 ? cap2 : Long.MAX_VALUE; }

    public static boolean isProtected(String fullId) {
        fullId = fullId.toLowerCase(Locale.ROOT);
        String path = fullId.contains(":") ? fullId.substring(fullId.indexOf(':') + 1) : fullId;
        for (String p : protect) {
            if (p.contains(":") ? fullId.equals(p) : path.contains(p)) return true;
        }
        return false;
    }

    public static void load() {
        Path f = file();
        try {
            if (Files.exists(f)) {
                JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
                if (o.has("autosellProtect")) {
                    List<String> l = new ArrayList<>();
                    for (JsonElement e : o.getAsJsonArray("autosellProtect")) {
                        String v = e.getAsString().trim().toLowerCase(Locale.ROOT);
                        if (!v.isEmpty() && !l.contains(v)) l.add(v);   // a blank entry would match (protect) every item
                    }
                    protect = l;
                }
                if (o.has("autosellLevel1Max")) cap1 = Math.max(1, o.get("autosellLevel1Max").getAsLong());
                if (o.has("autosellLevel2Max")) cap2 = Math.max(cap1, o.get("autosellLevel2Max").getAsLong());
            } else save(f);
        } catch (IOException | RuntimeException ex) {
            UniversalEmc.LOG.warn("Could not read config/uemc.json, using defaults", ex);
        }
    }

    private static void save(Path f) throws IOException {
        JsonObject o = new JsonObject();
        JsonArray a = new JsonArray();
        protect.forEach(a::add);
        o.add("autosellProtect", a);
        o.addProperty("autosellLevel1Max", cap1);
        o.addProperty("autosellLevel2Max", cap2);
        Files.createDirectories(f.getParent());
        Files.writeString(f, new GsonBuilder().setPrettyPrinting().create().toJson(o));
    }
}

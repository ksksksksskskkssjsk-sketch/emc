package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Per-player EMC balance + discoveries. Server-side only; saved to <world>/uemc_players.json. */
public final class EmcData {
    public record Loc(String name, String dim, double x, double y, double z, float yaw, float pitch) {}

    private static JsonObject locJson(Loc l) {
        JsonObject o = new JsonObject();
        o.addProperty("name", l.name()); o.addProperty("dim", l.dim());
        o.addProperty("x", l.x()); o.addProperty("y", l.y()); o.addProperty("z", l.z());
        o.addProperty("yaw", l.yaw()); o.addProperty("pitch", l.pitch());
        return o;
    }

    private static Loc jsonLoc(JsonObject o) {
        return new Loc(o.get("name").getAsString(), o.get("dim").getAsString(), o.get("x").getAsDouble(),
                o.get("y").getAsDouble(), o.get("z").getAsDouble(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat());
    }

    public static final class Player {
        public long emc = 0;
        public Loc home = null;
        public final java.util.List<Loc> checkpoints = new java.util.ArrayList<>();
        public final Set<class_2960> discovered = new HashSet<>();
        public final Map<String, Integer> upgrades = new HashMap<>();
        public final Set<String> off = new HashSet<>();
        /** Level the player chose to run (1..owned). Missing = run the highest owned level. */
        public final Map<String, Integer> active = new HashMap<>();
        /** Item ids this player never wants Auto-Sell to sell (/emc protect). */
        public final Set<String> protect = new HashSet<>();
        /** Auto-Sell (Sell menu): switched on/off, and the item ids the player picked. */
        public boolean autoSell = false;
        /** Mine World unlocked (one-time Fees.MINE_COST[0], paid at a Mine Portal block). */
        public boolean mineUnlocked = false;
        public final Set<String> autoSellItems = new HashSet<>();
    }

    private static final Map<UUID, Player> PLAYERS = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private EmcData() {}

    private static Path file(MinecraftServer s) { return s.method_27050(class_5218.field_24188).resolve("uemc_players.json"); }

    public static Set<UUID> all() { return new HashSet<>(PLAYERS.keySet()); }

    public static Player get(UUID id) { return PLAYERS.computeIfAbsent(id, k -> new Player()); }

    /** Atomic add: returns false (no change) if it would go below 0 or overflow. */
    public static boolean add(UUID id, long amount) {
        Player p = get(id);
        long n;
        try { n = Math.addExact(p.emc, amount); } catch (ArithmeticException e) { return false; }
        if (n < 0) return false;
        p.emc = n;
        return true;
    }

    public static void load(MinecraftServer s) {
        PLAYERS.clear();
        Path f = file(s);
        if (!Files.exists(f)) return;
        JsonObject root;
        try {
            root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
        } catch (IOException | RuntimeException ex) {
            // Never let the next autosave overwrite a file we could not read: keep a copy first.
            UniversalEmc.LOG.error("Failed loading player EMC data", ex);
            backup(f);
            return;
        }
        boolean skipped = false;
        for (Map.Entry<String, JsonElement> e : root.entrySet()) {
            try {
                JsonObject o = e.getValue().getAsJsonObject();
                Player p = new Player();
                p.emc = o.has("emc") ? o.get("emc").getAsLong() : 0;
                if (o.has("discovered")) {
                    for (JsonElement d : o.getAsJsonArray("discovered")) {
                        try { p.discovered.add(class_2960.method_60654(d.getAsString())); } catch (RuntimeException ignored) {}
                    }
                }
                try {
                    if (o.has("home")) p.home = jsonLoc(o.getAsJsonObject("home"));
                    if (o.has("checkpoints")) for (JsonElement c : o.getAsJsonArray("checkpoints")) p.checkpoints.add(jsonLoc(c.getAsJsonObject()));
                } catch (RuntimeException ignored) {}
                try {
                    if (o.has("upgrades")) for (Map.Entry<String, JsonElement> u : o.getAsJsonObject("upgrades").entrySet()) p.upgrades.put(u.getKey(), u.getValue().getAsInt());
                    if (o.has("off")) for (JsonElement x : o.getAsJsonArray("off")) p.off.add(x.getAsString());
                    if (o.has("active")) for (Map.Entry<String, JsonElement> u : o.getAsJsonObject("active").entrySet()) p.active.put(u.getKey(), u.getValue().getAsInt());
                } catch (RuntimeException ignored) {}
                try {
                    if (o.has("protect")) for (JsonElement x : o.getAsJsonArray("protect")) p.protect.add(x.getAsString());
                } catch (RuntimeException ignored) {}
                try {
                    if (o.has("autoSell")) {
                        JsonObject a = o.getAsJsonObject("autoSell");
                        if (a.has("on")) p.autoSell = a.get("on").getAsBoolean();
                        if (a.has("items")) for (JsonElement x : a.getAsJsonArray("items")) p.autoSellItems.add(x.getAsString());
                    }
                } catch (RuntimeException ignored) {}
                try {
                    if (o.has("mineUnlocked")) p.mineUnlocked = o.get("mineUnlocked").getAsBoolean();
                } catch (RuntimeException ignored) {}
                PLAYERS.put(UUID.fromString(e.getKey()), p);
            } catch (RuntimeException ex) {
                // one broken entry must not wipe everybody else
                skipped = true;
                UniversalEmc.LOG.error("Skipping unreadable EMC entry " + e.getKey(), ex);
            }
        }
        if (skipped) backup(f);
    }

    private static void backup(Path f) {
        try {
            Path b = f.resolveSibling("uemc_players.json.broken-" + System.currentTimeMillis());
            Files.copy(f, b, StandardCopyOption.REPLACE_EXISTING);
            UniversalEmc.LOG.warn("Copy of the original EMC data kept at {}", b);
        } catch (IOException ex) {
            UniversalEmc.LOG.error("Could not back up EMC data", ex);
        }
    }

    public static void save(MinecraftServer s) {
        JsonObject root = new JsonObject();
        PLAYERS.forEach((id, p) -> {
            JsonObject o = new JsonObject();
            o.addProperty("emc", p.emc);
            JsonArray a = new JsonArray();
            p.discovered.forEach(i -> a.add(i.toString()));
            o.add("discovered", a);
            if (p.home != null) o.add("home", locJson(p.home));
            JsonArray cps = new JsonArray();
            p.checkpoints.forEach(l -> cps.add(locJson(l)));
            o.add("checkpoints", cps);
            JsonObject ups = new JsonObject();
            p.upgrades.forEach(ups::addProperty);
            o.add("upgrades", ups);
            JsonArray offs = new JsonArray();
            p.off.forEach(offs::add);
            o.add("off", offs);
            JsonObject act = new JsonObject();
            p.active.forEach(act::addProperty);
            o.add("active", act);
            JsonArray prot = new JsonArray();
            p.protect.forEach(prot::add);
            o.add("protect", prot);
            JsonObject autoSell = new JsonObject();
            autoSell.addProperty("on", p.autoSell);
            JsonArray autoItems = new JsonArray();
            p.autoSellItems.forEach(autoItems::add);
            autoSell.add("items", autoItems);
            o.add("autoSell", autoSell);
            o.addProperty("mineUnlocked", p.mineUnlocked);
            root.add(id.toString(), o);
        });
        try {
            Path f = file(s), tmp = f.resolveSibling("uemc_players.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            try {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING);   // some file systems cannot move atomically
            }
        } catch (IOException ex) {
            UniversalEmc.LOG.error("Failed saving player EMC data", ex);
        }
    }
}

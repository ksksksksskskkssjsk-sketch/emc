package com.uemc.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

/**
 * Mine Portal. Right-click in the Overworld: first time it unlocks the Mine World (Fees.MINE_COST[0] EMC, one time),
 * after that it is free. Right-click inside the Mine World: back to where you came from (free).
 */
public class MinePortalBlock extends class_2248 {
    public static final MapCodec<MinePortalBlock> CODEC = method_54094(MinePortalBlock::new);

    public MinePortalBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() { return CODEC; }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.method_8608()) return class_1269.field_5812;
        if (player instanceof class_3222 sp) com.uemc.emc.Services.portalUse(sp);
        return class_1269.field_5812;
    }
}

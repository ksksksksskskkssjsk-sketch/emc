package com.uemc.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** What the server last told us about this player's Auto-Sell list. */
public final class ClientAutoSell {
    private ClientAutoSell() {}

    public static volatile boolean on = false;
    public static volatile List<String> ids = new ArrayList<>();

    public static void set(boolean o, List<String> list) {
        List<String> c = new ArrayList<>(list);
        Collections.sort(c);
        ids = c;
        on = o;
    }

    public static boolean has(String id) { return ids.contains(id); }

    public static void clear() { on = false; ids = new ArrayList<>(); }
}

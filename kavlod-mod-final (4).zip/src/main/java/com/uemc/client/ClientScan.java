package com.uemc.client;

import com.uemc.net.OreScanPayload;

/** The last Ore Scanner result the server sent. */
public final class ClientScan {
    private ClientScan() {}

    public static volatile OreScanPayload last = null;

    public static void clear() { last = null; }
}

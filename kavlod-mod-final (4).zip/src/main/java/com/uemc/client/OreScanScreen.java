package com.uemc.client;

import com.uemc.emc.OreGroups;
import com.uemc.net.ActionPayload;
import com.uemc.net.OreScanPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.List;

/**
 * Ore Scanner (Tablet > Services). Pick a range, then an ore: the server charges EMC, looks at the blocks around you
 * and sends back a radar. White dot = you, north is up, coloured dots = that ore. The bar next to the radar shows how
 * high or low the ore is compared to you. The list shows the nearest separate spots with real coordinates.
 */
public class OreScanScreen extends ServiceScreen {
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static final int RS = 88;

    private record Icon(GlowButton b, String id, float scale) {}

    private final Runnable onBack;
    private final GlowButton[] range = new GlowButton[OreGroups.RADIUS.length];
    private final GlowButton[] ore = new GlowButton[OreGroups.ALL.length];
    private final List<Icon> icons = new ArrayList<>();
    private int size = 0, ticks = 0;

    public OreScanScreen(Runnable onBack) {
        super("ORE SCANNER");
        this.onBack = onBack;
        W = 304;
        H = 244;
    }

    private static String compact(long v) { return v >= 1000 ? (v / 100) / 10.0 + "k" : String.valueOf(v); }

    @Override
    protected void method_25426() {
        super.method_25426();
        icons.clear();
        for (int i = 0; i < range.length; i++) {
            final int k = i;
            GlowButton b = GlowButton.of(OreGroups.RADIUS[i] + " blocks  " + compact(OreGroups.COST[i]), left + 10 + i * 96, top + 36, 92, 18, bb -> { size = k; refresh(); });
            b.accent = Fx.CYAN;
            b.method_47400(class_7919.method_47407(class_2561.method_43470("Scan " + OreGroups.RADIUS[i] + " blocks around you.\nCosts " + Fx.num(OreGroups.COST[i]) + " EMC per scan.")));
            range[i] = b;
            method_37063(b);
        }
        for (int i = 0; i < ore.length; i++) {
            OreGroups.Group g = OreGroups.ALL[i];
            GlowButton b = GlowButton.of(g.name(), left + 10 + (i % 4) * 73, top + 62 + (i / 4) * 22, 70, 20,
                    bb -> ClientPlayNetworking.send(new ActionPayload(70, g.id(), size)));
            b.accent = g.color();
            ore[i] = b;
            method_37063(b);
            icons.add(new Icon(b, g.icon(), 0.55f));
        }
        GlowButton back = GlowButton.of("Back", left + 10, top + H - 22, 56, 16, b -> onBack.run());
        back.accent = Fx.CYAN;
        method_37063(back);
        refresh();
    }

    /** Updates the range chips, the ore buttons (greyed out when you cannot pay) and their tooltips. */
    public void refresh() {
        long cost = OreGroups.COST[size];
        for (int i = 0; i < range.length; i++) if (range[i] != null) range[i].selected = i == size;
        for (int i = 0; i < ore.length; i++) {
            GlowButton b = ore[i];
            if (b == null) continue;
            b.field_22763 = ClientEmc.balance >= cost;
            b.method_47400(class_7919.method_47407(class_2561.method_43470("Scan " + OreGroups.RADIUS[size] + " blocks for " + OreGroups.ALL[i].name()
                    + "\nCosts " + Fx.num(cost) + " EMC")));
        }
    }

    @Override
    public void method_25393() {
        if (++ticks % 5 == 0) refresh();
    }

    private static String dir(int dx, int dz) {
        double deg = Math.toDegrees(Math.atan2(dx, -dz));   // 0 = north, 90 = east
        int i = (int) Math.round(deg / 45.0);
        return DIRS[((i % 8) + 8) % 8];
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        txt(ctx, "RANGE", left + 10, top + 24, 0xFF7A8A99);
        for (Icon i : icons) {
            GlowButton b = i.b();
            Icons.draw(ctx, i.id(), b.method_46426() + 8, b.method_46427() + b.method_25364() / 2f, i.scale());
        }

        int rx = left + 10, ry = top + 130, cx = rx + RS / 2, cy = ry + RS / 2;
        int sx = rx + RS + 4;
        ctx.method_25294(rx, ry, rx + RS, ry + RS, Fx.argb(255, 0x05090D));
        ctx.method_25294(rx + 1, ry + 1, rx + RS - 1, ry + RS - 1, Fx.argb(255, 0x0A141A));
        ctx.method_25294(rx, cy, rx + RS, cy + 1, Fx.argb(50, Fx.CYAN));
        ctx.method_25294(cx, ry, cx + 1, ry + RS, Fx.argb(50, Fx.CYAN));
        Fx.circle(ctx, cx, cy, 43, Fx.argb(110, Fx.CYAN));
        Fx.circle(ctx, cx, cy, 21, Fx.argb(60, Fx.CYAN));
        ctx.method_25294(sx, ry, sx + 8, ry + RS, Fx.argb(255, 0x0A141A));

        OreScanPayload r = ClientScan.last;
        OreGroups.Group g = r == null ? null : OreGroups.find(r.group());
        int radius = r == null ? 1 : OreGroups.RADIUS[Math.max(0, Math.min(r.size(), OreGroups.RADIUS.length - 1))];
        if (r != null && g != null) {
            double sc = 42.0 / radius;
            List<Integer> b = r.blips();
            for (int i = 0; i + 2 < b.size(); i += 3) {
                int dx = b.get(i), dy = b.get(i + 1), dz = b.get(i + 2);
                int px = cx + (int) Math.round(dx * sc), py = cy + (int) Math.round(dz * sc);
                if (px >= rx + 1 && px <= rx + RS - 3 && py >= ry + 1 && py <= ry + RS - 3)
                    ctx.method_25294(px, py, px + 2, py + 2, Fx.argb(255, g.color()));
                int yy = cy - (int) Math.round(dy * sc);
                if (yy >= ry + 1 && yy <= ry + RS - 2) ctx.method_25294(sx, yy, sx + 8, yy + 1, Fx.argb(170, g.color()));
            }
        }
        ctx.method_25294(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        ctx.method_25294(sx - 1, cy, sx + 9, cy + 1, 0xFFFFFFFF);
        txt(ctx, "N", cx - 2, ry + 2, GREY);

        int lx = left + 118, ly = top + 130, lw = W - 118 - 10;
        if (r == null || g == null) {
            txt(ctx, "Pick a range, then an ore.", lx, ly, WHITE);
            txt(ctx, "Each scan costs EMC.", lx, ly + 12, GREY);
            txt(ctx, "Shows nearby ore on a radar", lx, ly + 28, GREY);
            txt(ctx, "with real coordinates.", lx, ly + 40, GREY);
        } else {
            txt(ctx, g.name() + ": " + Fx.num(r.total()) + " within " + radius, lx, ly, 0xFF000000 | g.color());
            List<Integer> n = r.near();
            if (r.total() == 0) {
                txt(ctx, "Nothing found. Try a bigger", lx, ly + 14, GREY);
                txt(ctx, "range or walk somewhere new.", lx, ly + 26, GREY);
            } else {
                txt(ctx, "Nearest spots:", lx, ly + 12, 0xFF7A8A99);
                for (int i = 0, line = 0; i + 2 < n.size() && line < 5; i += 3, line++) {
                    int dx = n.get(i), dy = n.get(i + 1), dz = n.get(i + 2);
                    long dist = Math.round(Math.sqrt((double) dx * dx + (double) dy * dy + (double) dz * dz));
                    String left1 = dist + "m " + dir(dx, dz) + (dy == 0 ? " level" : "  " + Math.abs(dy) + (dy > 0 ? " up" : " down"));
                    String coords = (r.ox() + dx) + " " + (r.oy() + dy) + " " + (r.oz() + dz);
                    int yy = ly + 24 + line * 11;
                    txt(ctx, left1, lx, yy, WHITE);
                    txt(ctx, coords, lx + lw - field_22793.method_1727(coords), yy, 0xFFFFC040);
                }
            }
        }
        txt(ctx, "White dot = you, top = north.", lx, top + H - 34, 0xFF7A8A99);
        txt(ctx, "Side bar = height, line = you.", lx, top + H - 22, 0xFF7A8A99);
    }
}

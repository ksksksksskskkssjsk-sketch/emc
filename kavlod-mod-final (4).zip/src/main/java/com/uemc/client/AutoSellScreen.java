package com.uemc.client;

import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

/**
 * Auto-Sell options (opened from the Sell menu). Click any stack in your inventory to put that item type on the list
 * (click again to take it off). Listed items are sold the moment they are in your inventory.
 * Presets add whole groups. Tools and enchanted gear are never sold. The server keeps the list and does the selling.
 */
public class AutoSellScreen extends ServiceScreen {
    private static final int LIST_COLS = 15, LIST_ROWS = 2, CARD_W = 62, CARD_H = 74;

    private record Icon(GlowButton b, String id, float scale) {}

    private final Runnable onBack;
    private final GlowButton[] cell = new GlowButton[36];
    private final GlowButton[] slot = new GlowButton[LIST_COLS * LIST_ROWS];
    private final List<Icon> icons = new ArrayList<>();
    private GlowButton power;
    private int ticks = 0, hash = 0;
    private boolean synced = false;

    public AutoSellScreen(Runnable onBack) {
        super("AUTO-SELL");
        this.onBack = onBack;
        W = 330;
        H = 220;
        accent = Fx.GOLD;
    }

    // ---------- helpers ----------
    private class_1799 stack(int s) {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_31548().method_5438(s);
    }

    private static String idOf(class_1799 st) { return class_7923.field_41178.method_10221(st.method_7909()).toString(); }

    /** Only plain stacks with an EMC value can be auto-sold: no tools, no enchanted gear. */
    private boolean pickable(class_1799 st) {
        return !st.method_7960() && ClientEmc.unit(st) > 0 && !st.method_7942() && !st.method_7963();
    }

    private int cellX(int s) { return left + 8 + (s < 9 ? s : (s - 9) % 9) * 18; }
    private int cellY(int s) { return s < 9 ? top + 96 : top + 38 + ((s - 9) / 9) * 18; }

    private static void send(int action, String item) { ClientPlayNetworking.send(new ActionPayload(action, item, 0)); }

    private void pick(int s) {
        class_1799 st = stack(s);
        if (pickable(st)) send(44, idOf(st));
    }

    private void removeAt(int i) {
        List<String> ids = ClientAutoSell.ids;
        if (i >= 0 && i < ids.size()) send(44, ids.get(i));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        icons.clear();
        if (!synced) { synced = true; send(46, ""); }

        for (int s = 0; s < 36; s++) {
            final int sl = s;
            GlowButton b = GlowButton.slot(cellX(s), cellY(s), x -> pick(sl));
            b.accent = Fx.GOLD;
            cell[s] = b;
            method_37063(b);
        }

        int rx = left + 176;
        power = side("Auto-Sell", "Switch Auto-Sell on or off. Your list is kept while it is off.", rx, top + 38, "minecraft:comparator", () -> send(43, ""));
        side("Add ores", "Add every ore drop: coal, raw metals, redstone, lapis, diamond, emerald, quartz, debris...", rx, top + 57, "minecraft:diamond", () -> send(45, "ores"));
        side("Add junk", "Add cave junk: cobblestone, deepslate, dirt, gravel, stones, netherrack, rotten flesh", rx, top + 76, "minecraft:cobblestone", () -> send(45, "junk"));
        side("Clear list", "Take everything off the Auto-Sell list", rx, top + 95, "minecraft:barrier", () -> send(45, "clear"));

        for (int i = 0; i < slot.length; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % LIST_COLS) * 20, top + 148 + (i / LIST_COLS) * 20, x -> removeAt(idx));
            b.accent = Fx.GREEN;
            slot[i] = b;
            method_37063(b);
        }

        GlowButton back = GlowButton.of("Back", left + 8, top + 196, 56, 18, b -> onBack.run());
        back.accent = Fx.GOLD;
        method_37063(back);
        icons.add(new Icon(back, "minecraft:arrow", 0.7f));
        refresh();
    }

    private GlowButton side(String label, String tip, int x, int y, String icon, Runnable r) {
        GlowButton b = GlowButton.of(label, x, y, 78, 16, bb -> r.run());
        b.accent = Fx.GOLD;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        icons.add(new Icon(b, icon, 0.55f));
        return b;
    }

    /** Re-reads the inventory and the list: enables the clickable stacks, marks the listed ones, fills tooltips. */
    public void refresh() {
        List<String> ids = ClientAutoSell.ids;
        for (int s = 0; s < 36; s++) {
            GlowButton b = cell[s];
            if (b == null) continue;
            class_1799 st = stack(s);
            boolean ok = pickable(st);
            b.field_22763 = ok;
            b.selected = ok && ClientAutoSell.has(idOf(st));
            if (st.method_7960()) { b.method_47400(null); continue; }
            String tip = st.method_7964().getString();
            if (ClientEmc.unit(st) <= 0) tip += "\nNo EMC value";
            else if (st.method_7942() || st.method_7963()) tip += "\nTools and enchanted gear are never auto-sold";
            else tip += ClientAutoSell.has(idOf(st)) ? "\nOn the list: click to remove" : "\nClick to auto-sell this item";
            b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        }
        for (int i = 0; i < slot.length; i++) {
            GlowButton b = slot[i];
            if (b == null) continue;
            boolean has = i < ids.size();
            b.field_22763 = has;
            if (has) {
                class_1799 st = Icons.stack(ids.get(i));
                String name = st.method_7960() ? ids.get(i) : st.method_7964().getString();
                b.method_47400(class_7919.method_47407(class_2561.method_43470(name + "\nClick to remove")));
            } else {
                b.method_47400(null);
            }
        }
        if (power != null) {
            power.method_25355(class_2561.method_43470(ClientAutoSell.on ? "Auto-Sell: ON" : "Auto-Sell: OFF"));
            power.selected = ClientAutoSell.on;
            power.accent = ClientAutoSell.on ? Fx.GREEN : Fx.RED;
        }
    }

    @Override
    public void method_25393() {
        if (++ticks % 5 != 0) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        int h = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 s = stack(i);
            h = h * 31 + (s.method_7960() ? 0 : s.method_7947() + s.method_7909().hashCode() + s.method_7919());
        }
        if (h != hash) { hash = h; refresh(); }
    }

    // ---------- drawing ----------
    private void tiny(class_332 c, String s, int cx, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.75f, 0.75f);
        int w = field_22793.method_1727(s);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (cx / 0.75f - w / 2f), (int) (y / 0.75f), color, false);
        m.popMatrix();
    }

    private void drawCard(class_332 ctx, int x0, int y0) {
        int cx = x0 + CARD_W / 2;
        boolean on = ClientAutoSell.on;
        int col = on ? Fx.GREEN : Fx.RED;
        ctx.method_25294(x0, y0, x0 + CARD_W, y0 + CARD_H, Fx.argb(255, 0x05090D));
        ctx.method_25296(x0 + 1, y0 + 1, x0 + CARD_W - 1, y0 + CARD_H - 1, Fx.argb(255, 0x1A2630), Fx.argb(255, 0x0E151C));
        Fx.ring(ctx, x0, y0, CARD_W, CARD_H, Fx.argb(130, col));
        Icons.draw(ctx, "minecraft:hopper", cx, y0 + 24, 1.6f);
        tiny(ctx, on ? "ACTIVE" : "OFF", cx, y0 + 46, on ? 0xFF40FF80 : 0xFFFF7070);
        int n = ClientAutoSell.ids.size();
        tiny(ctx, n + (n == 1 ? " item" : " items"), cx, y0 + 58, GREY);
        tiny(ctx, "on the list", cx, y0 + 66, GREY);
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        float now = Fx.t();
        txt(ctx, "Click items to sell them automatically on pickup.", left + 8, top + 24, GREY);

        for (int s = 0; s < 36; s++) {
            class_1799 st = stack(s);
            if (st.method_7960()) continue;
            int x = cellX(s) + 1, y = cellY(s) + 1;
            float appear = Fx.ease((now - openT) * 4f - ((s % 9) + (s / 9)) * 0.04f);
            boolean listed = ClientAutoSell.has(idOf(st)) && pickable(st);
            Fx.item(ctx, st, x, y, cell[s] != null && cell[s].method_49606(), listed, appear, Fx.GREEN);
            if (appear < 0.9f) continue;
            if (!pickable(st)) ctx.method_25294(x, y, x + 16, y + 16, 0xAA101820);
            if (listed) ctx.method_25294(x, y, x + 3, y + 3, Fx.argb(255, Fx.GREEN));
            if (st.method_7947() > 1) {
                String cnt = String.valueOf(st.method_7947());
                txt(ctx, cnt, x + 17 - field_22793.method_1727(cnt), y + 9, WHITE);
            }
        }

        for (Icon i : icons) {
            GlowButton b = i.b();
            Icons.draw(ctx, i.id(), b.method_46426() + 8, b.method_46427() + b.method_25364() / 2f, i.scale());
        }

        drawCard(ctx, left + 260, top + 38);

        List<String> ids = ClientAutoSell.ids;
        String status = ClientAutoSell.on
                ? (ids.isEmpty() ? "ON, but the list is empty" : "ON: listed items sell as you pick them up")
                : "OFF: nothing is sold automatically";
        txt(ctx, status, left + 8, top + 120, ClientAutoSell.on && !ids.isEmpty() ? 0xFF40FF80 : 0xFFFFB060);
        txt(ctx, "Your list (click an item to remove it):", left + 8, top + 134, GREY);

        for (int i = 0; i < slot.length && i < ids.size(); i++) {
            class_1799 st = Icons.stack(ids.get(i));
            if (!st.method_7960()) Fx.itemScaled(ctx, st, slot[i].method_46426() + 9, slot[i].method_46427() + 9, 1f);
        }
        if (ids.isEmpty()) txt(ctx, "Nothing yet. Click items above or use a preset.", left + 8, top + 152, GREY);
        else if (ids.size() > slot.length) txt(ctx, "+" + (ids.size() - slot.length) + " more", left + 8 + LIST_COLS * 20 - 40, top + 188, GREY);
        txt(ctx, "Tools and enchanted gear are never sold.", left + 70, top + 200, 0xFF7A8A99);
    }
}

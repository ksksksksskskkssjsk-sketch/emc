@echo off
REM Builds the mod. Output jar: dist\
REM Needs: Java 21+. Gradle is downloaded automatically if there is no wrapper.
setlocal
cd /d "%~dp0"
set GRADLE_VERSION=9.2.1

where java >nul 2>nul || (echo Install Java 21 first: https://adoptium.net & pause & exit /b 1)

if not exist gradlew.bat (
  where gradle >nul 2>nul
  if %errorlevel%==0 (
    set G=gradle
  ) else (
    echo ==^> Downloading Gradle %GRADLE_VERSION%
    if not exist .gradle-dist mkdir .gradle-dist
    powershell -NoProfile -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile .gradle-dist\g.zip; Expand-Archive -Force .gradle-dist\g.zip .gradle-dist"
    set G=.gradle-dist\gradle-%GRADLE_VERSION%\bin\gradle.bat
  )
  call %G% wrapper --gradle-version %GRADLE_VERSION% || (pause & exit /b 1)
)

call gradlew.bat build --console=plain || (echo BUILD FAILED & pause & exit /b 1)

if exist dist rmdir /s /q dist
mkdir dist
copy build\libs\*.jar dist\ >nul
del dist\*-sources.jar 2>nul
echo.
echo Done. Jar is in: %cd%\dist
dir /b dist
pause

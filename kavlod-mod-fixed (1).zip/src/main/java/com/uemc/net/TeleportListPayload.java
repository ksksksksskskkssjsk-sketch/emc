package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: home + checkpoints. If hasHome, entry 0 is the home. coords = x,y,z per entry. */
public record TeleportListPayload(boolean hasHome, List<String> names, List<String> dims, List<Double> coords) implements class_8710 {
    public static final class_8710.class_9154<TeleportListPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "tp_list"));

    public static final class_9139<class_9129, TeleportListPayload> CODEC = new class_9139<>() {
        @Override
        public TeleportListPayload decode(class_9129 buf) {
            boolean h = buf.readBoolean();
            int n = buf.method_10816();
            List<String> names = new ArrayList<>(), dims = new ArrayList<>();
            List<Double> co = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                names.add(buf.method_10800(64));
                dims.add(buf.method_10800(128));
                co.add(buf.readDouble()); co.add(buf.readDouble()); co.add(buf.readDouble());
            }
            return new TeleportListPayload(h, names, dims, co);
        }

        @Override
        public void encode(class_9129 buf, TeleportListPayload p) {
            buf.method_52964(p.hasHome);
            buf.method_10804(p.names.size());
            for (int i = 0; i < p.names.size(); i++) {
                buf.method_10814(p.names.get(i));
                buf.method_10814(p.dims.get(i));
                buf.method_52940(p.coords.get(i * 3)); buf.method_52940(p.coords.get(i * 3 + 1)); buf.method_52940(p.coords.get(i * 3 + 2));
            }
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> server: which(1 enchanting table, 8 EMC shop). */
public record MenuActionPayload(long pos, int which) implements class_8710 {
    public static final class_8710.class_9154<MenuActionPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "menu_action"));
    public static final class_9139<class_9129, MenuActionPayload> CODEC = new class_9139<>() {
        @Override public MenuActionPayload decode(class_9129 buf) { return new MenuActionPayload(buf.readLong(), buf.method_10816()); }
        @Override public void encode(class_9129 buf, MenuActionPayload p) { buf.method_52974(p.pos); buf.method_10804(p.which); }
    };
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

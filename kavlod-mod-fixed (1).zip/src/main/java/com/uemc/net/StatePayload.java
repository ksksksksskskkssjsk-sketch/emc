package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: player's EMC balance and discovered items with values. */
public record StatePayload(long emc, int total, List<String> ids, List<Long> values, List<Long> slots) implements class_8710 {
    public static final class_8710.class_9154<StatePayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "state"));

    public static final class_9139<class_9129, StatePayload> CODEC = new class_9139<>() {
        @Override
        public StatePayload decode(class_9129 buf) {
            long emc = buf.readLong();
            int total = buf.method_10816();
            int n = buf.method_10816();
            List<String> ids = new ArrayList<>(n);
            List<Long> vals = new ArrayList<>(n);
            for (int i = 0; i < n; i++) { ids.add(buf.method_19772()); vals.add(buf.readLong()); }
            int m = buf.method_10816();
            List<Long> slots = new ArrayList<>(m);
            for (int i = 0; i < m; i++) slots.add(buf.readLong());
            return new StatePayload(emc, total, ids, vals, slots);
        }

        @Override
        public void encode(class_9129 buf, StatePayload p) {
            buf.method_52974(p.emc);
            buf.method_10804(p.total);
            buf.method_10804(p.ids.size());
            for (int i = 0; i < p.ids.size(); i++) { buf.method_10814(p.ids.get(i)); buf.method_52974(p.values.get(i)); }
            buf.method_10804(p.slots.size());
            for (long s : p.slots) buf.method_52974(s);
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

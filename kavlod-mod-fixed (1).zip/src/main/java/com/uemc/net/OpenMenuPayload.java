package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: open the converter menu for the block at pos. */
public record OpenMenuPayload(long pos) implements class_8710 {
    public static final class_8710.class_9154<OpenMenuPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "open_menu"));
    public static final class_9139<class_9129, OpenMenuPayload> CODEC = new class_9139<>() {
        @Override public OpenMenuPayload decode(class_9129 buf) { return new OpenMenuPayload(buf.readLong()); }
        @Override public void encode(class_9129 buf, OpenMenuPayload p) { buf.method_52974(p.pos); }
    };
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: running time speed (index into Fees.SPEED_X, 0 = normal). */
public record TimeStatePayload(int speed) implements class_8710 {
    public static final class_8710.class_9154<TimeStatePayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "time_state"));
    public static final class_9139<class_9129, TimeStatePayload> CODEC = new class_9139<>() {
        @Override public TimeStatePayload decode(class_9129 buf) { return new TimeStatePayload(buf.method_10816()); }
        @Override public void encode(class_9129 buf, TimeStatePayload p) { buf.method_10804(p.speed); }
    };
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

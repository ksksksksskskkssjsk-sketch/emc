package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> server. action 1 = buy(item,count), 2 = convert offhand stack. */
public record ActionPayload(int action, String item, int count) implements class_8710 {
    public static final class_8710.class_9154<ActionPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "action"));

    public static final class_9139<class_9129, ActionPayload> CODEC = new class_9139<>() {
        @Override
        public ActionPayload decode(class_9129 buf) {
            return new ActionPayload(buf.method_10816(), buf.method_10800(256), buf.method_10816());
        }

        @Override
        public void encode(class_9129 buf, ActionPayload p) {
            buf.method_10804(p.action);
            buf.method_10814(p.item);
            buf.method_10804(p.count);
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

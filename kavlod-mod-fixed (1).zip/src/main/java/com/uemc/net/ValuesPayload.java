package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: every item's EMC value, sent on join so tooltips work everywhere. */
public record ValuesPayload(List<String> ids, List<Long> values) implements class_8710 {
    public static final class_8710.class_9154<ValuesPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "values"));

    public static final class_9139<class_9129, ValuesPayload> CODEC = new class_9139<>() {
        @Override
        public ValuesPayload decode(class_9129 buf) {
            int n = buf.method_10816();
            List<String> ids = new ArrayList<>(n);
            List<Long> vals = new ArrayList<>(n);
            for (int i = 0; i < n; i++) { ids.add(buf.method_19772()); vals.add(buf.method_10792()); }
            return new ValuesPayload(ids, vals);
        }

        @Override
        public void encode(class_9129 buf, ValuesPayload p) {
            buf.method_10804(p.ids.size());
            for (int i = 0; i < p.ids.size(); i++) { buf.method_10814(p.ids.get(i)); buf.method_10791(p.values.get(i)); }
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

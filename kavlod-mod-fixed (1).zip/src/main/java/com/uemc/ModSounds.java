package com.uemc;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ModSounds {
    public static final class_3414 CONVERTER_START = reg("converter_start");
    public static final class_3414 CONVERTER_DONE = reg("converter_done");
    public static final class_3414 SCANNER_SCAN = reg("scanner_scan");
    public static final class_3414 TABLET_OPEN = reg("tablet_open");
    public static final class_3414 EMC_TRANSACT = reg("emc_transact");

    private static class_3414 reg(String n) {
        class_2960 id = class_2960.method_60655(UniversalEmc.ID, n);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void init() {}
}

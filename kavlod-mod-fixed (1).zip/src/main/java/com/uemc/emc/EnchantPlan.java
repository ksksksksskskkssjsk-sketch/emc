package com.uemc.emc;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * "Max everything" plan for one item: every enchant that fits, at its top level (X, or I for single-level ones).
 * Enchants already on the item win conflicts, then a priority order (Mending, Unbreaking, Sharpness, Protection...),
 * then A-Z. Curses are never added. Client (price preview) and server (real charge) both call this, so they always agree.
 */
public final class EnchantPlan {
    public record Entry(class_6880<class_1887> ref, String id, String name, int level, long fee) {}

    private record Cand(class_6880<class_1887> ref, String id, String name, int max) {}

    private static final List<String> FIRST = List.of("mending", "unbreaking", "sharpness", "protection", "power", "efficiency",
            "fortune", "looting", "sweeping_edge", "feather_falling", "respiration", "aqua_affinity", "depth_strider",
            "impaling", "quick_charge", "lure", "luck_of_the_sea");

    public final List<Entry> entries = new ArrayList<>();
    public long fee = 0;

    private EnchantPlan() {}

    private static int rank(String id) {
        int i = FIRST.indexOf(id.substring(id.indexOf(':') + 1));
        return i < 0 ? 100 : i;
    }

    public static EnchantPlan make(class_2378<class_1887> reg, class_1799 st) {
        EnchantPlan plan = new EnchantPlan();
        if (st.method_7960()) return plan;
        List<Cand> cand = new ArrayList<>();
        reg.method_42017().forEach(ref -> {
            class_1887 en = ref.comp_349();
            String id = ref.method_40237().method_29177().toString();
            if (id.contains("curse") || !en.method_8192(st)) return;
            cand.add(new Cand(ref, id, en.comp_2686().getString(), Fees.maxLevel(en.method_8183())));
        });
        cand.sort(Comparator.comparingInt((Cand c) -> rank(c.id())).thenComparing(Cand::id));

        class_9304 cur = class_1890.method_57532(st);
        List<class_6880<class_1887>> chosen = new ArrayList<>();
        for (class_6880<class_1887> o : cur.method_57534()) chosen.add(o);
        for (Cand c : cand) {
            int have = cur.method_57536(c.ref());
            if (have >= c.max()) continue;
            boolean clash = false;
            for (class_6880<class_1887> o : chosen)
                if (!o.equals(c.ref()) && !class_1887.method_60033(c.ref(), o)) { clash = true; break; }
            if (clash) continue;
            if (!chosen.contains(c.ref())) chosen.add(c.ref());
            long f = Fees.enchant(c.max()) - Fees.enchant(have);
            plan.entries.add(new Entry(c.ref(), c.id(), c.name(), c.max(), f));
            plan.fee += f;
        }
        return plan;
    }

    /** True if at least one enchant can go on this stack. */
    public static boolean fits(class_2378<class_1887> reg, class_1799 st) {
        if (st.method_7960()) return false;
        boolean[] ok = {false};
        reg.method_42017().forEach(ref -> { if (!ok[0] && ref.comp_349().method_8192(st)) ok[0] = true; });
        return ok[0];
    }
}

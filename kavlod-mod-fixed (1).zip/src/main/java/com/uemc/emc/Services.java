package com.uemc.emc;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_12279;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/** Tablet upgrades: chosen enchants (up to X), repair, teleports, time + weather. All paid in EMC, all server-side. */
public final class Services {
    private Services() {}

    private static final Map<UUID, class_3218> WORLDS = new HashMap<>();

    private static MinecraftServer SERVER;
    private static MinecraftServer server() { return SERVER; }

    public static void init() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> { SERVER = s; recoverGrowth(s); });
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPING.register(s -> stopSpeed(s, null));
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> { SERVER = null; WORLDS.clear(); timeLeft = 0; timeWorld = null; speedIdx = 0; speedPayer = null; lastWeather = -1000; });
        ServerTickEvents.END_SERVER_TICK.register(Services::timeTick);
    }

    public static void rememberWorld(class_3222 p, class_3218 w) { WORLDS.put(p.method_5667(), w); }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    private static boolean pay(class_3222 p, long fee) {
        if (EmcData.add(p.method_5667(), -fee)) return true;
        msg(p, "Not enough EMC (need " + fee + ")");
        return false;
    }

    private static class_3218 worldOf(class_3222 p) {
        for (class_3218 w : server().method_3738()) if (w.method_18470(p.method_5667()) != null) return w;
        return WORLDS.getOrDefault(p.method_5667(), server().method_30002());
    }

    // ---------- home + checkpoints ----------
    private static final Map<UUID, Integer> TP_LAST = new HashMap<>();

    private static EmcData.Loc here(class_3222 p, String name) {
        return new EmcData.Loc(name, worldOf(p).method_27983().method_29177().toString(),
                p.method_23317(), p.method_23318(), p.method_23321(), p.method_36454(), p.method_36455());
    }

    public static void sendTp(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<String> names = new ArrayList<>(), dims = new ArrayList<>();
        List<Double> co = new ArrayList<>();
        List<EmcData.Loc> all = new ArrayList<>();
        if (d.home != null) all.add(d.home);
        all.addAll(d.checkpoints);
        for (EmcData.Loc l : all) { names.add(l.name()); dims.add(l.dim()); co.add(l.x()); co.add(l.y()); co.add(l.z()); }
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.uemc.net.TeleportListPayload(d.home != null, names, dims, co));
    }

    public static void tpSetHome(class_3222 p) {
        EmcData.get(p.method_5667()).home = here(p, "Home");
        msg(p, "Home set here");
        sendTp(p);
    }

    public static void tpAdd(class_3222 p, String raw) {
        EmcData.Player d = EmcData.get(p.method_5667());
        if (d.checkpoints.size() >= Fees.MAX_CHECKPOINTS) { msg(p, "Max " + Fees.MAX_CHECKPOINTS + " checkpoints"); return; }
        String name = raw == null ? "" : raw.replaceAll("[^\\x20-\\x7E]", "").trim();
        if (name.length() > 20) name = name.substring(0, 20);
        if (name.isEmpty()) name = "Checkpoint " + (d.checkpoints.size() + 1);
        if (!pay(p, Fees.CHECKPOINT)) return;
        d.checkpoints.add(here(p, name));
        msg(p, "Checkpoint \"" + name + "\" saved");
        sendTp(p);
    }

    public static void tpDelete(class_3222 p, int idx) {
        EmcData.Player d = EmcData.get(p.method_5667());
        if (idx < 0 || idx >= d.checkpoints.size()) return;
        d.checkpoints.remove(idx);
        sendTp(p);
    }

    /** idx -1 = home, otherwise checkpoint index. */
    public static void tpGo(class_3222 p, int idx) {
        EmcData.Player d = EmcData.get(p.method_5667());
        EmcData.Loc l = idx < 0 ? d.home : (idx < d.checkpoints.size() ? d.checkpoints.get(idx) : null);
        if (l == null) { msg(p, idx < 0 ? "No home set" : "No such checkpoint"); return; }
        int now = server().method_3780();
        Integer last = TP_LAST.get(p.method_5667());
        if (last != null && now - last < Fees.TP_COOLDOWN_TICKS && now >= last) { msg(p, "Teleport cooling down"); return; }
        class_3218 dest = null;
        for (class_3218 w : server().method_3738()) if (w.method_27983().method_29177().toString().equals(l.dim())) dest = w;
        if (dest == null) { msg(p, "That dimension is not available"); return; }
        class_3218 cur = worldOf(p);
        boolean same = cur == dest;
        double dist = same ? Math.sqrt(p.method_5649(l.x(), l.y(), l.z())) : 0;
        long fee = Fees.tp(same, dist);
        if (!pay(p, fee)) return;
        cur.method_65096(net.minecraft.class_2398.field_11214, p.method_23317(), p.method_23318() + 1, p.method_23321(), 40, 0.3, 0.6, 0.3, 0.2);
        boolean ok = p.method_48105(dest, l.x(), l.y(), l.z(), java.util.Set.of(), l.yaw(), l.pitch(), true);
        if (!ok) { EmcData.add(p.method_5667(), fee); msg(p, "Teleport failed"); return; }
        TP_LAST.put(p.method_5667(), now);
        dest.method_65096(net.minecraft.class_2398.field_11214, l.x(), l.y() + 1, l.z(), 40, 0.3, 0.6, 0.3, 0.2);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.8f, 0.6f);
        msg(p, "Teleported to " + l.name() + " for " + fee + " EMC");
    }

    // ---------- repair ----------
    private static boolean damaged(class_1799 st) { return !st.method_7960() && st.method_7963() && st.method_7919() > 0; }

    /** Repair the held item (old one-click). */
    public static void repair(class_3222 p) {
        class_1799 st = p.method_6047();
        if (!damaged(st)) { msg(p, "Hold a damaged item"); return; }
        long fee = Fees.repairFee(st.method_7919());
        if (!pay(p, fee)) return;
        st.method_7974(0);
        msg(p, "Repaired for " + fee + " EMC");
    }

    /** Repair one inventory / armor / offhand slot (0-40). */
    public static void repairSlot(class_3222 p, int slot) {
        var inv = p.method_31548();
        if (slot < 0 || slot >= inv.method_5439()) return;
        class_1799 st = inv.method_5438(slot);
        if (!damaged(st)) { msg(p, "Nothing to repair"); return; }
        long fee = Fees.repairFee(st.method_7919());
        if (!pay(p, fee)) return;
        st.method_7974(0);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.4f);
        msg(p, "Repaired for " + fee + " EMC");
    }

    /** Repair every damaged item the player carries (all or nothing). */
    public static void repairAll(class_3222 p) {
        var inv = p.method_31548();
        long fee = 0;
        int n = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 st = inv.method_5438(i);
            if (damaged(st)) { fee += Fees.repairFee(st.method_7919()); n++; }
        }
        if (n == 0) { msg(p, "Nothing to repair"); return; }
        if (!pay(p, fee)) return;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 st = inv.method_5438(i);
            if (damaged(st)) st.method_7974(0);
        }
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.4f);
        msg(p, "Repaired " + n + " item" + (n == 1 ? "" : "s") + " for " + fee + " EMC");
    }

    /** Switch Auto-Repair on/off: every damaged item you carry heals itself, paid per durability point in EMC. */
    public static void toggleAutoFix(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        boolean on = d.upgrades.remove("autofix") == null;
        if (on) d.upgrades.put("autofix", 1);
        msg(p, "Auto-Repair " + (on ? "ON: nothing can break (" + Fees.REPAIR_PER_POINT + " EMC per durability point)" : "OFF"));
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.uemc.net.BalancePayload(d.emc, on));
    }

    // ---------- mine worlds ----------
    private static final String[] MINE_IDS = {"uemc:mine_overworld", "uemc:mine_nether", "uemc:mine_end"};
    private static final String[] MINE_NAMES = {"Mine World", "Nether Mine", "End Mine"};
    private static final Map<UUID, EmcData.Loc> MINE_BACK = new HashMap<>();

    private static class_3218 dimension(String id) {
        for (class_3218 w : server().method_3738()) if (w.method_27983().method_29177().toString().equals(id)) return w;
        return null;
    }

    private static boolean isMineDim(String id) { return id.startsWith("uemc:mine_"); }

    /** Finds ground with two free blocks above it, not on liquid or fire. Spirals outward from 0,0. */
    private static net.minecraft.class_2338 safeSpot(class_3218 w, int kind) {
        int hi = kind == 0 ? 225 : kind == 1 ? 118 : 195, lo = kind == 0 ? -58 : kind == 1 ? 6 : 14;
        for (int i = 0; i < 260; i++) {
            int x = (int) Math.round(Math.cos(i * 2.4) * Math.sqrt(i) * 6), z = (int) Math.round(Math.sin(i * 2.4) * Math.sqrt(i) * 6);
            for (int y = hi; y >= lo; y--) {
                if (!w.method_8320(new net.minecraft.class_2338(x, y, z)).method_26215()) continue;
                if (!w.method_8320(new net.minecraft.class_2338(x, y + 1, z)).method_26215()) continue;
                net.minecraft.class_2680 below = w.method_8320(new net.minecraft.class_2338(x, y - 1, z));
                if (below.method_26215()) continue;
                String n = class_7923.field_41175.method_10221(below.method_26204()).method_12832();
                if (n.equals("water") || n.equals("lava") || n.equals("magma_block") || n.contains("fire") || n.equals("bedrock")) continue;
                return new net.minecraft.class_2338(x, y, z);
            }
        }
        return null;
    }

    /** kind 0 = Mine World (caves, ores, water), 1 = Nether Mine, 2 = End Mine. Costs Fees.MINE_ENTRY. */
    public static void mineEnter(class_3222 p, int kind) {
        if (kind < 0 || kind > 2) return;
        class_3218 dest = dimension(MINE_IDS[kind]);
        if (dest == null) { msg(p, MINE_NAMES[kind] + " is not available (restart the world once)"); return; }
        class_3218 cur = worldOf(p);
        String curId = cur.method_27983().method_29177().toString();
        if (curId.equals(MINE_IDS[kind])) { msg(p, "You are already in the " + MINE_NAMES[kind]); return; }
        if (EmcData.get(p.method_5667()).emc < Fees.MINE_COST[kind]) { msg(p, "Not enough EMC (need " + Fees.MINE_COST[kind] + ")"); return; }
        int now = server().method_3780();
        Integer last = TP_LAST.get(p.method_5667());
        if (last != null && now - last < Fees.TP_COOLDOWN_TICKS && now >= last) { msg(p, "Teleport cooling down"); return; }
        net.minecraft.class_2338 spot = safeSpot(dest, kind);
        if (spot == null) { msg(p, "No safe place found in the " + MINE_NAMES[kind] + ", try again"); return; }
        if (!pay(p, Fees.MINE_COST[kind])) return;
        EmcData.Loc back = here(p, "Return");
        boolean ok = p.method_48105(dest, spot.method_10263() + 0.5, spot.method_10264(), spot.method_10260() + 0.5, java.util.Set.of(), p.method_36454(), 0f, true);
        if (!ok) { EmcData.add(p.method_5667(), Fees.MINE_COST[kind]); msg(p, "Teleport failed, EMC refunded"); return; }
        if (!isMineDim(curId)) MINE_BACK.put(p.method_5667(), back);   // remember where you came from (not when hopping between mines)
        TP_LAST.put(p.method_5667(), now);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.8f, 0.5f);
        msg(p, "Welcome to the " + MINE_NAMES[kind] + "  (-" + Fees.MINE_COST[kind] + " EMC)");
    }

    /** Free trip back to where you entered from (or home, or the Overworld). */
    public static void mineLeave(class_3222 p) {
        class_3218 cur = worldOf(p);
        if (!isMineDim(cur.method_27983().method_29177().toString())) { msg(p, "You are not in a mine world"); return; }
        EmcData.Loc l = MINE_BACK.remove(p.method_5667());
        if (l == null) l = EmcData.get(p.method_5667()).home;
        class_3218 dest = l == null ? null : dimension(l.dim());
        double x, y, z;
        float yaw = p.method_36454();
        if (l != null && dest != null) { x = l.x(); y = l.y(); z = l.z(); yaw = l.yaw(); }
        else {
            dest = server().method_30002();
            net.minecraft.class_2338 s = safeSpot(dest, 0);
            if (s == null) { msg(p, "Could not find a way out, try again"); return; }
            x = s.method_10263() + 0.5; y = s.method_10264(); z = s.method_10260() + 0.5;
        }
        if (!p.method_48105(dest, x, y, z, java.util.Set.of(), yaw, 0f, true)) { msg(p, "Teleport failed"); return; }
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.8f, 1.0f);
        msg(p, "Back from the mines");
    }

    // ---------- time skip ----------
    private static class_3218 timeWorld = null;
    private static long timeLeft = 0;

    /** mode = "abs" (value = time of day to reach) or "rel" (value = ticks to add), plus ":fast" (watch it run) or ":instant". */
    public static void timeSkip(class_3222 p, String mode, int value) {
        class_3218 w = server().method_30002();
        if (worldOf(p) != w) { msg(p, "Time only moves in the Overworld"); return; }
        if (timeLeft > 0) { msg(p, "Time is already moving"); return; }
        boolean abs = mode.startsWith("abs"), fast = mode.endsWith(":fast");
        long now = w.method_8532();
        long delta = abs ? Fees.timeDelta(now, value) : value;
        if (delta <= 0) { msg(p, "It is already that time"); return; }
        if (delta > 24000) return;
        long fee = Fees.timeCost(delta);
        if (!pay(p, fee)) return;
        if (fast) { timeWorld = w; timeLeft = delta; }
        else w.method_29199(now + delta);
        msg(p, "Skipping " + (delta / 1000) + "h " + ((delta % 1000) * 60 / 1000) + "m for " + fee + " EMC");
    }

    private static void timeTick(MinecraftServer s) {
        if (speedIdx > 0) speedTick(s);
        if (timeLeft <= 0 || timeWorld == null) return;
        long step = Math.min(timeLeft, Fees.TIME_FAST_STEP);
        timeWorld.method_29199(timeWorld.method_8532() + step);
        timeLeft -= step;
        if (timeLeft <= 0) timeWorld = null;
    }

    // ---------- time speed (runs until stopped) ----------
    // Real speed-up: the server tick rate itself is raised (vanilla "/tick rate"). Everything runs faster:
    // crops, trees, animals (growing + breeding cooldown), furnaces, brewing, eggs, effects, item cooldowns, day/night.
    // Note: the client follows the server tick rate, so the player moves faster too (same as vanilla /tick rate).
    private static int speedIdx = 0;
    private static UUID speedPayer = null;
    private static long speedNextPay = 0;   // wall clock ms of the next charge: you pay per REAL second, whatever the tick rate

    public static void sendTimeState(class_3222 p) {
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.uemc.net.TimeStatePayload(speedIdx));
    }

    private static void broadcastTime(MinecraftServer s) {
        for (class_3222 pl : s.method_3760().method_14571()) sendTimeState(pl);
    }

    // The tick rate is set by running the vanilla command with the server's own command source. The three methods are
    // found by their SIGNATURE (not their name), so this does not depend on any one mapping name.
    private static boolean cmdReady = false, cmdBroken = false;
    private static java.lang.reflect.Method mGetMgr, mGetSrc, mExec;

    private static void findCmd() {
        cmdReady = true;
        try {
            Class<?> mgr = Class.forName("net.minecraft.class_2170");   // CommandManager
            Class<?> src = Class.forName("net.minecraft.class_2168");   // ServerCommandSource
            for (java.lang.reflect.Method m : MinecraftServer.class.getMethods()) {
                if (m.getParameterCount() != 0) continue;
                if (m.getReturnType() == mgr) mGetMgr = m;
                else if (m.getReturnType() == src) mGetSrc = m;
            }
            for (java.lang.reflect.Method m : mgr.getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (t.length == 2 && t[0] == src && t[1] == String.class && m.getReturnType() == void.class) mExec = m;
            }
            if (mGetMgr == null || mGetSrc == null || mExec == null) throw new IllegalStateException("command methods not found");
        } catch (Throwable e) {
            cmdBroken = true;
            com.uemc.UniversalEmc.LOG.warn("Time speed: could not find the command API, speed will not work", e);
        }
    }

    private static boolean runCmd(MinecraftServer s, String cmd) {
        if (!cmdReady) findCmd();
        if (cmdBroken) return false;
        try {
            mExec.invoke(mGetMgr.invoke(s), mGetSrc.invoke(s), cmd);
            return true;
        } catch (Throwable e) {
            com.uemc.UniversalEmc.LOG.warn("Time speed: command failed: " + cmd, e);
            return false;
        }
    }

    private static boolean setRate(MinecraftServer s, int x) { return runCmd(s, "tick rate " + (20 * x)); }

    /** idx 0 = back to normal, otherwise Fees.SPEED_X[idx]. The first second is paid now, then every real second. */
    public static void timeSpeed(class_3222 p, int idx) {
        if (idx < 0 || idx >= Fees.SPEED_X.length) return;
        if (idx == 0) {
            if (speedIdx > 0) { stopSpeed(server(), null); msg(p, "Time back to normal"); }
            return;
        }
        if (idx == speedIdx && p.method_5667().equals(speedPayer)) return;
        long fee = Fees.SPEED_FEE[idx];
        if (!pay(p, fee)) return;
        if (!setRate(server(), Fees.SPEED_X[idx])) {
            EmcData.add(p.method_5667(), fee);   // nothing started: give it back
            msg(p, "Time speed failed (see the log)");
            return;
        }
        speedPayer = p.method_5667();
        speedIdx = idx;
        speedNextPay = System.currentTimeMillis() + 1000;
        broadcastTime(server());
        msg(p, "Time x" + Fees.SPEED_X[idx] + " running, " + fee + " EMC/s. Everything runs faster");
    }

    private static void stopSpeed(MinecraftServer s, String why) {
        UUID who = speedPayer;
        boolean was = speedIdx > 0;
        speedIdx = 0;
        speedPayer = null;
        if (was) setRate(s, 1);
        if (!was) return;
        if (why != null && who != null) {
            class_3222 pl = s.method_3760().method_14602(who);
            if (pl != null) msg(pl, why);
        }
        broadcastTime(s);
    }

    private static void speedTick(MinecraftServer s) {
        class_3222 payer = speedPayer == null ? null : s.method_3760().method_14602(speedPayer);
        if (payer == null) { stopSpeed(s, null); return; }
        long now = System.currentTimeMillis();
        if (now >= speedNextPay) {
            speedNextPay += 1000;
            if (speedNextPay < now) speedNextPay = now + 1000;   // long pause (lag): do not charge a backlog
            if (!EmcData.add(payer.method_5667(), -Fees.SPEED_FEE[speedIdx])) {
                stopSpeed(s, "Time speed stopped: out of EMC");
            }
        }
    }

    // Older versions raised the random tick speed and saved a marker. If a crash left that value behind, put it back once.
    private static class_12279 rtRule() {
        for (String n : new String[]{"random_tick_speed", "randomTickSpeed"}) {
            class_2960 id = class_2960.method_60656(n);
            if (class_7923.field_64251.method_10250(id)) return class_7923.field_64251.method_63535(id);
        }
        return null;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void rtSet(MinecraftServer s, class_12279 r, int v) {
        s.method_30002().method_64395().method_76186(r, Integer.valueOf(v), s);
    }

    private static java.nio.file.Path marker(MinecraftServer s) {
        return s.method_27050(class_5218.field_24188).resolve("uemc_randomtick.txt");
    }

    private static void recoverGrowth(MinecraftServer s) {
        try {
            java.nio.file.Path f = marker(s);
            if (!java.nio.file.Files.exists(f)) return;
            int v = Integer.parseInt(java.nio.file.Files.readString(f).trim());
            class_12279 r = rtRule();
            if (r != null) rtSet(s, r, v);
            java.nio.file.Files.deleteIfExists(f);
        } catch (java.io.IOException | RuntimeException e) {
            com.uemc.UniversalEmc.LOG.warn("Could not restore random tick speed", e);
        }
    }

    // ---------- weather ----------
    private static int lastWeather = -1000;

    /** kind 0 = clear, 1 = rain, 2 = storm. Overworld only. */
    public static void weather(class_3222 p, int kind) {
        if (kind < 0 || kind >= Fees.WEATHER_NAMES.length) return;
        class_3218 w = server().method_30002();
        if (worldOf(p) != w) { msg(p, "Weather only changes in the Overworld"); return; }
        int now = server().method_3780();
        if (now - lastWeather < 100 && now >= lastWeather) { msg(p, "Weather is still changing"); return; }
        int cur = w.method_8546() ? 2 : w.method_8419() ? 1 : 0;
        if (cur == kind) { msg(p, Fees.WEATHER_NAMES[kind] + " is already on"); return; }
        long fee = Fees.WEATHER_FEE[kind];
        if (!pay(p, fee)) return;
        int t = Fees.WEATHER_TICKS[kind];
        if (kind == 0) w.method_27910(t, 0, false, false);
        else w.method_27910(0, t, true, kind == 2);
        lastWeather = now;
        msg(p, Fees.WEATHER_NAMES[kind] + " weather for " + fee + " EMC");
    }

    // ---------- chosen enchant ----------
    /** Main-hand item (kept for old clients / commands). */
    public static void enchant(class_3222 p, String idStr, int level) { enchantStack(p, p.method_6047(), idStr, level); }

    /** code = slot * 100 + level, slot is an inventory slot 0-35 (hotbar 0-8). */
    public static void enchantSlot(class_3222 p, String idStr, int code) {
        int slot = code / 100, level = code % 100;
        if (slot < 0 || slot > 35) return;
        enchantStack(p, p.method_31548().method_5438(slot), idStr, level);
    }

    private static void enchantStack(class_3222 p, class_1799 st, String idStr, int level) {
        if (st.method_7960()) { msg(p, "Pick an item first"); return; }
        class_2960 id = class_2960.method_12829(idStr);
        if (id == null) return;
        var reg = server().method_30611().method_30530(class_7924.field_41265);
        var opt = reg.method_46746(class_5321.method_29179(class_7924.field_41265, id));
        if (opt.isEmpty()) return;
        class_6880<class_1887> e = opt.get();
        class_1887 en = e.comp_349();
        if (level < 1 || level > Fees.maxLevel(en.method_8183())) { msg(p, "Bad level"); return; }
        if (!en.method_8192(st)) { msg(p, "Can't go on this item"); return; }
        class_9304 cur = class_1890.method_57532(st);
        for (class_6880<class_1887> o : cur.method_57534())
            if (!o.equals(e) && !class_1887.method_60033(e, o)) { msg(p, "Conflicts with " + o.comp_349().comp_2686().getString()); return; }
        int have = cur.method_57536(e);
        if (have >= level) { msg(p, "Already has that level"); return; }
        long fee = Fees.enchant(level) - Fees.enchant(have);
        if (!pay(p, fee)) return;
        class_1890.method_57531(st, b -> b.method_57547(e, level));
        msg(p, "Enchanted for " + fee + " EMC");
    }

    /** Lower (or remove, level 0) an enchant that is on the item. code = slot * 100 + new level. Free, no refund. */
    public static void lowerSlot(class_3222 p, String idStr, int code) {
        int slot = code / 100, level = code % 100;
        if (slot < 0 || slot > 35) return;
        class_1799 st = p.method_31548().method_5438(slot);
        if (st.method_7960()) { msg(p, "Pick an item first"); return; }
        class_2960 id = class_2960.method_12829(idStr);
        if (id == null) return;
        var reg = server().method_30611().method_30530(class_7924.field_41265);
        var opt = reg.method_46746(class_5321.method_29179(class_7924.field_41265, id));
        if (opt.isEmpty()) return;
        class_6880<class_1887> e = opt.get();
        int have = class_1890.method_57532(st).method_57536(e);
        if (level < 0 || level >= have) { msg(p, "Pick a lower level"); return; }
        class_1890.method_57531(st, b -> b.method_57547(e, level));
        String name = e.comp_349().comp_2686().getString();
        msg(p, level == 0 ? "Removed " + name : name + " lowered to " + level);
    }

    /** One click: every compatible enchant at max level on the item in this inventory slot (0-35). */
    public static void enchantAll(class_3222 p, int slot) {
        if (slot < 0 || slot > 35) return;
        class_1799 st = p.method_31548().method_5438(slot);
        if (st.method_7960()) { msg(p, "Pick an item first"); return; }
        var reg = server().method_30611().method_30530(class_7924.field_41265);
        EnchantPlan plan = EnchantPlan.make(reg, st);
        if (plan.entries.isEmpty()) { msg(p, "Nothing left to add"); return; }
        if (!pay(p, plan.fee)) return;
        class_1890.method_57531(st, b -> { for (EnchantPlan.Entry en : plan.entries) b.method_57547(en.ref(), en.level()); });
        msg(p, "Maxed " + plan.entries.size() + " enchants for " + plan.fee + " EMC");
    }
}

package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.Reader;
import java.util.*;

/**
 * Derives EMC for craftable items from recipe JSONs (vanilla + any datapack/mod).
 * Output value = floor(sum(inputs) / output count), repeated until stable.
 * Values only ever decrease -> no craft/uncraft loop can create EMC.
 */
final class RecipeEmc {
    private record Rec(class_2960 out, int count, List<List<class_2960>> ingredients) {}

    private RecipeEmc() {}

    static void compute(MinecraftServer server, Map<class_2960, Long> values, Set<class_2960> locked) {
        List<Rec> recs = new ArrayList<>();
        var found = server.method_34864().method_14488("recipe", id -> id.method_12832().endsWith(".json"));
        for (Map.Entry<class_2960, class_3298> e : found.entrySet()) {
            try (Reader r = e.getValue().method_43039()) {
                JsonElement el = JsonParser.parseReader(r);
                if (el.isJsonObject()) parse(el.getAsJsonObject(), recs);
            } catch (Exception ex) {
                UniversalEmc.LOG.debug("Skipped recipe {}: {}", e.getKey(), ex.toString());
            }
        }
        for (int pass = 0; pass < 60; pass++) {
            boolean changed = false;
            for (Rec rec : recs) {
                if (locked.contains(rec.out)) continue;
                long sum = 0;
                boolean ok = true;
                for (List<class_2960> opts : rec.ingredients) {
                    long best = Long.MAX_VALUE;
                    for (class_2960 i : opts) {
                        long v = values.getOrDefault(i, 0L);
                        if (v > 0 && v < best) best = v;
                    }
                    if (best == Long.MAX_VALUE) { ok = false; break; }
                    sum += best;
                }
                if (!ok) continue;
                long cand = sum / rec.count;
                if (cand <= 0) continue;
                Long cur = values.get(rec.out);
                if (cur == null || cur <= 0 || cand < cur) { values.put(rec.out, cand); changed = true; }
            }
            if (!changed) break;
        }
        UniversalEmc.LOG.info("Recipes parsed for EMC: {}", recs.size());
    }

    private static void parse(JsonObject o, List<Rec> out) {
        if (!o.has("type")) return;
        String type = o.get("type").getAsString().replace("minecraft:", "");
        switch (type) {
            case "crafting_shaped" -> {
                JsonObject key = o.getAsJsonObject("key");
                Map<String, List<class_2960>> k = new HashMap<>();
                for (var e : key.entrySet()) k.put(e.getKey(), ing(e.getValue()));
                List<List<class_2960>> list = new ArrayList<>();
                for (JsonElement row : o.getAsJsonArray("pattern"))
                    for (char c : row.getAsString().toCharArray()) {
                        if (c == ' ') continue;
                        List<class_2960> x = k.get(String.valueOf(c));
                        if (x == null) return;
                        list.add(x);
                    }
                add(out, o.get("result"), list);
            }
            case "crafting_shapeless" -> {
                List<List<class_2960>> list = new ArrayList<>();
                for (JsonElement i : o.getAsJsonArray("ingredients")) list.add(ing(i));
                add(out, o.get("result"), list);
            }
            case "smelting", "blasting", "smoking", "campfire_cooking", "stonecutting" ->
                add(out, o.get("result"), List.of(ing(o.get("ingredient"))));
            case "crafting_transmute" ->
                add(out, o.get("result"), List.of(ing(o.get("input")), ing(o.get("material"))));
            case "smithing_transform" ->
                add(out, o.get("result"), List.of(ing(o.get("template")), ing(o.get("base")), ing(o.get("addition"))));
            default -> {}
        }
    }

    private static void add(List<Rec> out, JsonElement result, List<List<class_2960>> ings) {
        String id; int count = 1;
        if (result.isJsonPrimitive()) id = result.getAsString();
        else {
            JsonObject r = result.getAsJsonObject();
            id = r.has("id") ? r.get("id").getAsString() : r.get("item").getAsString();
            if (r.has("count")) count = Math.max(1, r.get("count").getAsInt());
        }
        for (List<class_2960> l : ings) if (l.isEmpty()) return;
        out.add(new Rec(class_2960.method_60654(id), count, ings));
    }

    /** Ingredient -> candidate item ids (string, "#tag", array, or legacy {item}/{tag}). */
    private static List<class_2960> ing(JsonElement e) {
        List<class_2960> res = new ArrayList<>();
        if (e == null) return res;
        if (e.isJsonArray()) { for (JsonElement x : e.getAsJsonArray()) res.addAll(ing(x)); return res; }
        String s;
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("item")) s = o.get("item").getAsString();
            else if (o.has("tag")) s = "#" + o.get("tag").getAsString();
            else return res;
        } else s = e.getAsString();
        if (s.startsWith("#")) {
            class_6862<class_1792> tag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60654(s.substring(1)));
            for (class_6880<class_1792> en : class_7923.field_41178.method_40286(tag)) res.add(class_7923.field_41178.method_10221(en.comp_349()));
        } else res.add(class_2960.method_60654(s));
        return res;
    }
}

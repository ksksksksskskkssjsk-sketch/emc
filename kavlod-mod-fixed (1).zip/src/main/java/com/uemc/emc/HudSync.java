package com.uemc.emc;

import com.uemc.net.BalancePayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Keeps each player's on-screen EMC HUD up to date: every 5 ticks, sends the balance
 * to any player whose balance changed since the last packet (plus once after joining).
 */
public final class HudSync {
    private HudSync() {}

    private static final Map<UUID, Long> LAST = new HashMap<>();
    private static int tick = 0;

    public static void init() {
        PayloadTypeRegistry.playS2C().register(BalancePayload.ID, BalancePayload.CODEC);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> LAST.remove(handler.field_14140.method_5667()));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LAST.remove(handler.field_14140.method_5667()));
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> LAST.clear());
        ServerTickEvents.END_SERVER_TICK.register(HudSync::tick);
    }

    private static void tick(MinecraftServer s) {
        if (++tick % 5 != 0) return;
        for (UUID id : EmcData.all()) {
            class_3222 p = s.method_3760().method_14602(id);
            if (p == null) continue;
            long now = EmcData.get(id).emc;
            Long before = LAST.get(id);
            if (before != null && before == now) continue;
            LAST.put(id, now);
            ServerPlayNetworking.send(p, new BalancePayload(now, EmcData.get(id).upgrades.containsKey("autofix")));
        }
    }
}

package com.uemc.emc;

import com.uemc.UniversalEmc;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

import java.util.Map;

/** Gives every item that still has no EMC (no base value, no derivable recipe) a price, so EVERY item in the game is priced. */
final class FallbackEmc {
    private FallbackEmc() {}

    static final long DEFAULT = 64;

    static void fill(Map<class_2960, Long> values) {
        int added = 0;
        for (class_1792 item : class_7923.field_41178) {
            class_2960 id = class_7923.field_41178.method_10221(item);
            if (id.method_12832().equals("air")) continue;
            Long cur = values.get(id);
            if (cur != null && cur > 0) continue;
            values.put(id, price(id.method_12832()));
            added++;
        }
        UniversalEmc.LOG.info("Fallback EMC prices added: {}", added);
    }

    static long price(String p) {
        // admin / creative-only
        if (p.contains("command_block") || p.equals("barrier") || p.equals("structure_block") || p.equals("structure_void")
                || p.equals("jigsaw") || p.equals("light") || p.equals("debug_stick") || p.equals("bedrock")
                || p.equals("knowledge_book") || p.startsWith("test_") || p.equals("reinforced_deepslate")) return 1_000_000;
        if (p.equals("dragon_egg")) return 200_000;
        if (p.equals("enchanted_golden_apple")) return 65_536;
        if (p.equals("mace")) return 40_000;
        if (p.equals("elytra")) return 32_768;
        if (p.equals("trident") || p.equals("conduit")) return 16_384;
        if (p.equals("totem_of_undying") || p.equals("heavy_core")) return 8_192;
        if (p.equals("dragon_head") || p.equals("wither_skeleton_skull")) return 20_000;
        if (p.endsWith("_skull") || p.endsWith("_head") || p.equals("creeper_head")) return 4_096;
        if (p.equals("spawner") || p.equals("trial_spawner") || p.equals("vault")) return 20_000;
        if (p.contains("trial_key") || p.contains("ominous_bottle")) return 4_096;
        if (p.endsWith("_spawn_egg")) return 4_096;
        if (p.startsWith("music_disc") || p.equals("disc_fragment_5")) return 2_048;
        if (p.endsWith("_smithing_template")) return 8_192;
        if (p.endsWith("_pottery_sherd") || p.endsWith("_banner_pattern")) return 512;
        if (p.equals("enchanted_book")) return 3_000;
        if (p.equals("potion") || p.equals("splash_potion") || p.equals("lingering_potion") || p.equals("tipped_arrow")) return 256;
        if (p.equals("suspicious_stew") || p.equals("firework_star")) return 128;
        if (p.equals("written_book") || p.equals("filled_map") || p.equals("player_head")) return 64;
        if (p.contains("sapling") || p.contains("flower") || p.contains("coral")) return 16;
        if (p.contains("infested_") || p.startsWith("chipped_") || p.startsWith("damaged_")) return 64;
        return DEFAULT;
    }
}

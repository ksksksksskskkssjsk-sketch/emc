package com.uemc.block;

import com.mojang.serialization.MapCodec;
import com.uemc.ModSounds;
import com.uemc.emc.EmcData;
import com.uemc.emc.EmcLogic;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

/**
 * Energy Converter. Right-click with items to convert up to perUse of them into your EMC.
 * CHARGE (0-8) is the visible machine state: drives model, light level, particles and sounds.
 */
public class ConverterBlock extends class_2248 {
    public static final class_2758 CHARGE = class_2758.method_11867("charge", 0, 8);
    public static final MapCodec<ConverterBlock> field_46280 = method_54094(s -> new ConverterBlock(s, 16));

    private final int perUse;

    public ConverterBlock(class_2251 settings, int perUse) {
        super(settings);
        this.perUse = perUse;
        method_9590(method_9595().method_11664().method_11657(CHARGE, 0));
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() { return field_46280; }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(CHARGE); }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                         class_1657 player, class_1268 hand, class_3965 hit) {
        if (stack.method_7960()) return class_1269.field_52423;
        if (world.method_8608()) return class_1269.field_5812;
        class_3218 sw = (class_3218) world;

        int n = Math.min(stack.method_7947(), perUse);
        class_1799 part = stack.method_46651(n);
        long gained = EmcLogic.convert(player, part);
        if (gained <= 0) return class_1269.field_52423;
        stack.method_7934(n);
        player.method_7353(class_2561.method_43470("+" + gained + " EMC  (" + EmcData.get(player.method_5667()).emc + ")"), true);

        boolean wasIdle = state.method_11654(CHARGE) == 0;
        world.method_8501(pos, state.method_11657(CHARGE, 8));
        sw.method_64310(pos, this, 4);
        if (wasIdle) sw.method_8396(null, pos, ModSounds.CONVERTER_START, class_3419.field_15245, 0.8f, 1.0f);
        sw.method_8396(null, pos, ModSounds.EMC_TRANSACT, class_3419.field_15245, 0.5f, 1.0f);

        // energy beam: machine core -> player
        double sx = pos.method_10263() + 0.5, sy = pos.method_10264() + 0.7, sz = pos.method_10260() + 0.5;
        double dx = player.method_23317() - sx, dy = player.method_23320() - sy, dz = player.method_23321() - sz;
        for (int i = 0; i <= 14; i++) {
            double t = i / 14.0;
            sw.method_65096(class_2398.field_11207, sx + dx * t, sy + dy * t, sz + dz * t, 1, 0, 0, 0, 0);
        }
        sw.method_65096(class_2398.field_29644, sx, pos.method_10264() + 1.0, sz, 12, 0.25, 0.2, 0.25, 0.1);
        // expanding ring + rising spiral
        for (int i = 0; i < 20; i++) {
            double a = i * Math.PI * 2 / 20;
            sw.method_65096(class_2398.field_11207, sx + Math.cos(a) * 0.75, pos.method_10264() + 0.15, sz + Math.sin(a) * 0.75, 1, 0, 0.05, 0, 0.02);
        }
        spiral(sw, pos, 8, 0.0);
        return class_1269.field_5812;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.method_8608()) return class_1269.field_5812;
        if (player instanceof net.minecraft.class_3222 sp) {
            pulse((class_3218) world, pos);
            com.uemc.net.ServerNet.openMenu(sp, (class_3218) world, pos);
        }
        return class_1269.field_5812;
    }

    /** Light the machine up (used for any interaction). */
    public static void pulse(class_3218 w, class_2338 pos) {
        class_2680 s = w.method_8320(pos);
        if (!(s.method_26204() instanceof ConverterBlock b)) return;
        boolean idle = s.method_11654(CHARGE) == 0;
        w.method_8501(pos, s.method_11657(CHARGE, 8));
        w.method_64310(pos, b, 4);
        if (idle) w.method_8396(null, pos, ModSounds.CONVERTER_START, class_3419.field_15245, 0.6f, 1.2f);
    }

    /** A glowing helix that climbs the machine. phase rotates it between ticks. */
    private static void spiral(class_3218 w, class_2338 pos, int charge, double phase) {
        double cx = pos.method_10263() + 0.5, cz = pos.method_10260() + 0.5;
        for (int i = 0; i < 3; i++) {
            double a = phase + i * Math.PI * 2 / 3;
            double up = 0.1 + (charge / 8.0) * 0.9;
            for (int k = 0; k < 4; k++) {
                double aa = a + k * 0.5, yy = pos.method_10264() + up * (k / 4.0) * 1.1 + 0.1;
                w.method_65096(class_2398.field_29644, cx + Math.cos(aa) * 0.62, yy, cz + Math.sin(aa) * 0.62, 1, 0, 0, 0, 0);
            }
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int c = state.method_11654(CHARGE);
        if (c <= 0) return;
        world.method_65096(class_2398.field_29644, pos.method_10263() + 0.5, pos.method_10264() + 1.0 + c * 0.03, pos.method_10260() + 0.5,
                2, 0.2, 0.05, 0.2, 0.02);
        spiral(world, pos, c, c * 0.9);
        if (c == 1) {
            world.method_8396(null, pos, ModSounds.CONVERTER_DONE, class_3419.field_15245, 0.7f, 1.0f);
            world.method_65096(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 1.1, pos.method_10260() + 0.5, 6, 0.15, 0.1, 0.15, 0.03);
        } else {
            world.method_64310(pos, this, 4);
        }
        world.method_8501(pos, state.method_11657(CHARGE, c - 1));
    }
}

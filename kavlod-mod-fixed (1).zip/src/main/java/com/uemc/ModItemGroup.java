package com.uemc;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItemGroup {
    private ModItemGroup() {}

    public static void init() {
        class_1761 g = FabricItemGroup.builder()
                .method_47320(() -> new class_1799(ModBlocks.CONVERTER_ULTIMATE))
                .method_47321(class_2561.method_43471("itemGroup.uemc"))
                .method_47317((ctx, entries) -> {
                    entries.method_45421(ModBlocks.CONVERTER_BASIC);
                    entries.method_45421(ModBlocks.CONVERTER_ADVANCED);
                    entries.method_45421(ModBlocks.CONVERTER_ULTIMATE);
                    entries.method_45421(ModItems.EMC_SCANNER);
                    entries.method_45421(ModItems.EMC_TABLET);
                })
                .method_47324();
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_40197).register(e -> {
            e.method_45421(ModBlocks.CONVERTER_BASIC);
            e.method_45421(ModBlocks.CONVERTER_ADVANCED);
            e.method_45421(ModBlocks.CONVERTER_ULTIMATE);
        });
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_41060).register(e -> {
            e.method_45421(ModItems.EMC_SCANNER);
            e.method_45421(ModItems.EMC_TABLET);
        });
        class_2378.method_39197(class_7923.field_44687, class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(UniversalEmc.ID, "main")), g);
    }
}

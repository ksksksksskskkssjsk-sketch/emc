package com.uemc.item;

import com.uemc.net.ServerNet;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class TabletItem extends class_1792 {
    public TabletItem(class_1793 s) { super(s); }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        if (!world.method_8608() && player instanceof class_3222 sp) {
            if (world instanceof net.minecraft.class_3218 sw) com.uemc.emc.Services.rememberWorld(sp, sw);
            ServerNet.sendState(sp);
            world.method_8396(null, player.method_24515(), com.uemc.ModSounds.TABLET_OPEN, net.minecraft.class_3419.field_15248, 0.6f, 1.0f);
        }
        return class_1269.field_5812;
    }
}

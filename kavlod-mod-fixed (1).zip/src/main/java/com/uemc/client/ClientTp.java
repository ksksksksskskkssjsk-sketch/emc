package com.uemc.client;

import java.util.ArrayList;
import java.util.List;

/** Client copy of the player's home + checkpoints. */
public final class ClientTp {
    private ClientTp() {}
    public record Loc(String name, String dim, double x, double y, double z) {}
    public static volatile Loc home = null;
    public static volatile List<Loc> checkpoints = new ArrayList<>();
}

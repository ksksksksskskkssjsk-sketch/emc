package com.uemc.client;

import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Sell from your inventory. Laid out like your real inventory (hotbar at the bottom).
 * - Click stacks to tick them, or switch on QUICK to sell a stack the moment you click it.
 * - Big picture card shows the hovered (or last clicked) item with its EMC price.
 * - A "cart" row of icons shows exactly what will be sold; the Sell button shows the total.
 * - Dim stacks have no EMC value. Enchanted stacks get a purple marker and are never auto-selected or quick-sold.
 * Values are computed from the EMC table the server already synced; the server re-checks everything.
 */
public class SellScreen extends ServiceScreen {
    private static final int MODE_ALL = 0, MODE_HALF = 1000, MODE_ONE = 1;
    private static final int CARD_W = 62, CARD_H = 74, MAX_CART = 15;

    private record Icon(GlowButton b, String id, float scale) {}

    private final Runnable onBack;
    private final GlowButton[] cell = new GlowButton[36];
    private final List<Icon> icons = new ArrayList<>();
    private final TreeSet<Integer> picked = new TreeSet<>();
    private GlowButton sell, mAll, mHalf, mOne, quickBtn;
    private int mode = MODE_ALL, last = -1, ticks = 0, hash = 0;
    private boolean synced = false, quick = false;

    public SellScreen(Runnable onBack) {
        super("SELL ITEMS");
        this.onBack = onBack;
        W = 330;
        H = 220;
        accent = Fx.GOLD;
    }

    // ---------- helpers ----------
    private class_1799 stack(int slot) {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_31548().method_5438(slot);
    }

    private boolean sellable(int slot) { return ClientEmc.unit(stack(slot)) > 0; }

    private int cellX(int slot) { return left + 8 + (slot < 9 ? slot : (slot - 9) % 9) * 18; }
    private int cellY(int slot) { return slot < 9 ? top + 96 : top + 38 + ((slot - 9) / 9) * 18; }

    private int amount(class_1799 st) {
        int c = st.method_7947();
        return mode == MODE_ALL ? c : mode == MODE_HALF ? Math.max(1, c / 2) : 1;
    }

    private long value(int slot) {
        class_1799 st = stack(slot);
        return ClientEmc.unit(st) * amount(st);
    }

    private long totalValue() { long t = 0; for (int s : picked) t += value(s); return t; }

    private int totalItems() { int t = 0; for (int s : picked) t += amount(stack(s)); return t; }

    private String idOf(int slot) { return class_7923.field_41178.method_10221(stack(slot).method_7909()).toString(); }

    /** EMC you would get for "Sell all items" (everything sellable that is not enchanted). */
    private long inventoryWorth() {
        long t = 0;
        for (int s = 0; s < 36; s++) {
            class_1799 st = stack(s);
            if (!st.method_7960() && !st.method_7942()) t += ClientEmc.unit(st) * st.method_7947();
        }
        return t;
    }

    private static String compact(long v) {
        if (v >= 1_000_000) return (v / 100_000) / 10.0 + "M";
        if (v >= 1000) return (v / 100) / 10.0 + "k";
        return String.valueOf(v);
    }

    /** The slot shown in the picture card: hovered stack first, else the last one you clicked. */
    private int focus() {
        for (int s = 0; s < 36; s++)
            if (cell[s] != null && cell[s].method_49606() && !stack(s).method_7960()) return s;
        return last >= 0 && !stack(last).method_7960() ? last : -1;
    }

    // ---------- selection ----------
    private void toggle(int slot) {
        if (!sellable(slot)) return;
        last = slot;
        if (quick && !stack(slot).method_7942()) {
            ClientPlayNetworking.send(new ActionPayload(42, String.valueOf(slot), mode));
            picked.remove(slot);
            refresh();
            return;
        }
        if (!picked.remove(slot)) picked.add(slot);
        refresh();
    }

    private void selectRange(int from, int to) {
        for (int s = from; s <= to; s++) if (sellable(s) && !stack(s).method_7942()) picked.add(s);
        refresh();
    }

    private void selectSame() {
        if (last < 0 || stack(last).method_7960()) return;
        String id = idOf(last);
        for (int s = 0; s < 36; s++)
            if (sellable(s) && !stack(s).method_7942() && idOf(s).equals(id)) picked.add(s);
        refresh();
    }

    private void doSell() {
        if (picked.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (int s : picked) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        ClientPlayNetworking.send(new ActionPayload(42, sb.toString(), mode));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        icons.clear();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); }

        for (int s = 0; s < 36; s++) {
            final int slot = s;
            GlowButton b = GlowButton.slot(cellX(s), cellY(s), x -> toggle(slot));
            b.accent = Fx.GOLD;
            cell[s] = b;
            method_37063(b);
        }

        int rx = left + 176;
        side("Select main", "Select every sellable, non-enchanted stack in your inventory (not the hotbar)", rx, top + 38, "minecraft:chest", () -> selectRange(9, 35));
        side("Select all", "Select every sellable, non-enchanted stack including the hotbar", rx, top + 57, "minecraft:ender_chest", () -> selectRange(0, 35));
        side("Same item", "Select every stack of the same item as the one you clicked last", rx, top + 76, "minecraft:name_tag", this::selectSame);
        side("Clear", "Unselect everything", rx, top + 95, "minecraft:barrier", () -> { picked.clear(); refresh(); });
        quickBtn = side("Quick: OFF", "Quick sell: when ON, clicking a stack sells it immediately (enchanted stacks are skipped)", rx, top + 114, "minecraft:gold_nugget", () -> {
            quick = !quick;
            picked.clear();
            refresh();
        });

        mAll = chip("All", "Sell the whole stack", left + 8, MODE_ALL, "minecraft:chest");
        mHalf = chip("Half", "Sell half of each stack", left + 52, MODE_HALF, "minecraft:shears");
        mOne = chip("One", "Sell one item from each stack", left + 96, MODE_ONE, "minecraft:gold_nugget");

        int by = top + 196;
        GlowButton back = GlowButton.of("Back", left + 8, by, 56, 18, b -> onBack.run());
        back.accent = Fx.GOLD;
        method_37063(back);
        icons.add(new Icon(back, "minecraft:arrow", 0.7f));

        GlowButton all = GlowButton.of("Sell all items", left + 68, by, 96, 18, b -> ClientPlayNetworking.send(new ActionPayload(4, "", 0)));
        all.accent = Fx.ORANGE;
        all.method_47400(class_7919.method_47407(class_2561.method_43470("Sells every sellable stack in your inventory.\nEnchanted items are kept.")));
        method_37063(all);
        icons.add(new Icon(all, "minecraft:hopper", 0.7f));

        sell = GlowButton.of("Sell selected", left + 168, by, 154, 18, b -> doSell());
        sell.accent = Fx.GOLD;
        method_37063(sell);
        icons.add(new Icon(sell, "minecraft:emerald", 0.7f));
        refresh();
    }

    private GlowButton side(String label, String tip, int x, int y, String icon, Runnable r) {
        GlowButton b = GlowButton.of(label, x, y, 78, 16, bb -> r.run());
        b.accent = Fx.GOLD;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        icons.add(new Icon(b, icon, 0.55f));
        return b;
    }

    private GlowButton chip(String label, String tip, int x, int m, String icon) {
        GlowButton b = GlowButton.of(label, x, top + 128, 40, 16, bb -> { mode = m; refresh(); });
        b.accent = Fx.GOLD;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        icons.add(new Icon(b, icon, 0.55f));
        return b;
    }

    /** Re-reads the inventory: prunes the selection, updates tooltips, buttons, labels and mode chips. */
    private void refresh() {
        picked.removeIf(s -> !sellable(s));
        for (int s = 0; s < 36; s++) {
            GlowButton b = cell[s];
            if (b == null) continue;
            class_1799 st = stack(s);
            long unit = ClientEmc.unit(st);
            b.field_22763 = unit > 0;
            b.selected = picked.contains(s);
            if (st.method_7960()) { b.method_47400(null); continue; }
            String tip = st.method_7964().getString();
            if (unit <= 0) tip += "\nNo EMC value";
            else {
                tip += "\nEach: " + Fx.num(unit) + " EMC";
                tip += "\nSells: " + Fx.num(unit * amount(st)) + " EMC";
                if (st.method_7942()) tip += "\nEnchanted: selling loses the enchants";
            }
            b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        }
        if (mAll != null) { mAll.selected = mode == MODE_ALL; mHalf.selected = mode == MODE_HALF; mOne.selected = mode == MODE_ONE; }
        if (quickBtn != null) {
            quickBtn.method_25355(class_2561.method_43470(quick ? "Quick: ON" : "Quick: OFF"));
            quickBtn.selected = quick;
            quickBtn.accent = quick ? Fx.GREEN : Fx.GOLD;
        }
        if (sell != null) {
            sell.field_22763 = !picked.isEmpty();
            sell.method_25355(class_2561.method_43470(picked.isEmpty() ? "Sell selected" : "Sell  +" + Fx.num(totalValue()) + " EMC"));
        }
    }

    @Override
    public void method_25393() {
        if (++ticks % 5 != 0) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        int h = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 s = stack(i);
            h = h * 31 + (s.method_7960() ? 0 : s.method_7947() + s.method_7909().hashCode() + s.method_7919());
        }
        if (h != hash) { hash = h; refresh(); }
    }

    // ---------- drawing ----------
    /** Smaller text (0.75x) centred on cx. */
    private void tiny(class_332 c, String s, int cx, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.75f, 0.75f);
        int w = field_22793.method_1727(s);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (cx / 0.75f - w / 2f), (int) (y / 0.75f), color, false);
        m.popMatrix();
    }

    private void centred(class_332 c, String s, int cx, int y, int color) {
        String t = field_22793.method_27523(s, CARD_W - 4);
        c.method_51439(field_22793, class_2561.method_43470(t), cx - field_22793.method_1727(t) / 2, y, color, true);
    }

    private void drawCard(class_332 ctx, int x0, int y0) {
        int cx = x0 + CARD_W / 2;
        ctx.method_25294(x0, y0, x0 + CARD_W, y0 + CARD_H, Fx.argb(255, 0x05090D));
        ctx.method_25296(x0 + 1, y0 + 1, x0 + CARD_W - 1, y0 + CARD_H - 1, Fx.argb(255, 0x1A2630), Fx.argb(255, 0x0E151C));
        Fx.ring(ctx, x0, y0, CARD_W, CARD_H, Fx.argb(130, Fx.GOLD));
        int f = focus();
        if (f < 0) {
            Icons.draw(ctx, "minecraft:gold_ingot", cx, y0 + 26, 1.6f);
            tiny(ctx, "Hover or click", cx, y0 + 50, GREY);
            tiny(ctx, "an item to see", cx, y0 + 58, GREY);
            tiny(ctx, "its price", cx, y0 + 66, GREY);
            return;
        }
        class_1799 st = stack(f);
        long unit = ClientEmc.unit(st);
        Fx.showcase(ctx, st, cx, y0 + 24, 1.5f, Fx.GOLD);
        centred(ctx, st.method_7964().getString(), cx, y0 + 46, WHITE);
        if (unit <= 0) {
            tiny(ctx, "no EMC value", cx, y0 + 60, 0xFFFF7070);
        } else {
            tiny(ctx, Fx.num(unit) + " each", cx, y0 + 58, GREY);
            tiny(ctx, "sells " + Fx.num(unit * amount(st)), cx, y0 + 66, 0xFFFFC040);
        }
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        float now = Fx.t();
        if (quick) txt(ctx, "QUICK SELL ON: click a stack to sell it now.", left + 8, top + 24, 0xFF40FF80);
        else txt(ctx, "Click stacks to select. Dim = no EMC value.", left + 8, top + 24, GREY);

        // inventory grid
        for (int s = 0; s < 36; s++) {
            class_1799 st = stack(s);
            if (st.method_7960()) continue;
            int x = cellX(s) + 1, y = cellY(s) + 1;
            float appear = Fx.ease((now - openT) * 4f - ((s % 9) + (s / 9)) * 0.04f);
            boolean sel = picked.contains(s);
            Fx.item(ctx, st, x, y, cell[s] != null && cell[s].method_49606(), sel, appear, Fx.GOLD);
            if (appear < 0.9f) continue;
            if (!sellable(s)) ctx.method_25294(x, y, x + 16, y + 16, 0xAA101820);
            if (st.method_7942()) ctx.method_25294(x, y, x + 3, y + 3, Fx.argb(255, Fx.PURPLE));
            if (st.method_7947() > 1) {
                String cnt = String.valueOf(st.method_7947());
                txt(ctx, cnt, x + 17 - field_22793.method_1727(cnt), y + 9, WHITE);
            }
        }
        txt(ctx, "Amount per stack:", left + 8, top + 117, GREY);

        // button icons
        for (Icon i : icons) {
            GlowButton b = i.b();
            Icons.draw(ctx, i.id(), b.method_46426() + 8, b.method_46427() + b.method_25364() / 2f, i.scale());
        }

        // picture card + inventory worth
        int cx0 = left + 260;
        drawCard(ctx, cx0, top + 38);
        tiny(ctx, "INVENTORY WORTH", cx0 + CARD_W / 2, top + 118, 0xFF7A8A99);
        String worth = Fx.num(inventoryWorth());
        int ww = field_22793.method_1727(worth);
        txt(ctx, worth, ww > CARD_W ? cx0 : cx0 + (CARD_W - ww) / 2, top + 128, 0xFFFFC040);
        tiny(ctx, "EMC", cx0 + CARD_W / 2, top + 139, 0xFF7A8A99);

        // cart: icons of what will be sold
        int n = picked.size();
        if (n == 0) {
            txt(ctx, quick ? "Quick sell is on: nothing to select." : "Nothing selected. Click items above.", left + 8, top + 152, GREY);
        } else {
            Map<String, long[]> agg = new LinkedHashMap<>();
            for (int s : picked) {
                long[] a = agg.computeIfAbsent(idOf(s), k -> new long[]{0, s});
                a[0] += amount(stack(s));
            }
            int i = 0;
            for (Map.Entry<String, long[]> e : agg.entrySet()) {
                if (i >= MAX_CART) break;
                int ix = left + 8 + i * 20, iy = top + 148;
                Fx.itemScaled(ctx, stack((int) e.getValue()[1]), ix + 8, iy + 8, 1f);
                if (e.getValue()[0] > 1) tiny(ctx, compact(e.getValue()[0]), ix + 12, iy + 10, WHITE);
                i++;
            }
            if (agg.size() > MAX_CART) txt(ctx, "+" + (agg.size() - MAX_CART), left + 8 + MAX_CART * 20, top + 152, GREY);
            txt(ctx, n + (n == 1 ? " stack" : " stacks") + ", " + Fx.num(totalItems()) + " items", left + 8, top + 169, GREY);
            Fx.glowText(ctx, field_22793, "+" + Fx.num(totalValue()) + " EMC", left + 8, top + 180, Fx.GOLD);
            String after = "Balance after: " + Fx.num(ClientEmc.balance + totalValue());
            txt(ctx, after, left + W - 8 - field_22793.method_1727(after), top + 180, 0xFFAAFFCC);
        }
    }
}

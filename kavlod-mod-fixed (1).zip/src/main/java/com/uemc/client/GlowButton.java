package com.uemc.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/**
 * Button with animated hover glow, shine sweep and accent line. cell=true makes it an item slot.
 * Extras: staggered spring pop-in when the screen opens, press squash + ripple + sparks,
 * frame-rate independent easing.
 */
public class GlowButton extends class_4185 {
    @FunctionalInterface
    public interface Press { void press(GlowButton b); }

    private float hover = 0;
    public int accent = Fx.CYAN;
    public boolean cell = false;
    public boolean selected = false;

    private final Press action;
    private float pressT = -1000f;
    private int clickX, clickY, lastMx, lastMy;
    private long lastNano = System.nanoTime();
    private boolean wasSel = false, wasOn = true;
    private float flash = 0;

    private GlowButton(int x, int y, int w, int h, class_2561 msg, Press a) {
        super(x, y, w, h, msg, btn -> ((GlowButton) btn).fire(), field_40754);
        this.action = a;
    }

    private void fire() {
        pressT = Fx.t();
        clickX = Math.max(method_46426() + 1, Math.min(method_46426() + method_25368() - 2, lastMx));
        clickY = Math.max(method_46427() + 1, Math.min(method_46427() + method_25364() - 2, lastMy));
        if (action != null) action.press(this);
    }

    public static GlowButton of(String label, int x, int y, int w, int h, Press a) {
        return new GlowButton(x, y, w, h, class_2561.method_43470(label), a);
    }

    public static GlowButton slot(int x, int y, Press a) {
        GlowButton b = new GlowButton(x, y, 18, 18, class_2561.method_43473(), a);
        b.cell = true;
        return b;
    }

    @Override
    public void method_75752(class_332 c, int mx, int my, float delta) {
        lastMx = mx;
        lastMy = my;
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNano) / 1e9f);
        lastNano = now;

        int x = method_46426(), y = method_46427(), w = method_25368(), h = method_25364();

        // --- entrance: staggered spring pop-in (not for item slots, they animate themselves) ---
        float appear = 1f;
        if (!cell) {
            float rel = Fx.clamp01((x - Fx.pX) / (float) Math.max(1, Fx.pW) * 0.5f + (y - Fx.pY) / (float) Math.max(1, Fx.pH));
            float e = Fx.since(Fx.curOpen) - 0.06f - rel * 0.16f;
            if (e <= 0f) return;
            appear = Fx.easeOutBack(e / 0.26f);
        }

        // --- press squash: quick dip, springy return ---
        float pp = Fx.clamp01(Fx.since(pressT) / 0.28f);
        float squash = pp < 1f ? 0.07f * Fx.sin(pp * 3.1416f) * (1f - pp * 0.5f) : 0f;
        float sc = (0.86f + 0.14f * appear) * (1f - squash);

        float k = 1f - (float) Math.pow(0.72, dt * 60f);
        float target = (method_49606() && field_22763) ? 1f : 0f;
        hover += (target - hover) * k;
        if ((selected && !wasSel) || (field_22763 && !wasOn)) flash = 1f;
        wasSel = selected;
        wasOn = field_22763;
        flash = Math.max(0f, flash - dt * 3.6f);

        boolean xform = Math.abs(sc - 1f) > 0.002f;
        var m = c.method_51448();
        if (xform) {
            float cx = x + w / 2f, cy = y + h / 2f;
            m.pushMatrix();
            m.translate(cx, cy);
            m.scale(sc, sc);
            m.translate(-cx, -cy);
        }
        drawBody(c, x, y, w, h, pp);
        if (xform) m.popMatrix();

        // sparks fly out of the click point
        if (pp < 1f && !cell && field_22763) {
            for (int i = 0; i < 7; i++) {
                float ang = -1.5708f + (Fx.hash(i, 5) - 0.5f) * 2.6f;
                float sp = 14 + Fx.hash(i, 6) * 26;
                float age = pp * 0.28f;
                int px = clickX + (int) (Math.cos(ang) * sp * age * 3f);
                int py = clickY + (int) (Math.sin(ang) * sp * age * 3f + 40 * age * age);
                int a = (int) (255 * (1 - pp) * (1 - pp));
                c.method_25294(px, py, px + 2, py + 2, Fx.argb(a, i % 2 == 0 ? Fx.WHITE : accent));
            }
        }
    }

    private void drawBody(class_332 c, int x, int y, int w, int h, float pp) {
        float t = Fx.t();
        int acc = accent;
        float breathe = selected ? 0.7f + 0.2f * Fx.sin(t * 4f) : 0f;
        float glowAmt = Math.max(Math.max(hover, breathe), flash);

        if (!cell && glowAmt > 0.03f && field_22763) Fx.glow(c, x, y, w, h, acc, glowAmt * 0.7f, 4);
        int borderA = !field_22763 ? 30 : cell ? (int) (50 + 160 * Math.max(hover, flash)) : (int) (70 + 170 * glowAmt);
        c.method_25294(x, y, x + w, y + h, Fx.argb(255, 0x05090D));
        int top = field_22763 ? Fx.mix(0x1F2D3A, Fx.mix(0x1F2D3A, acc, 0.38f), glowAmt) : 0x151C23;
        int bot = field_22763 ? Fx.mix(0x111A22, Fx.mix(0x111A22, acc, 0.24f), glowAmt) : 0x0D1218;
        c.method_25296(x + 1, y + 1, x + w - 1, y + h - 1, Fx.argb(255, top), Fx.argb(255, bot));
        if (flash > 0.02f) c.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, Fx.argb((int) (110 * flash), Fx.WHITE));

        // ripple band spreading from the click point
        if (pp < 1f && field_22763) {
            int r = (int) (Fx.ease(pp) * (w * 0.6f + 6));
            int a0 = Math.max(x + 1, clickX - r), a1 = Math.min(x + w - 1, clickX + r);
            if (a1 > a0) c.method_25294(a0, y + 1, a1, y + h - 1, Fx.argb((int) (95 * (1 - pp) * (1 - pp)), Fx.WHITE));
        }

        Fx.ring(c, x, y, w, h, Fx.argb(borderA, acc));
        c.method_25294(x + 1, y + 1, x + w - 1, y + 2, 0x20FFFFFF);

        if (!cell && field_22763) {
            int lw = (int) ((w - 4) * Math.max(Fx.smooth(hover), selected ? 1f : 0f));
            c.method_25294(x + 2, y + h - 2, x + 2 + lw, y + h - 1, Fx.argb((int) (90 + 165 * glowAmt), acc));
            if (selected && lw > 8) {
                int rx = x + 2 + (int) ((t * 60f) % lw);
                c.method_25294(rx, y + h - 2, Math.min(rx + 6, x + 2 + lw), y + h - 1, Fx.argb(255, Fx.WHITE));
            }
            if (selected) c.method_25294(x + 1, y + 2, x + 3, y + h - 2, Fx.argb(200, acc));
        }

        if (hover > 0.05f && field_22763) {
            float sx = (t * 80f) % (w + 30) - 15;
            int a = (int) Math.max(x + 1, x + sx), b = (int) Math.min(x + w - 1, x + sx + 10);
            if (b > a) c.method_25294(a, y + 1, b, y + h - 1, Fx.argb((int) (46 * hover), Fx.WHITE));
            if (cell) Fx.sparkle(c, x + w - 3, y + 3, 2, Fx.WHITE, hover * (0.5f + 0.5f * Fx.sin(t * 8f)));
        }

        if (!cell) {
            class_327 tr = class_310.method_1551().field_1772;
            String s = tr.method_27523(method_25369().getString(), w - 6);
            int col = !field_22763 ? 0xFF6A7580 : Fx.argb(255, Fx.mix(0xE8F4F8, Fx.WHITE, glowAmt));
            int tx = x + (w - tr.method_1727(s)) / 2, ty = y + (h - 8) / 2 - (hover > 0.6f ? 1 : 0);
            if (glowAmt > 0.3f && field_22763) Fx.glowText(c, tr, s, tx, ty, Fx.mix(0xE8F4F8, acc, 0.35f));
            else c.method_51439(tr, class_2561.method_43470(s), tx, ty, col, true);
        }
    }
}

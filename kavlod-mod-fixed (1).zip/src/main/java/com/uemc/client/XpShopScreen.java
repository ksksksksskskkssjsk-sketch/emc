package com.uemc.client;

import com.uemc.emc.EmcLogic;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/** XP shop: Buy / Sell toggle, pick how many levels (presets, +/-, Max), live preview of cost or gain, one confirm button. */
public class XpShopScreen extends ServiceScreen {
    private final Runnable onBack;
    private boolean buy = true;
    private int amount = 1;
    private GlowButton bBuy, bSell, confirm;

    public XpShopScreen(Runnable onBack) {
        super("XP SHOP");
        this.onBack = onBack;
        W = 250;
        H = 168;
        accent = Fx.GREEN;
    }

    // ---- same XP curve as the server (display only; server re-checks everything) ----
    private static int pointsAt(int l) {
        if (l <= 16) return l * l + 6 * l;
        if (l <= 31) return (int) Math.round(2.5 * l * l - 40.5 * l + 360);
        return (int) Math.round(4.5 * l * l - 162.5 * l + 2220);
    }

    private static int xpForNext(int l) {
        if (l >= 30) return 112 + (l - 30) * 9;
        if (l >= 15) return 37 + (l - 15) * 5;
        return 7 + l * 2;
    }

    private int level() {
        var p = class_310.method_1551().field_1724;
        return p == null ? 0 : p.field_7520;
    }

    private int points() {
        var p = class_310.method_1551().field_1724;
        if (p == null) return 0;
        return pointsAt(p.field_7520) + Math.round(p.field_7510 * xpForNext(p.field_7520));
    }

    private long buyCost(int n) { return (long) (pointsAt(level() + n) - points()) * EmcLogic.XP_BUY; }

    private long sellGain(int n) {
        int l = level();
        int target = n >= l ? 0 : pointsAt(l - n);
        return Math.max(0, (long) (points() - target)) * EmcLogic.XP_SELL;
    }

    private int maxAmount() {
        if (!buy) return Math.max(1, level());
        int best = 1;
        for (int n = 1; n <= 100; n++) {
            if (buyCost(n) <= ClientEmc.balance) best = n; else break;
        }
        return best;
    }

    private void setAmount(int n) {
        int max = buy ? 100 : Math.max(1, level());
        amount = Math.max(1, Math.min(max, n));
    }

    private GlowButton btn(String label, int x, int y, int w, int h, int color, String tip, Runnable r) {
        GlowButton b = GlowButton.of(label, left + x, top + y, w, h, bb -> r.run());
        b.accent = color;
        if (tip != null) b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        return b;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        ClientPlayNetworking.send(new ActionPayload(11, "", 0)); // refresh EMC balance

        bBuy = btn("Buy XP", 10, 30, 112, 18, Fx.GREEN, "Spend EMC to gain levels (" + EmcLogic.XP_BUY + " EMC per XP point)", () -> { buy = true; setAmount(amount); });
        bSell = btn("Sell XP", 128, 30, 112, 18, Fx.ORANGE, "Turn your levels into EMC (" + EmcLogic.XP_SELL + " EMC per XP point)", () -> { buy = false; setAmount(amount); });

        int[] presets = {1, 5, 10, 30};
        for (int i = 0; i < presets.length; i++) {
            final int v = presets[i];
            btn(String.valueOf(v), 10 + i * 46, 58, 42, 16, Fx.CYAN, v + (v == 1 ? " level" : " levels"), () -> setAmount(v));
        }
        btn("Max", 194, 58, 46, 16, Fx.GOLD, "As many levels as you can afford / have", () -> setAmount(maxAmount()));

        btn("-5", 10, 82, 36, 18, Fx.CYAN, null, () -> setAmount(amount - 5));
        btn("-1", 50, 82, 36, 18, Fx.CYAN, null, () -> setAmount(amount - 1));
        btn("+1", 164, 82, 36, 18, Fx.CYAN, null, () -> setAmount(amount + 1));
        btn("+5", 204, 82, 36, 18, Fx.CYAN, null, () -> setAmount(amount + 5));

        confirm = btn("", 10, 134, 168, 22, Fx.GREEN, "Confirm", () -> {
            if (buy) ClientPlayNetworking.send(new ActionPayload(6, "", amount));
            else ClientPlayNetworking.send(new ActionPayload(5, "", amount >= level() ? 0 : amount));
        });
        btn("Back", 184, 134, 56, 22, Fx.GOLD, null, onBack);
        setAmount(amount);
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        bBuy.selected = buy;
        bSell.selected = !buy;
        setAmount(amount);

        // amount in the middle of the stepper
        String a = amount + (amount == 1 ? " level" : " levels");
        txt(ctx, a, left + W / 2 - field_22793.method_1727(a) / 2, top + 87, WHITE);

        int lv = level();
        int after = buy ? lv + amount : Math.max(0, lv - amount);
        txt(ctx, "Level " + lv + "  ->  " + after, left + 10, top + 108, 0xFF9FE8A0);

        long money = buy ? buyCost(amount) : sellGain(amount);
        boolean ok = !buy || money <= ClientEmc.balance;
        String line = buy ? "Cost: " + Fx.num(money) + " EMC" : "You get: " + Fx.num(money) + " EMC";
        txt(ctx, line, left + 10, top + 120, ok ? 0xFFE0B040 : 0xFFFF7070);
        if (!ok) txt(ctx, "Not enough EMC", left + W - 10 - field_22793.method_1727("Not enough EMC"), top + 120, 0xFFFF7070);

        String c = (buy ? "Buy " : "Sell ") + amount + (amount == 1 ? " level" : " levels");
        txt(ctx, c, confirm.method_46426() + confirm.method_25368() / 2 - field_22793.method_1727(c) / 2, confirm.method_46427() + 7, WHITE);
    }
}

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_7919;
import java.util.List;

/** Home + checkpoints. Teleports cost EMC by distance. Server does the real work. */
public class TeleportScreen extends ServiceScreen {
    private static final int PER = 5;
    private int page = 0;
    /** Checkpoint whose Delete button was pressed once (press again to really delete it). */
    private int armed = -1;
    private String name = "";

    public TeleportScreen() {
        super("TELEPORT");
        H = 232;
        accent = Fx.mix(Fx.CYAN, Fx.GREEN, 0.5f);
        ClientPlayNetworking.send(new ActionPayload(35, "", 0));
    }

    public void refresh() { method_41843(); }

    private static long cost(ClientTp.Loc l) {
        var mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return Fees.tp(true, 0);
        boolean same = mc.field_1687.method_27983().method_29177().toString().equals(l.dim());
        double dx = mc.field_1724.method_23317() - l.x(), dy = mc.field_1724.method_23318() - l.y(), dz = mc.field_1724.method_23321() - l.z();
        return Fees.tp(same, Math.sqrt(dx * dx + dy * dy + dz * dz));
    }

    private static String pos(ClientTp.Loc l) { return (int) l.x() + ", " + (int) l.y() + ", " + (int) l.z(); }

    @Override
    protected void method_25426() {
        super.method_25426();
        ClientTp.Loc home = ClientTp.home;
        GlowButton set = GlowButton.of("Set home here", left + 10, top + 38, 112, 20, b -> ClientPlayNetworking.send(new ActionPayload(30, "", 0)));
        set.accent = Fx.GOLD;
        set.method_47400(class_7919.method_47407(class_2561.method_43470("Save your current spot as home (free)")));
        method_37063(set);
        GlowButton go = GlowButton.of(home == null ? "No home" : "Home - " + Fx.num(cost(home)) + " EMC", left + 128, top + 38, 112, 20,
                b -> ClientPlayNetworking.send(new ActionPayload(31, "", 0)));
        go.field_22763 = home != null;
        go.accent = Fx.GREEN;
        method_37063(go);

        List<ClientTp.Loc> cps = ClientTp.checkpoints;
        page = Math.max(0, Math.min(page, (Math.max(1, cps.size()) - 1) / PER));
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= cps.size()) break;
            ClientTp.Loc l = cps.get(idx);
            final int fi = idx;
            GlowButton g = GlowButton.of(l.name() + " - " + Fx.num(cost(l)) + " EMC", left + 10, top + 78 + i * 20, 182, 18,
                    b -> ClientPlayNetworking.send(new ActionPayload(34, "", fi)));
            g.accent = Fx.CYAN;
            g.method_47400(class_7919.method_47407(class_2561.method_43470(pos(l) + "\n" + l.dim())));
            method_37063(g);
            boolean sure = armed == fi;
            GlowButton del = GlowButton.of(sure ? "Sure?" : "Del", left + 196, top + 78 + i * 20, 44, 18, b -> {
                if (armed == fi) { armed = -1; ClientPlayNetworking.send(new ActionPayload(33, "", fi)); }
                else { armed = fi; method_41843(); }
            });
            del.accent = Fx.RED;
            del.selected = sure;
            del.method_47400(class_7919.method_47407(class_2561.method_43470(sure ? "Press again to delete" : "Delete checkpoint (asks to confirm)")));
            method_37063(del);
        }
        method_37063(GlowButton.of("<", left + 190, top + 59, 24, 17, b -> { if (page > 0) { page--; method_41843(); } }));
        method_37063(GlowButton.of(">", left + 216, top + 59, 24, 17, b -> { if ((page + 1) * PER < ClientTp.checkpoints.size()) { page++; method_41843(); } }));

        class_342 f = new class_342(field_22793, left + 10, top + 186, 110, 18, class_2561.method_43470("Name"));
        f.method_1880(20);
        f.method_1852(name);
        f.method_1863(s -> name = s);
        method_37063(f);
        GlowButton add = GlowButton.of("Add here - " + Fees.CHECKPOINT, left + 124, top + 186, 116, 18, b -> {
            ClientPlayNetworking.send(new ActionPayload(32, name, 0));
            name = "";
            method_41843();
        });
        add.accent = Fx.GOLD;
        add.method_47400(class_7919.method_47407(class_2561.method_43470("Save a checkpoint at your position (" + Fees.CHECKPOINT + " EMC)")));
        method_37063(add);
        GlowButton back = GlowButton.of("Back", left + 10, top + 208, 230, 20, b -> class_310.method_1551().method_1507(new ServicesScreen()));
        back.accent = Fx.GOLD;
        method_37063(back);
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        ClientTp.Loc home = ClientTp.home;
        txt(ctx, home == null ? "Home: not set" : "Home: " + pos(home), left + 10, top + 26, GREY);
        txt(ctx, "Checkpoints " + ClientTp.checkpoints.size() + "/" + Fees.MAX_CHECKPOINTS, left + 10, top + 64, WHITE);
        if (ClientTp.checkpoints.isEmpty()) txt(ctx, "None yet - add one below", left + 10, top + 84, GREY);
        float t = Fx.t();
        for (int i = 0; i < 3; i++) {
            float a = t * 2f + i * 2.094f;
            int sx = left + W - 14 + (int) (Math.cos(a) * 5), sy = top + 30 + (int) (Math.sin(a) * 5);
            ctx.method_25294(sx, sy, sx + 2, sy + 2, Fx.argb(200, i == 0 ? Fx.WHITE : Fx.GREEN));
        }
    }
}

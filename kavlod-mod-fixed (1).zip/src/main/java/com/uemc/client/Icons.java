package com.uemc.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7923;

/** Small vanilla item pictures used as icons on buttons and cards. Looked up once by id, then cached. */
public final class Icons {
    private static final Map<String, class_1799> CACHE = new HashMap<>();

    private Icons() {}

    public static class_1799 stack(String id) {
        class_1799 st = CACHE.get(id);
        if (st == null) {
            class_2960 rl = class_2960.method_12829(id);
            st = (rl != null && class_7923.field_41178.method_10250(rl))
                    ? new class_1799(class_7923.field_41178.method_63535(rl), 1)
                    : class_1799.field_8037;
            CACHE.put(id, st);
        }
        return st;
    }

    /** Draws the item with id (e.g. "minecraft:chest") centred on cx,cy at the given scale (1 = 16px). */
    public static void draw(class_332 c, String id, float cx, float cy, float scale) {
        class_1799 st = stack(id);
        if (!st.method_7960()) Fx.itemScaled(c, st, cx, cy, scale);
    }
}

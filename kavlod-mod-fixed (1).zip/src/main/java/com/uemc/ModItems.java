package com.uemc;

import com.uemc.item.ScannerItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItems {
    public static final class_1792 EMC_SCANNER = register("emc_scanner",
            key -> new ScannerItem(new class_1792.class_1793().method_63686(key).method_7889(1)));

    public static final class_1792 EMC_TABLET = register("emc_tablet",
            key -> new com.uemc.item.TabletItem(new class_1792.class_1793().method_63686(key).method_7889(1)));

    private static class_1792 register(String name, java.util.function.Function<class_5321<class_1792>, class_1792> f) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(UniversalEmc.ID, name));
        return class_2378.method_39197(class_7923.field_41178, key, f.apply(key));
    }

    public static void init() {}
}

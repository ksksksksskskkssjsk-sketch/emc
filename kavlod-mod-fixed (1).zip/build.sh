#!/usr/bin/env bash
# Builds the mod. Output jar: ./dist/
# Needs: Java 21+. Gradle is downloaded automatically if there is no wrapper.
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION=9.2.1

command -v java >/dev/null 2>&1 || { echo "Install Java 21 first: https://adoptium.net"; exit 1; }
JV=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')
[ "${JV:-0}" -ge 21 ] || { echo "Java 21+ needed, found $JV"; exit 1; }

if [ ! -x ./gradlew ]; then
  if command -v gradle >/dev/null 2>&1; then
    G=gradle
  else
    echo "==> Downloading Gradle $GRADLE_VERSION"
    mkdir -p .gradle-dist
    curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o .gradle-dist/g.zip
    unzip -q -o .gradle-dist/g.zip -d .gradle-dist
    G=".gradle-dist/gradle-$GRADLE_VERSION/bin/gradle"
  fi
  "$G" wrapper --gradle-version "$GRADLE_VERSION"
  chmod +x gradlew
fi

./gradlew build --console=plain

rm -rf dist && mkdir dist
cp build/libs/*.jar dist/
rm -f dist/*-sources.jar
echo
echo "Done. Jar is in: $(pwd)/dist"
ls dist

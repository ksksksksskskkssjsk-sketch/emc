# Universal EMC – workstation UI (source files)

Drop the `com/` folder over your mod's source tree (same package layout as your sources jar).
UNTESTED: written without Minecraft/Gradle available, using only intermediary names already present in your sources.
Expect to build once and fix any name that doesn't resolve.

## New files
- net/WorkbenchPayload.java      server -> client: which screen to open + recipe data
- emc/Workbench.java             server logic: recipe loading, craft, stonecutter, grindstone (all validated server-side)
- client/WorkbenchScreen.java    crafting table + stonecutter (search, "can craft" filter, recipe variants, Craft 1/10/max)
- client/DisenchantScreen.java   grindstone (strip enchants, curses stay, small XP)

- client/SellScreen.java         sell from inventory: inventory-shaped grid, multi-select, All/Half/One, live total, Select main/all/same item

## Changed files (small patches to your originals)
- UniversalEmc.java              calls Workbench.init()
- net/ServerNet.java             registers payload; actions 40 (craft) and 41 (disenchant); converter buttons open new screens
- emc/Services.java              tablet "open" for crafting / stonecutter / grindstone / enchant uses new screens
- emc/EmcLogic.java              + addXp(), + sellSlots() (action 42)
- client/TabletScreen.java       "Mode" button is now "Sell items..." and opens SellScreen
- emc/Fees.java                  enchant-table open fee 500 -> 0 (each enchant is paid per use)
- client/UniversalEmcClient.java receiver for WorkbenchPayload
- client/EnchantScreen.java      rewritten: one row per enchant, click name = next level, click a level chip (I-VII) = that level, price on the big button, conflicts greyed out
- client/ConverterMenuScreen.java regrouped layout (Workstations / EMC + XP)
- client/ServicesScreen.java     two-line cards (name + price), grouped Workstations / Services
- client/ServiceScreen.java      panel width W is now adjustable per screen

## Behaviour changes
- Crafting/stonecutter craft from your inventory (no EMC). Tablet still charges its open fee for them (10 EMC each).
- Converter "Enchanting" now opens the pick-your-enchant screen (costs EMC). Set
  Workbench.CONVERTER_CUSTOM_ENCHANT = false to get the vanilla random table back.
- Anvil and smithing are unchanged (vanilla screens).

package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.MenuActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_7919;

/** Menu of the Energy Converter: workstations, EMC shop and XP in three clear groups. Server re-checks distance and block. */
public class ConverterMenuScreen extends class_437 {
    private static final int W = 242, H = 150;
    private final long pos;
    private int left, top;
    private final float openT = Fx.t();
    boolean shopRequested = false;

    public ConverterMenuScreen(long pos) {
        super(class_2561.method_43470("Energy Converter"));
        this.pos = pos;
    }

    private void add(String label, String tip, int x, int y, int w, int color, Act a) {
        GlowButton b = GlowButton.of(label, left + x, top + y, w, 20, x2 -> a.run());
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        b.accent = color;
        method_37063(b);
    }

    private interface Act { void run(); }

    private void station(String label, String tip, int col, int row, int which) {
        add(label, tip, 10 + col * 76, 36 + row * 24, 70, col % 2 == 0 ? Fx.CYAN : Fx.mix(Fx.CYAN, Fx.PURPLE, 0.5f),
                () -> ClientPlayNetworking.send(new MenuActionPayload(pos, which)));
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - W) / 2;
        top = (field_22790 - H) / 2;
        station("Crafting", "Crafting table: search recipes and craft from your inventory", 0, 0, 0);
        station("Stonecutter", "Stonecutter: search and cut blocks from your inventory", 1, 0, 3);
        station("Grindstone", "Grindstone: remove enchants from the item in your hand", 2, 0, 4);
        station("Anvil", "Anvil", 0, 1, 2);
        station("Smithing", "Smithing table", 1, 1, 5);
        station("Enchanting", "Pick the exact enchant and level for the item in your hand (costs EMC)", 2, 1, 1);

        add("EMC Shop", "Buy items with EMC, or sell items from your inventory", 10, 96, 108, Fx.GOLD, () -> {
            shopRequested = true;
            ClientPlayNetworking.send(new MenuActionPayload(pos, 8));
        });
        add("Sell items...", "Pick stacks from your inventory and sell them (or sell everything in one click)", 124, 96, 108, Fx.GOLD,
                () -> net.minecraft.class_310.method_1551().method_1507(new SellScreen(
                        () -> net.minecraft.class_310.method_1551().method_1507(new ConverterMenuScreen(pos)))));
        add("Buy 1 XP level", "Buy 1 XP level (10 EMC per XP point)", 10, 120, 108, Fx.GREEN,
                () -> ClientPlayNetworking.send(new ActionPayload(6, "", 1)));
        add("Sell all XP", "Sell all your XP (8 EMC per XP point)", 124, 120, 108, Fx.GREEN,
                () -> ClientPlayNetworking.send(new ActionPayload(5, "", 0)));
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, Fx.CYAN);
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        Fx.title(ctx, field_22793, "ENERGY CONVERTER", left + 10, top + 10, Fx.CYAN);
        Fx.text(ctx, field_22793, "WORKSTATIONS", left + 10, top + 26, 0xFF7A8A99);
        Fx.text(ctx, field_22793, "EMC + XP", left + 10, top + 86, 0xFF7A8A99);
        // blinking status lights
        float t = Fx.t();
        for (int i = 0; i < 4; i++) {
            float b = 0.5f + 0.5f * Fx.sin(t * (2f + i) + i * 1.7f);
            int lx = left + W - 12 - i * 7;
            Fx.glow(ctx, lx, top + 11, 3, 3, i % 2 == 0 ? Fx.CYAN : Fx.GREEN, b * 0.8f, 2);
            ctx.method_25294(lx, top + 11, lx + 3, top + 14, Fx.argb((int) (120 + 135 * b), i % 2 == 0 ? Fx.CYAN : Fx.GREEN));
        }
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

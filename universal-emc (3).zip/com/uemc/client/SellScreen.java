package com.uemc.client;

import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * Sell from your inventory: laid out like your real inventory (hotbar at the bottom).
 * Click stacks to tick them, pick how much to sell from each (All / Half / One), see the total live, press Sell.
 * Dim stacks have no EMC value. Enchanted stacks get a purple marker and are never auto-selected.
 * Values are computed from the EMC table the server already synced; the server re-checks everything.
 */
public class SellScreen extends ServiceScreen {
    private static final int MODE_ALL = 0, MODE_HALF = 1000, MODE_ONE = 1;

    private final Runnable onBack;
    private final GlowButton[] cell = new GlowButton[36];
    private final TreeSet<Integer> picked = new TreeSet<>();
    private GlowButton sell, mAll, mHalf, mOne;
    private int mode = MODE_ALL, last = -1, ticks = 0, hash = 0;
    private boolean synced = false;

    public SellScreen(Runnable onBack) {
        super("SELL ITEMS");
        this.onBack = onBack;
        W = 262;
        H = 198;
        accent = Fx.GOLD;
    }

    // ---------- helpers ----------
    private class_1799 stack(int slot) {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_31548().method_5438(slot);
    }

    private boolean sellable(int slot) { return ClientEmc.unit(stack(slot)) > 0; }

    private int cellX(int slot) { return left + 8 + (slot < 9 ? slot : (slot - 9) % 9) * 18; }
    private int cellY(int slot) { return slot < 9 ? top + 96 : top + 38 + ((slot - 9) / 9) * 18; }

    private int amount(class_1799 st) {
        int c = st.method_7947();
        return mode == MODE_ALL ? c : mode == MODE_HALF ? Math.max(1, c / 2) : 1;
    }

    private long value(int slot) {
        class_1799 st = stack(slot);
        return ClientEmc.unit(st) * amount(st);
    }

    private long totalValue() { long t = 0; for (int s : picked) t += value(s); return t; }

    private int totalItems() { int t = 0; for (int s : picked) t += amount(stack(s)); return t; }

    private String idOf(int slot) { return class_7923.field_41178.method_10221(stack(slot).method_7909()).toString(); }

    // ---------- selection ----------
    private void toggle(int slot) {
        if (!sellable(slot)) return;
        if (!picked.remove(slot)) picked.add(slot);
        last = slot;
        refresh();
    }

    private void selectRange(int from, int to) {
        for (int s = from; s <= to; s++) if (sellable(s) && !stack(s).method_7942()) picked.add(s);
        refresh();
    }

    private void selectSame() {
        if (last < 0 || stack(last).method_7960()) return;
        String id = idOf(last);
        for (int s = 0; s < 36; s++)
            if (sellable(s) && !stack(s).method_7942() && idOf(s).equals(id)) picked.add(s);
        refresh();
    }

    private void doSell() {
        if (picked.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (int s : picked) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        ClientPlayNetworking.send(new ActionPayload(42, sb.toString(), mode));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); }

        for (int s = 0; s < 36; s++) {
            final int slot = s;
            GlowButton b = GlowButton.slot(cellX(s), cellY(s), x -> toggle(slot));
            b.accent = Fx.GOLD;
            cell[s] = b;
            method_37063(b);
        }

        int rx = left + 176;
        side("Select main", "Select every sellable, non-enchanted stack in your inventory (not the hotbar)", rx, top + 38, () -> selectRange(9, 35));
        side("Select all", "Select every sellable, non-enchanted stack including the hotbar", rx, top + 57, () -> selectRange(0, 35));
        side("Same item", "Select every stack of the same item as the one you clicked last", rx, top + 76, this::selectSame);
        side("Clear", "Unselect everything", rx, top + 95, () -> { picked.clear(); refresh(); });

        mAll = chip("All", "Sell the whole stack", left + 8, MODE_ALL);
        mHalf = chip("Half", "Sell half of each selected stack", left + 52, MODE_HALF);
        mOne = chip("One", "Sell one item from each selected stack", left + 96, MODE_ONE);

        GlowButton back = GlowButton.of("Back", left + 8, top + 174, 56, 18, b -> onBack.run());
        back.accent = Fx.GOLD;
        method_37063(back);
        GlowButton all = GlowButton.of("Sell all items", left + 68, top + 174, 84, 18, b -> ClientPlayNetworking.send(new ActionPayload(4, "", 0)));
        all.accent = Fx.ORANGE;
        all.method_47400(class_7919.method_47407(class_2561.method_43470("Sells every sellable stack in your inventory.\nEnchanted items are kept.")));
        method_37063(all);
        sell = GlowButton.of("Sell selected", left + 156, top + 174, 98, 18, b -> doSell());
        sell.accent = Fx.GOLD;
        method_37063(sell);
        refresh();
    }

    private void side(String label, String tip, int x, int y, Runnable r) {
        GlowButton b = GlowButton.of(label, x, y, 78, 16, bb -> r.run());
        b.accent = Fx.GOLD;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
    }

    private GlowButton chip(String label, String tip, int x, int m) {
        GlowButton b = GlowButton.of(label, x, top + 122, 40, 16, bb -> { mode = m; refresh(); });
        b.accent = Fx.GOLD;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        return b;
    }

    /** Re-reads the inventory: prunes the selection, updates tooltips, buttons and mode chips. */
    private void refresh() {
        picked.removeIf(s -> !sellable(s));
        for (int s = 0; s < 36; s++) {
            GlowButton b = cell[s];
            if (b == null) continue;
            class_1799 st = stack(s);
            long unit = ClientEmc.unit(st);
            b.field_22763 = unit > 0;
            b.selected = picked.contains(s);
            if (st.method_7960()) { b.method_47400(null); continue; }
            String tip = st.method_7964().getString();
            if (unit <= 0) tip += "\nNo EMC value";
            else {
                tip += "\nEach: " + Fx.num(unit) + " EMC";
                tip += "\nSells: " + Fx.num(unit * amount(st)) + " EMC";
                if (st.method_7942()) tip += "\nEnchanted: selling loses the enchants";
            }
            b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        }
        if (mAll != null) { mAll.selected = mode == MODE_ALL; mHalf.selected = mode == MODE_HALF; mOne.selected = mode == MODE_ONE; }
        if (sell != null) sell.field_22763 = !picked.isEmpty();
    }

    @Override
    public void method_25393() {
        if (++ticks % 5 != 0) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        int h = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 s = stack(i);
            h = h * 31 + (s.method_7960() ? 0 : s.method_7947() + s.method_7909().hashCode() + s.method_7919());
        }
        if (h != hash) { hash = h; refresh(); }
    }

    // ---------- drawing ----------
    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        float now = Fx.t();
        txt(ctx, "Click stacks to select. Dim = no EMC value.", left + 8, top + 24, GREY);
        for (int s = 0; s < 36; s++) {
            class_1799 st = stack(s);
            if (st.method_7960()) continue;
            int x = cellX(s) + 1, y = cellY(s) + 1;
            float appear = Fx.ease((now - openT) * 4f - ((s % 9) + (s / 9)) * 0.04f);
            boolean sel = picked.contains(s);
            Fx.item(ctx, st, x, y, cell[s] != null && cell[s].method_49606(), sel, appear, Fx.GOLD);
            if (appear < 0.9f) continue;
            if (!sellable(s)) ctx.method_25294(x, y, x + 16, y + 16, 0xAA101820);
            if (st.method_7942()) ctx.method_25294(x, y, x + 3, y + 3, Fx.argb(255, Fx.PURPLE));
            if (st.method_7947() > 1) {
                String cnt = String.valueOf(st.method_7947());
                txt(ctx, cnt, x + 17 - field_22793.method_1727(cnt), y + 9, WHITE);
            }
        }
        txt(ctx, "Amount per stack", left + 142, top + 126, GREY);

        int n = picked.size();
        if (n == 0) {
            txt(ctx, "Nothing selected", left + 8, top + 146, GREY);
        } else {
            txt(ctx, n + (n == 1 ? " stack" : " stacks") + ", " + Fx.num(totalItems()) + " items", left + 8, top + 146, GREY);
            Fx.glowText(ctx, field_22793, "+" + Fx.num(totalValue()) + " EMC", left + 8, top + 158, Fx.GOLD);
        }
    }
}

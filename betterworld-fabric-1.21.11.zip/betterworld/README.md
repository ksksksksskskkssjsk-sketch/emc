# Better World (Fabric 1.21.11)

Vanilla blocks only. New biomes + structures.

## Build
JDK 21, then:

    ./gradlew build

Jar: `build/libs/betterworld-1.0.0.jar`. Put it in `mods/` with Fabric Loader + Fabric API.
Use a NEW world (or explore new chunks).

## Biomes (10)
| Biome | Replaces part of |
|---|---|
| autumn_forest (orange leaves, fallen logs) | forest, birch forest |
| rosewood_grove (pink trees, bees, ponds) | forest |
| lavender_meadow (purple flowers, ponds) | plains |
| harvest_fields (pumpkins, sunflowers, ponds) | plains |
| redwood_forest (dense giant spruce, boulders) | old growth taigas |
| misty_pines (gray fog, ponds, boulders) | taiga |
| frozen_pine_forest (dense snowy pines) | snowy taiga |
| golden_savanna (gold grass) | savanna |
| heather_moor (boulders, wildflowers) | windswept hills |
| red_dunes (red sand) | desert |

Also: temperature + humidity noise scaled 2x (`data/minecraft/worldgen/noise/`), so biomes are bigger.
Delete those 2 files for vanilla biome size.

Change rarity: `BetterBiomes.SPLITS` (from/to = slice of the humidity range, wider = more common).

## Structures
ruined_watchtower, hermit_cabin, ancient_obelisk, stone_circle, campsite (all with loot).
Rarity: `data/betterworld/worldgen/structure_set/*.json` -> `spacing` (bigger = rarer).

## Add your own
- Biome: copy a file in `data/betterworld/worldgen/biome/`, add a split in `BetterBiomes`.
- Structure: add `.nbt` (save with a Structure Block in-game) to `data/betterworld/structure/`,
  then a template_pool, structure, structure_set and a `has_structure` biome tag (copy an existing one).

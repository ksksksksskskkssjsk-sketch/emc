# Better World (Fabric 1.21.11)

Vanilla blocks only. New biomes + structures.

## GitHub (auto build)
    ./github-setup.sh          # creates repo + pushes (needs gh CLI)
Then GitHub -> Actions -> latest run -> download `betterworld-jar`.
Release jar: `git tag v1.0.0 && git push origin v1.0.0` (jar appears under Releases).

No gh CLI? Make an empty repo on github.com, then:

    git init -b main && git add . && git commit -m init
    git remote add origin https://github.com/YOU/betterworld.git && git push -u origin main

## Build locally
JDK 21, then:

    ./gradlew build

Jar: `build/libs/betterworld-1.0.0.jar`. Put it in `mods/` with Fabric Loader + Fabric API.
Use a NEW world (or explore new chunks).

## Biomes (10)
| Biome | Replaces part of |
|---|---|
| autumn_forest (orange leaves, fallen logs) | forest, birch forest |
| rosewood_grove (pink trees, bees, ponds) | forest |
| lavender_meadow (purple flowers, ponds) | plains |
| harvest_fields (pumpkins, sunflowers, ponds) | plains |
| redwood_forest (dense giant spruce, boulders) | old growth taigas |
| misty_pines (gray fog, ponds, boulders) | taiga |
| frozen_pine_forest (dense snowy pines) | snowy taiga |
| golden_savanna (gold grass) | savanna |
| heather_moor (boulders, wildflowers) | windswept hills |
| red_dunes (red sand) | desert |

## Terrain (buildable + pretty)
Files in `data/minecraft/worldgen/`. Delete any file to restore vanilla for that part.
- `noise/*` : temperature, humidity, continents, erosion 2x wider -> big biomes, big flat plains, big lands.
- `density_function/overworld/jaggedness.json` : x0.4 -> less spiky peaks.
- `density_function/overworld/factor.json` : x1.25 -> smoother slopes, fewer overhangs/cliffs (heights unchanged).

Change rarity: `BetterBiomes.SPLITS` (from/to = slice of the humidity range, wider = more common).

## Structures
ruined_watchtower, hermit_cabin, ancient_obelisk, stone_circle, campsite (all with loot).
Rarity: `data/betterworld/worldgen/structure_set/*.json` -> `spacing` (bigger = rarer).

## Add your own
- Biome: copy a file in `data/betterworld/worldgen/biome/`, add a split in `BetterBiomes`.
- Structure: add `.nbt` (save with a Structure Block in-game) to `data/betterworld/structure/`,
  then a template_pool, structure, structure_set and a `has_structure` biome tag (copy an existing one).

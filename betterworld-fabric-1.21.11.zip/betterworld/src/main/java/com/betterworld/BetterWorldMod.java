package com.betterworld;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BetterWorldMod implements ModInitializer {
	public static final String MOD_ID = "betterworld";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// Biomes, features and structures are data-driven (see src/main/resources/data/betterworld).
		// Mixins place the new biomes in the overworld and give Red Dunes its surface.
		LOGGER.info("Better World loaded: new biomes + structures");
	}
}

package com.betterworld.mixin;

import com.betterworld.world.BetterSurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.SurfaceRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(NoiseGeneratorSettings.class)
public abstract class NoiseGeneratorSettingsMixin {
	@Inject(method = "surfaceRule", at = @At("RETURN"), cancellable = true)
	private void betterworld$surface(CallbackInfoReturnable<SurfaceRules.RuleSource> cir) {
		cir.setReturnValue(BetterSurfaceRules.wrap(cir.getReturnValue()));
	}
}

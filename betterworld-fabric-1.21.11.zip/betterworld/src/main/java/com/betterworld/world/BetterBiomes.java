package com.betterworld.world;

import com.betterworld.BetterWorldMod;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

public final class BetterBiomes {
	public static final ResourceKey<Biome> AUTUMN_FOREST = key("autumn_forest");
	public static final ResourceKey<Biome> ROSEWOOD_GROVE = key("rosewood_grove");
	public static final ResourceKey<Biome> LAVENDER_MEADOW = key("lavender_meadow");
	public static final ResourceKey<Biome> HARVEST_FIELDS = key("harvest_fields");
	public static final ResourceKey<Biome> REDWOOD_FOREST = key("redwood_forest");
	public static final ResourceKey<Biome> MISTY_PINES = key("misty_pines");
	public static final ResourceKey<Biome> FROZEN_PINE_FOREST = key("frozen_pine_forest");
	public static final ResourceKey<Biome> GOLDEN_SAVANNA = key("golden_savanna");
	public static final ResourceKey<Biome> HEATHER_MOOR = key("heather_moor");
	public static final ResourceKey<Biome> RED_DUNES = key("red_dunes");

	/** A slice [from, to] (0..1) of a vanilla biome's humidity range that becomes the new biome. */
	public record Split(ResourceKey<Biome> biome, double from, double to) {}

	/**
	 * Vanilla biome -> new biomes that take over part of its area.
	 * Slices for one vanilla biome must not overlap and must be listed in ascending order.
	 * Wider slice = more common.
	 */
	public static final Map<ResourceKey<Biome>, List<Split>> SPLITS = Map.ofEntries(
		Map.entry(Biomes.FOREST, List.of(
			new Split(AUTUMN_FOREST, 0.10, 0.38),
			new Split(ROSEWOOD_GROVE, 0.62, 0.90))),
		Map.entry(Biomes.BIRCH_FOREST, List.of(new Split(AUTUMN_FOREST, 0.35, 0.65))),
		Map.entry(Biomes.PLAINS, List.of(
			new Split(LAVENDER_MEADOW, 0.10, 0.38),
			new Split(HARVEST_FIELDS, 0.62, 0.90))),
		Map.entry(Biomes.OLD_GROWTH_SPRUCE_TAIGA, List.of(new Split(REDWOOD_FOREST, 0.25, 0.75))),
		Map.entry(Biomes.OLD_GROWTH_PINE_TAIGA, List.of(new Split(REDWOOD_FOREST, 0.25, 0.75))),
		Map.entry(Biomes.TAIGA, List.of(new Split(MISTY_PINES, 0.30, 0.70))),
		Map.entry(Biomes.SNOWY_TAIGA, List.of(new Split(FROZEN_PINE_FOREST, 0.30, 0.70))),
		Map.entry(Biomes.SAVANNA, List.of(new Split(GOLDEN_SAVANNA, 0.30, 0.75))),
		Map.entry(Biomes.WINDSWEPT_HILLS, List.of(new Split(HEATHER_MOOR, 0.30, 0.70))),
		Map.entry(Biomes.DESERT, List.of(new Split(RED_DUNES, 0.30, 0.80)))
	);

	private static ResourceKey<Biome> key(String path) {
		return ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath(BetterWorldMod.MOD_ID, path));
	}

	private BetterBiomes() {}
}

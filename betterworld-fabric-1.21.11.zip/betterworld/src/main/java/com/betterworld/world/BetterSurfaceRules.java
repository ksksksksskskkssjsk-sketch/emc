package com.betterworld.world;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.SurfaceRules;

public final class BetterSurfaceRules {
	private static final SurfaceRules.RuleSource RED_SAND = SurfaceRules.state(Blocks.RED_SAND.defaultBlockState());
	private static final SurfaceRules.RuleSource RED_SANDSTONE = SurfaceRules.state(Blocks.RED_SANDSTONE.defaultBlockState());

	/** Red Dunes: red sand on top, red sandstone below. */
	private static final SurfaceRules.RuleSource RED_DUNES = SurfaceRules.ifTrue(
		SurfaceRules.isBiome(BetterBiomes.RED_DUNES),
		SurfaceRules.ifTrue(
			SurfaceRules.abovePreliminarySurface(),
			SurfaceRules.sequence(
				SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR, RED_SAND),
				SurfaceRules.ifTrue(SurfaceRules.UNDER_FLOOR, RED_SANDSTONE))));

	public static SurfaceRules.RuleSource wrap(SurfaceRules.RuleSource vanilla) {
		return SurfaceRules.sequence(RED_DUNES, vanilla);
	}

	private BetterSurfaceRules() {}
}

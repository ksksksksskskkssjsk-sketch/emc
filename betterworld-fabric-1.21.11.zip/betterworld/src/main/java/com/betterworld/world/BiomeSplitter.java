package com.betterworld.world;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;

public final class BiomeSplitter {
	/**
	 * Wraps the consumer vanilla uses to register overworld biome parameters.
	 * Each targeted vanilla cell is cut along its humidity range:
	 * vanilla / new biome / vanilla / new biome / vanilla ...
	 */
	public static Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> wrap(
			Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> out) {
		return pair -> {
			List<BetterBiomes.Split> splits = BetterBiomes.SPLITS.get(pair.getSecond());
			Climate.ParameterPoint p = pair.getFirst();
			Climate.Parameter h = p.humidity();
			long span = h.max() - h.min();
			if (splits == null || span < 600) {
				out.accept(pair);
				return;
			}
			long cursor = h.min();
			for (BetterBiomes.Split s : splits) {
				long a = h.min() + Math.round(span * s.from());
				long b = h.min() + Math.round(span * s.to());
				if (a - 1 >= cursor) {
					out.accept(Pair.of(with(p, new Climate.Parameter(cursor, a - 1)), pair.getSecond()));
				}
				out.accept(Pair.of(with(p, new Climate.Parameter(a, b)), s.biome()));
				cursor = b + 1;
			}
			if (cursor <= h.max()) {
				out.accept(Pair.of(with(p, new Climate.Parameter(cursor, h.max())), pair.getSecond()));
			}
		};
	}

	private static Climate.ParameterPoint with(Climate.ParameterPoint p, Climate.Parameter humidity) {
		return new Climate.ParameterPoint(p.temperature(), humidity, p.continentalness(),
			p.erosion(), p.depth(), p.weirdness(), p.offset());
	}

	private BiomeSplitter() {}
}

#!/usr/bin/env bash
# One-time: create the GitHub repo and push. Needs git + GitHub CLI (https://cli.github.com), logged in: gh auth login
set -euo pipefail
git init -b main
git add .
git commit -m "Better World mod"
gh repo create betterworld --public --source=. --push
echo
echo "Pushed. Build runs automatically: GitHub -> Actions tab -> download 'betterworld-jar'."
echo "To publish a release jar:  git tag v1.0.0 && git push origin v1.0.0"

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/**
 * Time control (Overworld). Left: skip to morning / noon / sunset / midnight. Right: skip forward 1, 3, 6 or 12 hours.
 * Speed: FAST = watch the sky race past, INSTANT = jump. The price (per in-game hour) is on every button; the server charges it.
 */
public class TimeScreen extends ServiceScreen {
    private static boolean fast = true;   // remembered while the game runs

    private final Runnable back;
    private final GlowButton[] abs = new GlowButton[4], rel = new GlowButton[4];
    private GlowButton speed;
    private long lastBal = Long.MIN_VALUE, lastTime = -1;

    public TimeScreen(Runnable back) {
        super("TIME CONTROL");
        this.back = back;
        W = 300;
        H = 208;
        accent = Fx.CYAN;
    }

    private long now() {
        class_310 mc = class_310.method_1551();
        return mc.field_1687 == null ? 0 : mc.field_1687.method_8532();
    }

    private static int dayTick(long t) { return (int) (((t % 24000) + 24000) % 24000); }

    private static String clock(long t) {
        int d = dayTick(t);
        return String.format("%02d:%02d", (d / 1000 + 6) % 24, (d % 1000) * 60 / 1000);
    }

    private static String phase(long t) {
        int d = dayTick(t);
        return d < 12000 ? "Day" : d < 13000 ? "Sunset" : d < 23000 ? "Night" : "Sunrise";
    }

    private static void tip(GlowButton b, String s) { b.method_47400(class_7919.method_47407(class_2561.method_43470(s))); }

    @Override
    protected void method_25426() {
        super.method_25426();
        for (int i = 0; i < 4; i++) {
            final int k = i;
            abs[i] = GlowButton.of("", left + 10, top + 84 + i * 24, 135, 20,
                    b -> ClientPlayNetworking.send(new ActionPayload(15, "abs" + (fast ? ":fast" : ":instant"), Fees.TIME_TARGETS[k])));
            abs[i].accent = Fx.CYAN;
            method_37063(abs[i]);
            rel[i] = GlowButton.of("", left + 155, top + 84 + i * 24, 135, 20,
                    b -> ClientPlayNetworking.send(new ActionPayload(15, "rel" + (fast ? ":fast" : ":instant"), Fees.TIME_HOURS[k] * 1000)));
            rel[i].accent = Fx.GOLD;
            method_37063(rel[i]);
        }
        speed = GlowButton.of("", left + 10, top + 184, 135, 18, b -> { fast = !fast; refresh(); });
        speed.accent = Fx.PURPLE;
        method_37063(speed);
        GlowButton close = GlowButton.of("Back", left + 155, top + 184, 135, 18, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);
        refresh();
    }

    private void style(GlowButton b, String name, long delta) {
        long fee = Fees.timeCost(delta);
        if (delta <= 0) { b.method_25355(class_2561.method_43470(name + "  (now)")); b.field_22763 = false; return; }
        boolean ok = fee <= ClientEmc.balance;
        b.method_25355(class_2561.method_43470(name + "  " + Fx.num(fee) + " EMC"));
        b.field_22763 = ok;
        tip(b, name + "\n" + (delta / 1000) + "h " + ((delta % 1000) * 60 / 1000) + "m  -  " + Fx.num(fee) + " EMC");
    }

    private void refresh() {
        long t = now();
        lastBal = ClientEmc.balance;
        lastTime = t;
        for (int i = 0; i < 4; i++) {
            style(abs[i], Fees.TIME_NAMES[i], Fees.timeDelta(t, Fees.TIME_TARGETS[i]));
            style(rel[i], "+" + Fees.TIME_HOURS[i] + (Fees.TIME_HOURS[i] == 1 ? " hour" : " hours"), Fees.TIME_HOURS[i] * 1000L);
        }
        speed.method_25355(class_2561.method_43470(fast ? "Speed: FAST" : "Speed: INSTANT"));
        tip(speed, fast ? "Watch the sky race forward (about 4 in-game hours per second)" : "Jump straight to the new time");
    }

    @Override
    public void method_25393() {
        long t = now();
        // prices only change when a new in-game hour starts or the balance moves
        if (ClientEmc.balance != lastBal || t / 1000 != lastTime / 1000) refresh();
        lastTime = t;
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        long t = now();
        int d = dayTick(t);
        boolean night = d >= 13000 && d < 23000;
        Fx.showcase(ctx, Icons.stack("minecraft:clock"), left + 30, top + 48, 1.4f, night ? Fx.PURPLE : Fx.GOLD);
        txt(ctx, clock(t), left + 62, top + 28, WHITE);
        txt(ctx, phase(t) + "  -  day " + (t / 24000 + 1), left + 100, top + 28, night ? 0xFFB090FF : 0xFFE0B040);

        // sky strip: day / sunset / night / sunrise with a moving marker
        int bx = left + 62, by = top + 44, bw = 228, bh = 10;
        int[] edge = {0, 12000, 13000, 23000, 24000};
        int[] col = {0x5AA8E8, 0xE08040, 0x161C3C, 0xE0A060};
        for (int i = 0; i < 4; i++) {
            int x0 = bx + edge[i] * bw / 24000, x1 = bx + edge[i + 1] * bw / 24000;
            ctx.method_25296(x0, by, x1, by + bh, Fx.argb(255, Fx.mix(col[i], Fx.WHITE, 0.15f)), Fx.argb(255, col[i]));
        }
        Fx.ring(ctx, bx - 1, by - 1, bw + 2, bh + 2, Fx.argb(120, Fx.CYAN));
        int mxp = bx + d * bw / 24000;
        Fx.glow(ctx, mxp - 1, by - 2, 3, bh + 4, Fx.WHITE, 0.9f, 3);
        ctx.method_25294(mxp - 1, by - 3, mxp + 2, by + bh + 3, 0xFFFFFFFF);
        small(ctx, "6:00", bx, by + 13);
        small(ctx, "12:00", bx + bw / 4 - 8, by + 13);
        small(ctx, "18:00", bx + bw / 2 - 8, by + 13);
        small(ctx, "0:00", bx + bw * 3 / 4 - 6, by + 13);

        txt(ctx, "SKIP TO", left + 10, top + 72, 0xFF7A8A99);
        txt(ctx, "SKIP FORWARD", left + 155, top + 72, 0xFF7A8A99);
        small(ctx, Fx.num(Fees.TIME_HOUR_FEE) + " EMC per in-game hour skipped. Overworld only.", left + 10, top + 177);
    }

    private void small(class_332 c, String s, int x, int y) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.6f, 0.6f);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (x / 0.6f), (int) (y / 0.6f), 0xFF7A8A99, false);
        m.popMatrix();
    }
}

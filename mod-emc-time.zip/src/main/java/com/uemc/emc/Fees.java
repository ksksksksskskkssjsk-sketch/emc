package com.uemc.emc;

/** EMC prices of tablet upgrades. Shared by server (charges) and client (display). */
public final class Fees {
    private Fees() {}

    public static final long REPAIR_PER_POINT = 2;

    public static final String[] SMELT_NAMES = {"Slow", "Fast", "Turbo", "Instant"};
    public static final int[] SMELT_INTERVAL = {10, 4, 1, 1};   // ticks between batches
    public static final int[] SMELT_BATCH = {1, 1, 1, 8};       // items per batch
    public static final long[] SMELT_FEE = {1, 3, 8, 20};       // EMC per item (+ any value gained)

    /** Total price of having an enchant at this level. Upgrading pays the difference. */
    public static long enchant(int level) { return level <= 0 ? 0 : 1000L * level * level + 2000; }

    /** Hard cap for every enchant: level X (10). */
    public static final int MAX_ENCHANT_LEVEL = 10;

    /** Highest level you can buy: single-level enchants (Mending, Silk Touch...) stay 1, everything else goes to X (10). */
    public static int maxLevel(int vanillaMax) { return vanillaMax <= 1 ? 1 : MAX_ENCHANT_LEVEL; }

    // ---- time skip (Overworld) ----
    public static final long TIME_HOUR_FEE = 150;     // EMC per in-game hour (1000 ticks) skipped, rounded up
    public static final int TIME_FAST_STEP = 200;     // ticks of game time added per server tick in "fast" mode
    public static final int[] TIME_TARGETS = {0, 6000, 12000, 18000};
    public static final String[] TIME_NAMES = {"Morning", "Noon", "Sunset", "Midnight"};
    public static final int[] TIME_HOURS = {1, 3, 6, 12};

    /** Ticks from now to the next time-of-day target (0 = already there). */
    public static long timeDelta(long now, int target) { return (((target - now) % 24000) + 24000) % 24000; }
    public static long timeCost(long delta) { return delta <= 0 ? 0 : ((delta + 999) / 1000) * TIME_HOUR_FEE; }

    public static final int MAX_CHECKPOINTS = 12;
    public static final long CHECKPOINT = 100;
    public static final int TP_COOLDOWN_TICKS = 100;

    /** Teleport price: 100 + 1 EMC per 10 blocks (same dimension) or flat 1000 across dimensions. Max 5000. */
    public static long tp(boolean sameDim, double dist) {
        return Math.min(5000, 100 + (sameDim ? (long) (dist / 10) : 1000));
    }
}

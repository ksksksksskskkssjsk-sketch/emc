package com.uemc.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

/** Shared UI effects: glow, animated panels, particles, item showcase, counters, popups. */
public final class Fx {
    private Fx() {}

    public static final int CYAN = 0x00FFDD, GOLD = 0xFFC040, PURPLE = 0xB080FF, ORANGE = 0xFF8030,
            GREEN = 0x50FF90, RED = 0xFF5060, WHITE = 0xFFFFFF;

    private static final long START = System.nanoTime();
    private static final float WRAP = 10_000f;
    /** Seconds on a smooth clock (wraps every 10000 s, so floats keep ~1 ms precision). */
    public static float t() { return ((System.nanoTime() - START) / 1_000_000L % 10_000_000L) / 1000f; }
    /** Seconds elapsed since t0 (safe across the clock wrap). */
    public static float since(float t0) { float d = t() - t0; return d < 0 ? d + WRAP : d; }
    public static int argb(int a, int rgb) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    public static float clamp01(float x) { return x < 0 ? 0 : Math.min(x, 1); }
    public static float ease(float x) { x = clamp01(x); return 1 - (1 - x) * (1 - x) * (1 - x); }
    public static float sin(float x) { return (float) Math.sin(x); }

    public static int mix(int a, int b, float f) {
        f = clamp01(f);
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }

    static float hash(int i, int k) {
        int n = i * 374761393 + k * 668265263;
        n = (n ^ (n >>> 13)) * 1274126177;
        return ((n ^ (n >>> 16)) & 0xFFFF) / 65535f;
    }

    public static String num(long v) { return String.format("%,d", v); }

    public static float smooth(float x) { x = clamp01(x); return x * x * (3 - 2 * x); }
    /** Ease-out with a small overshoot: pop-ins feel springy. */
    public static float easeOutBack(float x) {
        x = clamp01(x);
        float c1 = 1.70158f, c3 = c1 + 1, k = x - 1;
        return 1 + c3 * k * k * k + c1 * k * k;
    }

    // ---------- shapes ----------
    private static final int[][] HALF = new int[48][];
    /** Half-width of every row of a circle with radius r, cached (the UI redraws these every frame). */
    private static int[] halves(int r) {
        if (r < 0 || r >= HALF.length) return null;
        int[] a = HALF[r];
        if (a == null) {
            a = new int[2 * r + 1];
            for (int dy = -r; dy <= r; dy++) a[dy + r] = (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            HALF[r] = a;
        }
        return a;
    }

    /** Filled circle (row by row, so it is really round). */
    public static void disc(class_332 c, int cx, int cy, int r, int argb) {
        if (r <= 0) { c.method_25294(cx, cy, cx + 1, cy + 1, argb); return; }
        int[] hv = halves(r);
        for (int dy = -r; dy <= r; dy++) {
            int half = hv != null ? hv[dy + r] : (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            c.method_25294(cx - half, cy + dy, cx + half + 1, cy + dy + 1, argb);
        }
    }

    /** One-pixel circle outline. */
    public static void circle(class_332 c, int cx, int cy, int r, int argb) {
        if (r <= 0) return;
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            int inner = (int) Math.round(Math.sqrt(Math.max(0.0, (double) (r - 1) * (r - 1) - (double) dy * dy)));
            int w = Math.max(1, half - inner);
            c.method_25294(cx - half, cy + dy, cx - half + w, cy + dy + 1, argb);
            c.method_25294(cx + half - w + 1, cy + dy, cx + half + 1, cy + dy + 1, argb);
        }
    }

    /** Soft round glow: stacked discs that fade outwards. */
    public static void softGlow(class_332 c, int cx, int cy, int r, int rgb, float strength) {
        int layers = Math.max(3, Math.min(5, r / 2));
        for (int i = layers; i >= 1; i--) {
            float f = (float) i / layers;
            disc(c, cx, cy, (int) (r * f), argb((int) (strength * 26 * (1.2f - f)), rgb));
        }
    }

    /** Four-point star sparkle. size = arm length in pixels. */
    public static void sparkle(class_332 c, int cx, int cy, int size, int rgb, float alpha) {
        int a = (int) (255 * clamp01(alpha));
        if (a <= 4 || size <= 0) return;
        for (int i = 1; i <= size; i++) {
            int fa = (int) (a * (1 - (i - 1f) / size));
            int col = argb(fa, rgb);
            c.method_25294(cx - i, cy, cx - i + 1, cy + 1, col);
            c.method_25294(cx + i, cy, cx + i + 1, cy + 1, col);
            c.method_25294(cx, cy - i, cx + 1, cy - i + 1, col);
            c.method_25294(cx, cy + i, cx + 1, cy + i + 1, col);
        }
        c.method_25294(cx, cy, cx + 1, cy + 1, argb(a, WHITE));
    }

    // ---------- glow / outline ----------
    public static void glow(class_332 c, int x, int y, int w, int h, int rgb, float s, int layers) {
        for (int i = layers; i >= 1; i--) {
            float f = 1f - (i - 1f) / (layers + 1f);
            c.method_25294(x - i, y - i, x + w + i, y + h + i, argb((int) (s * 50 * f * f / (0.6f + i * 0.5f)), rgb));
        }
    }

    public static void ring(class_332 c, int x, int y, int w, int h, int argb) {
        c.method_25294(x, y, x + w, y + 1, argb);
        c.method_25294(x, y + h - 1, x + w, y + h, argb);
        c.method_25294(x, y + 1, x + 1, y + h - 1, argb);
        c.method_25294(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    /** Point on a rectangle's border, pos = pixels travelled clockwise from the top-left. */
    private static int[] perim(int x, int y, int w, int h, int pos) {
        int per = 2 * (w + h) - 4;
        pos = ((pos % per) + per) % per;
        if (pos < w) return new int[]{x + pos, y};
        pos -= w;
        if (pos < h - 1) return new int[]{x + w - 1, y + 1 + pos};
        pos -= h - 1;
        if (pos < w - 1) return new int[]{x + w - 2 - pos, y + h - 1};
        pos -= w - 1;
        return new int[]{x, y + h - 2 - pos};
    }

    /** A bright comet that runs around the border, with a fading tail. */
    public static void chase(class_332 c, int x, int y, int w, int h, int rgb, float speed, int tail) {
        int per = 2 * (w + h) - 4;
        int head = (int) ((t() * speed * 60f) % per);
        for (int k = 0; k < tail; k++) {
            int[] p = perim(x, y, w, h, head - k * 2);
            float f = 1f - (float) k / tail;
            c.method_25294(p[0], p[1], p[0] + 1, p[1] + 1, argb((int) (60 + 195 * f * f), k == 0 ? WHITE : rgb));
            if (k < tail / 2) c.method_25294(p[0] - 1, p[1] - 1, p[0] + 2, p[1] + 2, argb((int) (28 * f), rgb));
        }
    }

    // ---------- animated panel ----------
    /** Open time + bounds of the panel on screen: buttons use them to stagger their pop-in. */
    public static float curOpen = -1000f;
    public static int pX, pY, pW = 1, pH = 1;

    /** Panel that springs open (scale 0.90 -> 1 with a little overshoot). */
    public static void panel(class_332 c, int x, int y, int w, int h, int rgb, float openT) {
        curOpen = openT; pX = x; pY = y; pW = w; pH = h;
        float p = clamp01(since(openT) / 0.28f);
        if (p >= 1f) { panelBody(c, x, y, w, h, rgb); return; }
        float s = 0.90f + 0.10f * easeOutBack(p);
        float cx = x + w / 2f, cy = y + h / 2f;
        var m = c.method_51448();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(s, s);
        m.translate(-cx, -cy);
        panelBody(c, x, y, w, h, rgb);
        m.popMatrix();
    }

    public static void panel(class_332 c, int x, int y, int w, int h, int rgb) { panelBody(c, x, y, w, h, rgb); }

    private static void panelBody(class_332 c, int x, int y, int w, int h, int rgb) {
        float t = t();
        float pulse = 0.55f + 0.35f * sin(t * 1.6f);
        glow(c, x, y, w, h, rgb, pulse, 7);
        c.method_25294(x, y, x + w, y + h, 0xFF081016);
        c.method_25296(x + 1, y + 1, x + w - 1, y + h - 1, argb(255, mix(0x1F2F3D, rgb, 0.10f)), 0xFF0A131B);
        // breathing glow rising from the bottom
        c.method_25296(x + 1, y + h - 22, x + w - 1, y + h - 1, argb(0, rgb), argb((int) (22 + 16 * sin(t * 1.3f)), rgb));
        // slowly scrolling scanlines
        int off = (int) (t * 8f) % 4;
        for (int yy = y + 2 + off; yy < y + h - 2; yy += 4) c.method_25294(x + 1, yy, x + w - 1, yy + 1, 0x10000000);
        // drifting particles with a soft trail; a few are sparkles
        for (int i = 0; i < 24; i++) {
            float sp = 6 + hash(i, 2) * 16;
            int px = x + 2 + (int) (hash(i, 1) * (w - 5)) + (int) (sin(t * 0.8f + i) * 2f);
            float cycle = (t * sp + hash(i, 3) * h) % (h - 4);
            int py = y + h - 3 - (int) cycle;
            float tw = 0.5f + 0.5f * sin(t * 3f + i);
            float edge = Math.min(1f, Math.min(cycle, h - 4 - cycle) / 14f);   // fade in/out at the ends
            int col = argb((int) ((30 + 110 * tw) * edge), i % 3 == 0 ? WHITE : rgb);
            if (i % 9 == 0) { sparkle(c, px, py, 2 + (int) (2 * tw), rgb, 0.8f * edge * tw + 0.1f); continue; }
            int sz = 1 + (i % 4 == 0 ? 1 : 0);
            c.method_25294(px, py, px + sz, py + sz, col);
            c.method_25294(px, py + sz, px + sz, py + sz + 2, argb((int) (25 * edge * tw), rgb));
        }
        // moving shine band
        float sx = (t * 45f) % (w + 80) - 40;
        int x0 = (int) Math.max(x + 1, x + sx), x1 = (int) Math.min(x + w - 1, x + sx + 26);
        if (x1 > x0) c.method_25294(x0, y + 1, x1, y + h - 1, 0x09FFFFFF);
        int m0 = (int) Math.max(x + 1, x + sx + 8), m1 = (int) Math.min(x + w - 1, x + sx + 16);
        if (m1 > m0) c.method_25294(m0, y + 1, m1, y + h - 1, 0x0CFFFFFF);
        // animated top/bottom edges
        for (int sxp = 0; sxp < w; sxp += 6) {
            float a = 0.5f + 0.5f * sin(t * 3f - sxp * 0.06f);
            int col = argb((int) (60 + 195 * a * a), rgb);
            c.method_25294(x + sxp, y, Math.min(x + w, x + sxp + 6), y + 1, col);
            c.method_25294(x + sxp, y + h - 1, Math.min(x + w, x + sxp + 6), y + h, argb((int) (40 + 120 * (1 - a)), rgb));
        }
        c.method_25296(x, y, x + 1, y + h, argb(140, rgb), argb(60, rgb));
        c.method_25296(x + w - 1, y, x + w, y + h, argb(140, rgb), argb(60, rgb));
        // glowing accent strip under the top edge
        c.method_25296(x + 1, y + 1, x + w - 1, y + 5, argb(80, rgb), argb(0, rgb));
        // comet running around the border
        chase(c, x, y, w, h, rgb, 0.9f, 22);
        // corner brackets (breathing)
        int cb = argb((int) (210 + 45 * sin(t * 2.5f)), mix(rgb, WHITE, 0.55f));
        c.method_25294(x, y, x + 7, y + 1, cb);
        c.method_25294(x, y, x + 1, y + 7, cb);
        c.method_25294(x + w - 7, y, x + w, y + 1, cb);
        c.method_25294(x + w - 1, y, x + w, y + 7, cb);
        c.method_25294(x, y + h - 1, x + 7, y + h, cb);
        c.method_25294(x, y + h - 7, x + 1, y + h, cb);
        c.method_25294(x + w - 7, y + h - 1, x + w, y + h, cb);
        c.method_25294(x + w - 1, y + h - 7, x + w, y + h, cb);
    }

    /** Opening animation: fade-in, a scanning line with a bright trail, and a flash on the borders. */
    public static void openFade(class_332 c, int x, int y, int w, int h, float openT) {
        float p = since(openT) / 0.45f;
        if (p >= 1 || p < 0) return;
        float e = ease(p);
        c.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, argb((int) ((1 - e) * (1 - e) * 255), 0x081016));
        int ly = y + (int) (e * h);
        c.method_25296(x, Math.max(y, ly - 14), x + w, ly, argb(0, CYAN), argb(150, CYAN));
        c.method_25294(x, ly, x + w, ly + 1, argb(255, WHITE));
        int fl = (int) (140 * (1 - p) * (1 - p));
        ring(c, x - 1, y - 1, w + 2, h + 2, argb(fl, WHITE));
        glow(c, x, y, w, h, CYAN, (1 - p) * 1.3f, 5);
    }

    // ---------- text ----------
    public static void text(class_332 c, class_327 tr, String s, int x, int y, int argb) {
        c.method_51439(tr, class_2561.method_43470(s), x, y, argb, true);
    }

    public static void glowText(class_332 c, class_327 tr, String s, int x, int y, int rgb) {
        int g = argb(40, rgb), g2 = argb(18, rgb);
        class_2561 m = class_2561.method_43470(s);
        c.method_51439(tr, m, x - 2, y, g2, false);
        c.method_51439(tr, m, x + 2, y, g2, false);
        c.method_51439(tr, m, x, y - 2, g2, false);
        c.method_51439(tr, m, x, y + 2, g2, false);
        c.method_51439(tr, m, x - 1, y, g, false);
        c.method_51439(tr, m, x + 1, y, g, false);
        c.method_51439(tr, m, x, y - 1, g, false);
        c.method_51439(tr, m, x, y + 1, g, false);
        c.method_51439(tr, m, x, y, argb(255, rgb), true);
    }

    /** Title with a light wave running through the letters and a sweeping underline. */
    public static void title(class_332 c, class_327 tr, String s, int x, int y, int rgb) {
        float t = t();
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            float b = 0.5f + 0.5f * sin(t * 3.2f - i * 0.45f);
            int dy = b > 0.93f ? -1 : 0;
            c.method_51439(tr, class_2561.method_43470(ch), cx, y + dy, argb(255, mix(rgb, WHITE, b * b * 0.9f)), true);
            cx += tr.method_1727(ch);
        }
        int tw = cx - x;
        c.method_25294(x, y + 10, x + tw, y + 11, argb(50, rgb));
        float sp = (t * 40f) % (tw + 30) - 15;
        int a = (int) Math.max(x, x + sp), b2 = (int) Math.min(x + tw, x + sp + 14);
        if (b2 > a) c.method_25296(a, y + 10, b2, y + 11, argb(230, WHITE), argb(230, rgb));
    }

    /** Pop-up number: springs in (scales down from big), rises, glows, fades. age/life in seconds. */
    public static void popText(class_332 c, class_327 tr, String s, int x, int y, float age, float life, int rgb) {
        float fade = clamp01(1 - age / life);
        float sc = 1f + 0.6f * Math.max(0f, 1f - age * 5f);
        int w = tr.method_1727(s);
        var m = c.method_51448();
        m.pushMatrix();
        m.translate(x + w / 2f, y + 4f);
        m.scale(sc, sc);
        m.translate(-w / 2f, -4f);
        glowText(c, tr, s, 0, 0, mix(rgb, WHITE, 0.15f * fade));
        m.popMatrix();
    }

    // ---------- bar ----------
    public static void bar(class_332 c, int x, int y, int w, int h, float frac, int rgb) {
        float t = t();
        c.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF05090D);
        c.method_25294(x, y, x + w, y + h, 0xFF101820);
        int fw = (int) (w * clamp01(frac));
        if (fw <= 0) return;
        c.method_25296(x, y, x + fw, y + h, argb(255, mix(rgb, WHITE, 0.45f)), argb(255, rgb));
        c.method_25294(x, y, x + fw, y + 1, 0x50FFFFFF);
        for (int tx = x + 8; tx < x + fw; tx += 8) c.method_25294(tx, y + h - 2, tx + 1, y + h, 0x30000000);
        float sx = (t * 55f) % (fw + 30) - 14;
        int a = (int) Math.max(x, x + sx), b = (int) Math.min(x + fw, x + sx + 10);
        if (b > a) c.method_25294(a, y, b, y + h, 0x60FFFFFF);
        glow(c, x + fw - 1, y, 1, h, rgb, 0.7f, 3);
        sparkle(c, x + fw, y + h / 2, 3, rgb, 0.5f + 0.5f * sin(t * 6f));
    }

    // ---------- items ----------
    /** Draws a stack scaled (about its centre) with an optional bob. */
    public static void itemScaled(class_332 c, class_1799 st, float cx, float cy, float scale) {
        if (scale <= 0.02f) return;
        var m = c.method_51448();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        m.translate(-8, -8);
        c.method_51427(st, 0, 0);
        m.popMatrix();
    }

    // per-item animation state (hover / selected amounts glide instead of snapping)
    private static final java.util.HashMap<Long, float[]> ITEM_ST = new java.util.HashMap<>();

    /** {hoverAmount, selectedAmount, lastTime} for the item drawn at x,y: eases towards the current hover / selected state. */
    private static float[] itemState(int x, int y, boolean hover, boolean sel) {
        long key = ((long) x << 32) ^ (y & 0xFFFFFFFFL);
        float now = t();
        float[] st = ITEM_ST.get(key);
        if (st == null) {
            if (ITEM_ST.size() > 600) ITEM_ST.clear();   // screens change: old positions are not needed any more
            st = new float[]{hover ? 1f : 0f, sel ? 1f : 0f, now};
            ITEM_ST.put(key, st);
            return st;
        }
        float dt = now - st[2];
        st[2] = now;
        if (dt < 0f || dt > 0.5f) { st[0] = hover ? 1f : 0f; st[1] = sel ? 1f : 0f; return st; }   // screen was closed for a while: no glide
        float k = 1f - (float) Math.pow(0.70, dt * 60f);
        st[0] += ((hover ? 1f : 0f) - st[0]) * k;
        st[1] += ((sel ? 1f : 0f) - st[1]) * k;
        return st;
    }

    /** Grid item: springy pop-in, smooth hover zoom, selected glow + bob + orbiting sparkles, and a ring that bursts out when picked. */
    public static void item(class_332 c, class_1799 st, int x, int y, boolean hover, boolean sel, float appear, int rgb) {
        if (appear <= 0.02f) return;
        float t = t();
        float[] as = itemState(x, y, hover, sel);
        float hv = as[0], sl = as[1];
        float s = easeOutBack(appear);
        float bob = sin(t * 3f) * 1.4f * sl;
        s *= 1f + (0.20f + 0.03f * sin(t * 9f)) * smooth(hv) * (1f - sl) + (0.15f + 0.05f * sin(t * 4f)) * smooth(sl);
        float ga = Math.max(hv * 0.7f, sl);
        if (ga > 0.05f) softGlow(c, x + 8, y + 8, sl > 0.5f ? 14 : 11, rgb, ga);
        if (sl > 0.05f) {
            ring(c, x - 1, y - 1, 18, 18, argb((int) ((110 + 110 * (0.5f + 0.5f * sin(t * 5f))) * sl), rgb));
            for (int i = 0; i < 3; i++) {
                for (int k = 0; k < 4; k++) {
                    float a = t * 2.4f + i * 2.094f - k * 0.18f;
                    int sx = x + 8 + (int) (Math.cos(a) * 11), sy = y + 8 + (int) (Math.sin(a) * 11);
                    int fa = (int) (230 * (1 - k / 4f) * sl);
                    c.method_25294(sx, sy, sx + 2, sy + 2, argb(fa, k == 0 && i == 0 ? WHITE : rgb));
                }
            }
            if (sel && sl < 0.9f) circle(c, x + 8, y + 8, 6 + (int) (10 * sl), argb((int) (170 * (1f - sl)), WHITE));   // pick burst
        } else if (hv > 0.05f) {
            sparkle(c, x + 14, y + 2, 3, WHITE, (0.5f + 0.5f * sin(t * 8f)) * hv);
        }
        itemScaled(c, st, x + 8, y + 8 + bob, s);
    }

    /** Big showcase item: round halo, floor shadow, orbiting sparks with tails, twinkling stars. */
    private static Object lastShow;
    private static float showT = -1000f;

    public static void showcase(class_332 c, class_1799 st, int cx, int cy, float scale, int rgb) {
        float t = t();
        Object it = st.method_7909();
        if (it != lastShow) { lastShow = it; showT = t; }
        float sp = clamp01(since(showT) / 0.45f);
        if (sp < 1f) {
            circle(c, cx, cy, 6 + (int) (ease(sp) * 26 * scale), argb((int) (200 * (1 - sp) * (1 - sp)), rgb));
            circle(c, cx, cy, 3 + (int) (ease(sp) * 16 * scale), argb((int) (140 * (1 - sp)), WHITE));
            scale *= easeOutBack(Math.min(1f, sp * 1.6f));
        }
        int r = (int) (8 * scale);
        softGlow(c, cx, cy, r + 12 + (int) (sin(t * 2f) * 2f), rgb, 1.3f);
        // floor shadow that shrinks when the item floats up
        float bob = sin(t * 3f) * 1.5f;
        int sw = (int) (r * (0.9f - 0.08f * bob));
        c.method_25294(cx - sw, cy + r + 4, cx + sw, cy + r + 5, argb(70, 0x000000));
        c.method_25294(cx - sw + 2, cy + r + 5, cx + sw - 2, cy + r + 6, argb(40, 0x000000));
        for (int i = 0; i < 5; i++) {
            for (int k = 0; k < 5; k++) {
                float a = t * 1.8f + i * 1.2566f - k * 0.16f;
                int sx = cx + (int) (Math.cos(a) * (r + 6)), sy = cy + (int) (Math.sin(a) * (r + 6));
                int fa = (int) (220 * (1 - k / 5f));
                c.method_25294(sx, sy, sx + 2, sy + 2, argb(fa, i % 2 == 0 ? WHITE : rgb));
            }
        }
        for (int i = 0; i < 3; i++) {
            float ph = (t * 0.7f + i * 0.33f) % 1f;
            float a = i * 2.1f + t * 0.4f;
            sparkle(c, cx + (int) (Math.cos(a) * (r + 3)), cy + (int) (Math.sin(a) * (r + 3)) - (int) (ph * 4), 3, i == 1 ? WHITE : rgb, sin(ph * 3.1416f));
        }
        itemScaled(c, st, cx, cy + bob, scale);
    }

    /** Fire strip along the bottom edge of a panel: two layers plus rising embers. */
    public static void flames(class_332 c, int x, int y, int w, float intensity) {
        float t = t();
        for (int cx = 0; cx < w; cx += 3) {
            float n = 0.5f * sin(t * 8f + cx * 0.55f) + 0.5f * sin(t * 5.3f + cx * 0.29f);
            int hh = (int) (4 + 20 * intensity * (0.65f + 0.35f * n));
            c.method_25296(x + cx, y - hh, x + cx + 3, y, argb(0, ORANGE), argb((int) (150 + 80 * intensity), 0xFFD060));
            int h2 = (int) (hh * 0.55f);
            c.method_25296(x + cx, y - h2, x + cx + 3, y, argb(0, 0xFFE080), argb((int) (170 + 70 * intensity), 0xFFF2B0));
        }
        int embers = 6 + (int) (14 * intensity);
        for (int i = 0; i < embers; i++) {
            float life = (t * (0.6f + hash(i, 7)) + hash(i, 8)) % 1f;
            int ex = x + (int) (hash(i, 9) * w) + (int) (sin(t * 3f + i * 1.7f) * 3f);
            int ey = y - 4 - (int) (life * (28 + 22 * intensity));
            int a = (int) (230 * (1 - life));
            c.method_25294(ex, ey, ex + 1, ey + 1, argb(a, i % 3 == 0 ? 0xFFF2B0 : ORANGE));
        }
    }

    // ---------- particle burst (purchase / pick feedback) ----------
    private record Burst(float x, float y, int rgb, float start) {}
    private static final List<Burst> BURSTS = new ArrayList<>();

    public static void burst(int x, int y, int rgb) {
        BURSTS.add(new Burst(x, y, rgb, t()));
        if (BURSTS.size() > 6) BURSTS.remove(0);
    }

    public static void drawBursts(class_332 c) {
        BURSTS.removeIf(b -> since(b.start) > 0.8f);
        for (Burst b : BURSTS) {
            float age = since(b.start), k = age / 0.8f;
            for (int i = 0; i < 16; i++) {
                float ang = hash(i, 11) * 6.2832f;
                float sp = 18 + hash(i, 12) * 34;
                int px = (int) (b.x + Math.cos(ang) * sp * age);
                int py = (int) (b.y + Math.sin(ang) * sp * age + 26 * age * age);
                int a = (int) (255 * (1 - k) * (1 - k));
                if (i % 4 == 0) sparkle(c, px, py, 2, i % 8 == 0 ? WHITE : b.rgb, 1 - k);
                else c.method_25294(px, py, px + 2, py + 2, argb(a, i % 3 == 0 ? WHITE : b.rgb));
            }
        }
    }

    // ---------- counter + popups ----------
    public static final class Counter {
        private double v = -1;
        private long last = System.nanoTime();
        public long get(long target) {
            long now = System.nanoTime();
            double dt = Math.min(0.1, (now - last) / 1e9);
            last = now;
            if (v < 0) v = target;
            double d = target - v;
            double rate = Math.abs(d) > 5000 ? 0.28 : 0.18;
            v += d * (1 - Math.pow(1 - rate, dt * 60));
            if (Math.abs(target - v) < 1) v = target;
            return Math.round(v);
        }
    }

    private record Pop(long delta, float start) {}
    private static final List<Pop> POPS = new ArrayList<>();

    public static void pop(long delta) {
        if (delta != 0) POPS.add(new Pop(delta, t()));
        if (POPS.size() > 8) POPS.remove(0);
    }

    public static void drawPops(class_332 c, class_327 tr, int rightX, int y) {
        float now = t();
        POPS.removeIf(p -> now - p.start > 1.5f || now < p.start);
        for (Pop p : POPS) {
            float age = now - p.start;
            String s = (p.delta > 0 ? "+" : "-") + num(Math.abs(p.delta));
            int py = y + (int) (ease(age / 1.5f) * 22);
            float fade = clamp01(1 - age / 1.5f);
            if (fade < 0.25f) { c.method_51439(tr, class_2561.method_43470(s), rightX - tr.method_1727(s), py, argb((int) (fade * 4 * 255), p.delta > 0 ? GREEN : RED), true); continue; }
            popText(c, tr, s, rightX - tr.method_1727(s), py, age, 1.5f, p.delta > 0 ? GREEN : RED);
        }
    }

    /** Animated energy orb next to the balance: pulsing core, expanding rings, twinkle. */
    public static void orb(class_332 c, int x, int y, int rgb) {
        float t = t();
        int s = 4 + (int) (1.2f * sin(t * 4f));
        softGlow(c, x, y, s + 6, rgb, 1.1f);
        for (int k = 0; k < 2; k++) {
            float ph = (t * 0.9f + k * 0.5f) % 1f;
            circle(c, x, y, s + 1 + (int) (ph * 7), argb((int) (150 * (1 - ph)), rgb));
        }
        disc(c, x, y, s, argb(255, mix(rgb, WHITE, 0.25f)));
        disc(c, x, y, Math.max(1, s - 2), argb(255, mix(rgb, WHITE, 0.6f)));
        c.method_25294(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
        sparkle(c, x + s, y - s, 2, WHITE, 0.4f + 0.6f * Math.max(0f, sin(t * 3f)));
    }
}

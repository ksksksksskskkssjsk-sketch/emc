package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/** Mine Worlds: three huge mining dimensions full of ores, trips cost Fees.MINE_COST (1M / 5M / 10M). Coming back is free. */
public class MinesScreen extends ServiceScreen {
    private static final String[] NAMES = {"Mine World", "Nether Mine", "End Mine"};
    private static final String[] SUBS = {"Huge caves, water, every ore", "More diamond, emerald + debris", "Richest ores of all"};
    private static final String[] TIPS = {
            "Underground world: solid rock full of huge caves, underground lakes and every ore, plus rare gold, diamond and emerald blocks.",
            "Nether world: huge lava caves, quartz, gold, lots of ancient debris, extra diamond and emerald, rare ore blocks.",
            "Underground End: solid end stone full of huge caves, the most diamond, emerald and debris, rare netherite blocks."};
    private static final int[] COLORS = {Fx.GREEN, Fx.ORANGE, Fx.PURPLE};
    private static final String[] ICONS = {"minecraft:diamond_pickaxe", "minecraft:netherite_pickaxe", "minecraft:end_stone"};

    private final Runnable back;
    private final GlowButton[] go = new GlowButton[3];
    private long lastBal = Long.MIN_VALUE;

    public MinesScreen(Runnable back) {
        super("MINE WORLDS");
        this.back = back;
        W = 304;
        H = 176;
        accent = Fx.GREEN;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        for (int i = 0; i < 3; i++) {
            final int k = i;
            go[i] = GlowButton.of("", left + 10, top + 34 + i * 34, 284, 30, b -> ClientPlayNetworking.send(new ActionPayload(60, "", k)));
            go[i].method_47400(class_7919.method_47407(class_2561.method_43470(TIPS[i])));
            method_37063(go[i]);
        }
        GlowButton ret = GlowButton.of("Return from the mines (free)", left + 10, top + 138, 284, 14, b -> ClientPlayNetworking.send(new ActionPayload(61, "", 0)));
        ret.accent = Fx.CYAN;
        method_37063(ret);
        GlowButton close = GlowButton.of("Back", left + 10, top + 156, 284, 14, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);
        refresh();
    }

    private void refresh() {
        lastBal = ClientEmc.balance;
        for (int i = 0; i < 3; i++) {
            boolean ok = ClientEmc.balance >= Fees.MINE_COST[i];
            go[i].field_22763 = ok;
            go[i].accent = ok ? COLORS[i] : Fx.RED;
        }
    }

    @Override
    public void method_25393() {
        if (ClientEmc.balance != lastBal) refresh();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        txt(ctx, "Deeper worlds cost more but hold richer ores to sell", left + 10, top + 24, 0xFF7A8A99);
        for (int i = 0; i < 3; i++) {
            boolean ok = ClientEmc.balance >= Fees.MINE_COST[i];
            int y = top + 34 + i * 34;
            Icons.draw(ctx, ICONS[i], left + 24, y + 15, 1.0f);
            String t = NAMES[i];
            ctx.method_51439(field_22793, class_2561.method_43470(t), left + 44, y + 6, WHITE, true);
            ctx.method_51439(field_22793, class_2561.method_43470(SUBS[i]), left + 44, y + 17, GREY, false);
            String price = Fx.num(Fees.MINE_COST[i]) + " EMC";
            ctx.method_51439(field_22793, class_2561.method_43470(price), left + 284 + 10 - 6 - field_22793.method_1727(price), y + 11, ok ? 0xFFE0B040 : 0xFFFF7070, true);
        }
    }
}

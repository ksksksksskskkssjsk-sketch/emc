package com.uemc.client;

import com.uemc.net.StatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

public class UniversalEmcClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.BalancePayload.ID, (payload, ctx) -> { ClientEmc.balance = payload.emc(); ClientEmc.autoFix = payload.autoFix(); });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.ValuesPayload.ID, (payload, ctx) -> {
            java.util.Map<net.minecraft.class_2960, Long> m = new java.util.HashMap<>();
            for (int i = 0; i < payload.ids().size(); i++) {
                var id = net.minecraft.class_2960.method_12829(payload.ids().get(i));
                if (id != null) m.put(id, payload.values().get(i));
            }
            ClientEmc.set(m);
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.TeleportListPayload.ID, (payload, ctx) -> {
            java.util.List<ClientTp.Loc> all = new java.util.ArrayList<>();
            for (int i = 0; i < payload.names().size(); i++)
                all.add(new ClientTp.Loc(payload.names().get(i), payload.dims().get(i),
                        payload.coords().get(i * 3), payload.coords().get(i * 3 + 1), payload.coords().get(i * 3 + 2)));
            ClientTp.home = payload.hasHome() && !all.isEmpty() ? all.remove(0) : null;
            ClientTp.checkpoints = all;
            if (ctx.client().field_1755 instanceof TeleportScreen ts) ts.refresh();
        });
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> { ClientEmc.clear(); ClientUpgrades.clear(); ClientAutoSell.clear(); TimeScreen.speed = 0; });
        net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register((stack, ctx, type, lines) -> {
            long one = ClientEmc.unit(stack);
            net.minecraft.class_5250 t;
            if (one <= 0) {
                t = net.minecraft.class_2561.method_43470("EMC: none").method_27692(net.minecraft.class_124.field_1063);
            } else {
                t = net.minecraft.class_2561.method_43470("Sells: ").method_27692(net.minecraft.class_124.field_1065)
                        .method_10852(net.minecraft.class_2561.method_43470(String.format("%,d", one)).method_27692(net.minecraft.class_124.field_1054));
                if (stack.method_7947() > 1)
                    t.method_10852(net.minecraft.class_2561.method_43470("  (stack " + String.format("%,d", one * stack.method_7947()) + ")").method_27692(net.minecraft.class_124.field_1080));
            }
            long buy = ClientEmc.buyPrice(stack);
            if (buy > 0) t.method_10852(net.minecraft.class_2561.method_43470("   Buy: " + String.format("%,d", buy)).method_27692(net.minecraft.class_124.field_1060));
            lines.add(Math.min(1, lines.size()), t);
        });
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, ctx) -> {
            class_310 mc = ctx.client();
            if (mc.field_1755 instanceof ServiceScreen) { ClientEmc.balance = payload.emc(); return; }
            if (mc.field_1755 instanceof TabletScreen ts) ts.update(payload);
            else mc.method_1507(new TabletScreen(payload));
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.UpgradesPayload.ID, (payload, ctx) -> {
            ClientUpgrades.set(payload.levels(), payload.on(), payload.active());
            if (ctx.client().field_1755 instanceof UpgradesScreen us) us.refresh();
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.TimeStatePayload.ID, (payload, ctx) -> {
            TimeScreen.speed = payload.speed();
            if (ctx.client().field_1755 instanceof TimeScreen ts) ts.refresh();
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.AutoSellPayload.ID, (payload, ctx) -> {
            ClientAutoSell.set(payload.on(), payload.ids());
            if (ctx.client().field_1755 instanceof AutoSellScreen s) s.refresh();
        });
    }
}

package com.uemc.emc;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1320;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/**
 * Account-bound upgrades bought with EMC. They apply to whatever tool you hold (no item data needed).
 * Tools: Hammer (3x3 / 5x5 / 9x9), Auto-Repair.  Sneak = mine a single block.
 * Perks: potion-style effects you can switch on and off, plus Magnet (pulls items), Reach (longer block/entity range) and Flight (survival flying).
 * Shared by server (logic, price) and client (display).
 */
public final class Upgrades {
    private Upgrades() {}

    public record Def(String id, String name, String desc, String icon, boolean perk, long[] cost) {}

    public static final Def[] DEFS = {
            new Def("area", "Hammer", "Mine 3x3, then 5x5, then 9x9. Sneak = 1 block", "minecraft:diamond_pickaxe", false, new long[]{45000, 180000, 600000}),
            new Def("repair", "Auto-Repair", "Held tool heals itself", "minecraft:anvil", false, new long[]{15000, 45000, 120000}),
            new Def("haste", "Haste", "Mine and swing faster", "minecraft:golden_pickaxe", true, new long[]{18000, 60000, 180000}),
            new Def("speed", "Speed", "Run faster", "minecraft:sugar", true, new long[]{15000, 45000, 135000}),
            new Def("jump", "Jump Boost", "Jump higher", "minecraft:rabbit_foot", true, new long[]{12000, 36000, 108000}),
            new Def("night", "Night Vision", "See in the dark", "minecraft:golden_carrot", true, new long[]{9000}),
            new Def("water", "Water Breathing", "Never drown", "minecraft:heart_of_the_sea", true, new long[]{9000}),
            new Def("fire", "Fire Resistance", "Immune to fire and lava", "minecraft:magma_cream", true, new long[]{12000}),
            new Def("regen", "Regeneration", "Heal over time", "minecraft:ghast_tear", true, new long[]{30000, 120000}),
            new Def("resist", "Resistance", "Take less damage", "minecraft:iron_chestplate", true, new long[]{45000, 180000}),
            new Def("food", "No Hunger", "Food bar stays full", "minecraft:cooked_beef", true, new long[]{36000}),
            // ---- round 8 (append only: the order is the network order) ----
            new Def("magnet", "Magnet", "Pulls nearby items to you. Sneak = pause", "minecraft:lodestone", true, new long[]{18000, 60000, 180000}),
            new Def("strength", "Strength", "Hit harder", "minecraft:blaze_powder", true, new long[]{24000, 90000}),
            new Def("feather", "Slow Fall", "Float down, no fall damage", "minecraft:feather", true, new long[]{12000}),
            new Def("dolphin", "Dolphin's Grace", "Swim much faster", "minecraft:nautilus_shell", true, new long[]{9000}),
            new Def("luck", "Luck", "Better loot and fishing", "minecraft:emerald", true, new long[]{30000, 90000, 240000}),
            new Def("hearts", "Health Boost", "Extra hearts (2 per level)", "minecraft:golden_apple", true, new long[]{30000, 90000, 240000}),
            new Def("fly", "Flight", "Fly in survival. Off = slow fall", "minecraft:elytra", true, new long[]{450000}),
            // ---- round 9 ----
            new Def("reach", "Reach", "Mine, build and hit from farther away", "minecraft:fishing_rod", true, new long[]{24000, 75000, 210000}),
            // ---- round 10: auto-pickup family ----
            new Def("pickup", "Auto-Pickup", "Block and mob drops go straight into your inventory", "minecraft:hopper", true, new long[]{15000}),
            new Def("step", "Step Assist", "Walk up blocks without jumping", "minecraft:leather_boots", true, new long[]{9000, 27000}),
    };

    public static final int[] MAGNET_RADIUS = {4, 8, 16};
    public static final double STEP_BASE = 0.6;
    public static final double[] STEP_HEIGHT = {1.1, 2.1};
    public static final int[] REPAIR_TICKS = {100, 40, 10};   // ticks per durability point
    public static final int AREA_RADIUS_1 = 1, AREA_RADIUS_2 = 2, AREA_RADIUS_3 = 4;

    public static int indexOf(String id) {
        for (int i = 0; i < DEFS.length; i++) if (DEFS[i].id().equals(id)) return i;
        return -1;
    }

    private static int lvl(EmcData.Player d, String id) { return d.upgrades.getOrDefault(id, 0); }

    /** Level that really runs: 0 if not owned or switched off, else the level you chose (never above what you own). */
    public static int eff(EmcData.Player d, String id) {
        int own = lvl(d, id);
        if (own <= 0 || d.off.contains(id)) return 0;
        int a = d.active.getOrDefault(id, 0);
        return a > 0 ? Math.min(a, own) : own;
    }

    // ---------------- buying ----------------
    public static void buy(class_3222 p, String id) {
        int i = indexOf(id);
        if (i < 0) return;
        Def u = DEFS[i];
        EmcData.Player d = EmcData.get(p.method_5667());
        int lv = lvl(d, id);
        if (lv >= u.cost().length) { msg(p, u.name() + " is max level"); return; }
        long fee = u.cost()[lv];
        if (!EmcData.add(p.method_5667(), -fee)) { msg(p, "Not enough EMC (need " + fee + ")"); return; }
        d.upgrades.put(id, lv + 1);
        d.off.remove(id);
        d.active.remove(id);
        msg(p, u.name() + " level " + (lv + 1) + " unlocked");
        if (id.equals("fly")) flight(p, d);
        if (id.equals("reach")) reach(p, d);
    }

    public static void toggle(class_3222 p, String id) {
        int i = indexOf(id);
        if (i < 0) return;
        EmcData.Player d = EmcData.get(p.method_5667());
        if (lvl(d, id) <= 0) return;
        if (!d.off.add(id)) d.off.remove(id);
        msg(p, DEFS[i].name() + (d.off.contains(id) ? " off" : " on"));
        if (id.equals("fly")) flight(p, d);
        if (id.equals("reach")) reach(p, d);
    }

    /** Choose which owned level runs (1..owned). Lower = weaker, higher = stronger. Costs nothing. */
    public static void setLevel(class_3222 p, String id, int level) {
        int i = indexOf(id);
        if (i < 0) return;
        EmcData.Player d = EmcData.get(p.method_5667());
        int own = lvl(d, id);
        if (own <= 0) return;
        level = Math.max(1, Math.min(own, level));
        if (level >= own) d.active.remove(id); else d.active.put(id, level);
        d.off.remove(id);
        msg(p, DEFS[i].name() + " running at level " + level + "/" + own);
        if (id.equals("fly")) flight(p, d);
        if (id.equals("reach")) reach(p, d);
    }

    /** mode 0 = switch everything off, 1 = everything on, 2 = everything on at its highest level. */
    public static void setAll(class_3222 p, int mode) {
        EmcData.Player d = EmcData.get(p.method_5667());
        if (mode == 0) { for (Def u : DEFS) if (lvl(d, u.id()) > 0) d.off.add(u.id()); }
        else { d.off.clear(); if (mode == 2) d.active.clear(); }
        msg(p, mode == 0 ? "All upgrades off" : mode == 1 ? "All upgrades on" : "All upgrades on, max level");
        flight(p, d);
        reach(p, d);
    }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    // ---------------- events ----------------
    private static boolean busy = false;
    private static int counter = 0;

    public static void init() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy) return;
            if (!(player instanceof class_3222 sp) || !(world instanceof class_3218 sw)) return;
            busy = true;
            try { onBreak(sp, sw, pos, state); }
            catch (RuntimeException ex) { com.uemc.UniversalEmc.LOG.warn("Upgrade break failed", ex); }
            finally { busy = false; }
        });
        ServerTickEvents.END_SERVER_TICK.register(Upgrades::tick);

        // Auto-Pickup: remember where drops appeared, collect them at the end of the tick (drops exist by then)
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (player instanceof class_3222 sp && world instanceof class_3218 sw)
                queuePickup(sp, sw, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 1.5);
        });
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.method_5529() instanceof class_3222 sp)
                queuePickup(sp, sp.method_51469(), entity.method_23317(), entity.method_23318(), entity.method_23321(), 2.5);
        });

        // Flight: survival players we granted flight to. Taken back on leave so a saved "may fly" never outlives the perk.
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 p = handler.field_14140;
            EmcData.Player pd = EmcData.get(p.method_5667());
            if (pd.upgrades.remove("silk") != null) {   // Silk Touch was removed: give the EMC back
                pd.off.remove("silk"); pd.active.remove("silk");
                EmcData.add(p.method_5667(), 20000);
            }
            Integer veinLv = pd.upgrades.remove("vein");   // Vein Miner was removed: refund what was paid
            if (veinLv != null) {
                pd.off.remove("vein"); pd.active.remove("vein");
                long[] paid = {30000, 90000, 270000};
                long back = 0;
                for (int i = 0; i < Math.min(veinLv, paid.length); i++) back += paid[i];
                if (back > 0) EmcData.add(p.method_5667(), back);
            }
            Integer lumLv = pd.upgrades.remove("lumber");   // Lumberjack (tree vein-mine) was removed: refund what was paid
            if (lumLv != null) {
                pd.off.remove("lumber"); pd.active.remove("lumber");
                long[] paidL = {24000, 75000, 180000};
                long backL = 0;
                for (int i = 0; i < Math.min(lumLv, paidL.length); i++) backL += paidL[i];
                if (backL > 0) EmcData.add(p.method_5667(), backL);
            }
            Integer sellLv = pd.upgrades.remove("sell");   // Auto-Sell moved into the Sell menu (free): refund what was paid
            if (sellLv != null) {
                pd.off.remove("sell"); pd.active.remove("sell");
                long[] paidS = {30000, 90000, 240000};
                long backS = 0;
                for (int i = 0; i < Math.min(sellLv, paidS.length); i++) backS += paidS[i];
                if (backS > 0) EmcData.add(p.method_5667(), backS);
            }
            reach(p, pd);
            setBase(p, "block_break_speed", 1.0);   // a crash while flying could leave the fly-mining boost saved
            AIR_FAST.remove(p.method_5667());
            if (lvl(EmcData.get(p.method_5667()), "fly") > 0 && p.field_13974.method_14267() && p.method_31549().field_7478)
                FLYING.add(p.method_5667());   // saved flight from a crash: manage it again (revoked next check if the perk is off)
        });
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 p = handler.field_14140;
            setBase(p, "block_interaction_range", BLOCK_REACH);   // never leave a raised range saved on the player
            setBase(p, "entity_interaction_range", ENTITY_REACH);
            setBase(p, "step_height", STEP_BASE);
            setBase(p, "block_break_speed", 1.0);
            AIR_FAST.remove(p.method_5667());
            REPAIR_DEBT.remove(p.method_5667());
            if (FLYING.remove(p.method_5667()) && p.field_13974.method_14267()) revokeFlight(p);
        });
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> { PICKUPS.clear(); FULL_NOTE.clear(); FLYING.clear(); EFFECTS.clear(); AIR_FAST.clear(); REPAIR_DEBT.clear(); });
    }

    // ---------------- reach ----------------
    public static final double BLOCK_REACH = 4.5, ENTITY_REACH = 3.0;   // vanilla defaults
    public static final double BLOCK_PER_LEVEL = 2.0, ENTITY_PER_LEVEL = 1.0;

    private static final Map<String, class_6880<class_1320>> ATTRS = new HashMap<>();

    private static class_6880<class_1320> attr(String id) {
        return ATTRS.computeIfAbsent(id, k -> class_7923.field_41190.method_10223(class_2960.method_60656(k)).orElse(null));
    }

    private static void setBase(class_3222 p, String id, double v) {
        class_6880<class_1320> h = attr(id);
        if (h == null) return;
        var inst = p.method_5996(h);
        if (inst != null && Math.abs(inst.method_6201() - v) > 1e-6) inst.method_6192(v);
    }

    /** Sets the player's interaction range to vanilla + the running Reach level (back to vanilla when off). */
    public static void reach(class_3222 p, EmcData.Player d) {
        int lv = eff(d, "reach");
        setBase(p, "block_interaction_range", BLOCK_REACH + BLOCK_PER_LEVEL * lv);
        setBase(p, "entity_interaction_range", ENTITY_REACH + ENTITY_PER_LEVEL * lv);
        int st = eff(d, "step");
        setBase(p, "step_height", st <= 0 ? STEP_BASE : STEP_HEIGHT[Math.min(st, STEP_HEIGHT.length) - 1]);
    }

    // ---------------- auto-pickup / auto-sell ----------------
    private record Pickup(UUID id, class_3218 w, double x, double y, double z, double r) {}
    private record PKey(UUID id, class_3218 w) {}
    private static final List<Pickup> PICKUPS = new ArrayList<>();

    private static void queuePickup(class_3222 sp, class_3218 w, double x, double y, double z, double r) {
        if (PICKUPS.size() > 4000) return;
        if (eff(EmcData.get(sp.method_5667()), "pickup") <= 0) return;
        PICKUPS.add(new Pickup(sp.method_5667(), w, x, y, z, r));
    }

    private static void runPickups(MinecraftServer s) {
        if (PICKUPS.isEmpty()) return;
        List<Pickup> todo = new ArrayList<>(PICKUPS);
        PICKUPS.clear();
        Set<UUID> full = new HashSet<>();
        // One entity search per player and world per tick (a 9x9 hammer swing queues up to 80 spots: that was 80 searches)
        Map<PKey, double[]> merged = new LinkedHashMap<>();
        for (Pickup pk : todo) {
            PKey key = new PKey(pk.id(), pk.w());
            double[] b = merged.get(key);
            if (b == null) {
                merged.put(key, new double[]{pk.x() - pk.r(), pk.y() - pk.r(), pk.z() - pk.r(), pk.x() + pk.r(), pk.y() + pk.r(), pk.z() + pk.r()});
            } else {
                b[0] = Math.min(b[0], pk.x() - pk.r()); b[1] = Math.min(b[1], pk.y() - pk.r()); b[2] = Math.min(b[2], pk.z() - pk.r());
                b[3] = Math.max(b[3], pk.x() + pk.r()); b[4] = Math.max(b[4], pk.y() + pk.r()); b[5] = Math.max(b[5], pk.z() + pk.r());
            }
        }
        for (Map.Entry<PKey, double[]> me : merged.entrySet()) {
            UUID pid = me.getKey().id();
            class_3222 sp = s.method_3760().method_14602(pid);
            if (sp == null || !sp.method_5805()) continue;
            if (eff(EmcData.get(pid), "pickup") <= 0) continue;
            double[] b = me.getValue();
            class_238 box = new class_238(b[0], b[1], b[2], b[3], b[4], b[5]);
            for (class_1542 it : me.getKey().w().method_8390(class_1542.class, box, e -> e.method_5805() && !e.method_6983().method_7960())) {
                class_1799 st = it.method_6983();
                if (!st.method_7960()) sp.method_31548().method_7394(st);
                if (st.method_7960()) it.method_31472(); else full.add(pid);
            }
        }
        for (UUID id : full) {   // inventory full: tell them, at most every 4 seconds
            long now = counter;
            Long last = FULL_NOTE.get(id);
            if (last != null && now - last < 80) continue;
            FULL_NOTE.put(id, now);
            class_3222 sp = s.method_3760().method_14602(id);
            if (sp != null) msg(sp, "Inventory full - items left on the ground");
        }
    }
    private static final Map<UUID, Long> FULL_NOTE = new HashMap<>();

    // ---------------- mining ----------------
    private static String itemPath(class_1799 st) {
        return class_7923.field_41178.method_10221(st.method_7909()).method_12832();
    }

    private static String blockPath(class_2680 s) {
        return class_7923.field_41175.method_10221(s.method_26204()).method_12832();
    }

    private static boolean toolLow(class_1799 t) {
        return t.method_7960() || (t.method_7963() && t.method_7936() - t.method_7919() <= 2);
    }

    private static void onBreak(class_3222 sp, class_3218 w, class_2338 pos, class_2680 state) {
        EmcData.Player d = EmcData.get(sp.method_5667());
        if (d.upgrades.isEmpty()) return;
        class_1799 tool = sp.method_6047();
        if (tool.method_7960()) return;
        String it = itemPath(tool);
        boolean pick = it.endsWith("_pickaxe"), axe = it.endsWith("_axe"), shovel = it.endsWith("_shovel");
        if (!pick && !axe && !shovel) return;
        String bp = blockPath(state);
        if (!sp.method_5715()) {
            int area = eff(d, "area");
            if (area > 0) area(sp, w, pos, state, area >= 3 ? AREA_RADIUS_3 : area >= 2 ? AREA_RADIUS_2 : AREA_RADIUS_1);
        }
    }

    private static boolean breakAt(class_3222 sp, class_3218 w, class_2338 p, float maxHardness) {
        class_2680 s = w.method_8320(p);
        if (s.method_26215()) return false;
        float h = s.method_26214(w, p);
        if (h < 0 || h > 50 || h > maxHardness) return false;
        if (w.method_8321(p) != null) return false;
        return sp.field_13974.method_14266(p);
    }

    /** Breaks a flat (2r+1) x (2r+1) square around the block, facing the way you look. */
    private static void area(class_3222 sp, class_3218 w, class_2338 c, class_2680 origin, int r) {
        float oh = origin.method_26214(w, c);
        float maxH = Math.max(1.5f, oh + 2f);
        float pitch = sp.method_36455();
        double yaw = Math.toRadians(sp.method_36454());
        double lx = -Math.sin(yaw), lz = Math.cos(yaw);
        int mode = Math.abs(pitch) > 55 ? 0 : (Math.abs(lz) >= Math.abs(lx) ? 1 : 2); // 0 = XZ, 1 = XY, 2 = ZY
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                if (a == 0 && b == 0) continue;
                if (toolLow(sp.method_6047())) return;
                int dx = mode == 0 ? a : mode == 1 ? a : 0;
                int dy = mode == 0 ? 0 : b;
                int dz = mode == 0 ? b : mode == 1 ? 0 : a;
                breakAt(sp, w, new class_2338(c.method_10263() + dx, c.method_10264() + dy, c.method_10260() + dz), maxH);
            }
        }
    }

    // ---------------- ticking: auto-repair + perks ----------------
    /** Repairs owed while the player was mining (the held tool must not change mid-swing or the client restarts the block). */
    private static final Map<UUID, Integer> REPAIR_DEBT = new HashMap<>();
    /** Players currently holding the fly-mining speed boost. */
    private static final Set<UUID> AIR_FAST = new HashSet<>();

    private static java.lang.reflect.Field MINING_F;
    private static boolean miningTried = false;

    /** True while the server thinks this player is breaking a block (vanilla's own flag, read by reflection). */
    private static boolean isMining(class_3222 p) {
        if (!miningTried) {
            miningTried = true;
            try { MINING_F = class_3225.class.getDeclaredField("field_14003"); MINING_F.setAccessible(true); }
            catch (Throwable t) { com.uemc.UniversalEmc.LOG.warn("Mining flag not found, auto-repair may interrupt mining", t); }
        }
        if (MINING_F == null) return false;
        try { return MINING_F.getBoolean(p.field_13974); } catch (Throwable t) { return false; }
    }

    private static void tick(MinecraftServer s) {
        counter++;
        runPickups(s);

        for (class_3222 p : new ArrayList<>(s.method_3760().method_14571())) {
            UUID id = p.method_5667();
            EmcData.Player d = EmcData.get(id);
            if (d.upgrades.isEmpty()) continue;
            int rep = eff(d, "repair");
            if (rep > 0) {
                if (counter % REPAIR_TICKS[Math.min(rep, 3) - 1] == 0) {
                    heal(p.method_6079(), 1);
                    REPAIR_DEBT.merge(id, 1, (a, b) -> Math.min(a + b, 5000));
                }
                Integer debt = REPAIR_DEBT.get(id);
                if (debt != null && !isMining(p)) {   // never touch the held tool while mining: it cuts the mining off
                    heal(p.method_6047(), debt);
                    REPAIR_DEBT.remove(id);
                }
            } else REPAIR_DEBT.remove(id);
            if (d.upgrades.containsKey("autofix")) {
                autoGuard(p, id);   // every tick: nothing gets near breaking
                if (counter % 20 == 0) autoFix(p, id);
            }
            if (counter % 4 == 0) {
                int mg = eff(d, "magnet");
                if (mg > 0) magnet(p, mg);
            }
            flyMining(p, d);
            if (counter % 20 == 0) { perks(p, d); flight(p, d); reach(p, d); }
        }
    }

    /** Vanilla mines 5x slower off the ground. While flying, cancel that so mining in the air is as fast as on the ground. */
    private static void flyMining(class_3222 p, EmcData.Player d) {
        UUID id = p.method_5667();
        var ab = p.method_31549();
        boolean boost = eff(d, "fly") > 0 && FLYING.contains(id) && ab.field_7479 && !p.method_24828();
        if (boost) { if (AIR_FAST.add(id)) setBase(p, "block_break_speed", 5.0); }
        else if (AIR_FAST.remove(id)) setBase(p, "block_break_speed", 1.0);
    }

    /** Auto-Repair guard: no item can break. Any damageable item below the safety margin is topped back up, paid in EMC. */
    private static void autoGuard(class_3222 p, UUID id) {
        var inv = p.method_31548();
        boolean mining = isMining(p);
        class_1799 held = p.method_6047();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 st = inv.method_5438(i);
            if (st.method_7960() || !st.method_7963()) continue;
            int max = st.method_7936();
            int left = max - st.method_7919();
            int safe = Math.min(max, Fees.AUTOFIX_GUARD);
            if (left >= safe) continue;
            if (mining && st == held && left > 3) continue;   // do not cut the mining off unless it is about to break
            long can = EmcData.get(id).emc / Fees.REPAIR_PER_POINT;
            int pts = (int) Math.min(safe - left, can);
            if (pts <= 0) {
                if (counter % 100 == 0) p.method_7353(net.minecraft.class_2561.method_43470("Auto-Repair: not enough EMC, items can break!"), true);
                return;
            }
            if (!EmcData.add(id, -Fees.repairFee(pts))) return;
            st.method_7974(st.method_7919() - pts);
        }
    }

    /** Auto-Repair from the Repair screen: heals what you carry (inventory, armor, offhand), paying EMC per durability point. */
    private static void autoFix(class_3222 p, UUID id) {
        var inv = p.method_31548();
        boolean mining = isMining(p);
        class_1799 held = p.method_6047();
        int budget = Fees.AUTOFIX_POINTS;
        for (int i = 0; i < inv.method_5439() && budget > 0; i++) {
            class_1799 st = inv.method_5438(i);
            if (st.method_7960() || !st.method_7963() || st.method_7919() <= 0) continue;
            if (mining && st == held) continue;   // never touch the held tool while mining
            int pts = Math.min(budget, st.method_7919());
            if (!EmcData.add(id, -Fees.repairFee(pts))) {
                if (counter % 200 == 0) p.method_7353(net.minecraft.class_2561.method_43470("Auto-Repair paused: not enough EMC"), true);
                return;
            }
            st.method_7974(st.method_7919() - pts);
            budget -= pts;
        }
    }

    private static void heal(class_1799 st, int n) {
        if (n > 0 && !st.method_7960() && st.method_7963() && st.method_7919() > 0) st.method_7974(Math.max(0, st.method_7919() - n));
    }

    private static void give(class_3222 p, class_6880<class_1291> e, int amp) {
        if (e == null) return;
        class_1293 cur = p.method_6112(e);
        if (cur != null && cur.method_5578() >= amp && cur.method_5584() > 210) return;   // still plenty left: do not re-send it every second
        p.method_6092(new class_1293(e, 260, amp, true, false));
    }

    // ---------------- round 8: effects by id, magnet, flight ----------------
    /** Vanilla effects looked up by registry id ("strength", "luck"...), cached. null if the id does not exist. */
    private static final Map<String, class_6880<class_1291>> EFFECTS = new HashMap<>();

    private static class_6880<class_1291> effect(String id) {
        return EFFECTS.computeIfAbsent(id, k -> class_7923.field_41174.method_10223(class_2960.method_60656(k)).orElse(null));
    }

    /** Pulls dropped items within the radius onto you (skips items still on pickup delay, and everything while you sneak). */
    private static void magnet(class_3222 p, int lv) {
        if (p.method_5715() || p.method_7325() || !p.method_5805()) return;
        int r = MAGNET_RADIUS[Math.min(lv, MAGNET_RADIUS.length) - 1];
        double px = p.method_23317(), py = p.method_23318(), pz = p.method_23321();
        class_238 box = new class_238(px - r, py - r, pz - r, px + r, py + r, pz + r);
        for (class_1542 it : p.method_51469().method_8390(class_1542.class, box,
                e -> e.method_5805() && !e.method_6977() && !e.method_6983().method_7960())) {
            if (it.method_5649(px, py, pz) <= 2.25) continue;   // already on you (full inventory: do not keep moving it)
            it.method_5814(px, py, pz);
        }
    }

    /** Players we switched "may fly" on for (survival / adventure only: creative and spectator keep their own). */
    private static final Set<UUID> FLYING = new HashSet<>();

    private static void revokeFlight(class_3222 p) {
        var ab = p.method_31549();
        ab.field_7478 = false;
        ab.field_7479 = false;
        p.method_7355();
    }

    /** Grants or takes back survival flight to match the perk (level > 0 and switched on). */
    private static void flight(class_3222 p, EmcData.Player d) {
        UUID id = p.method_5667();
        boolean want = eff(d, "fly") > 0 && p.field_13974.method_14267();
        var ab = p.method_31549();
        if (want) {
            if (!ab.field_7478) { ab.field_7478 = true; p.method_7355(); FLYING.add(id); }
        } else if (FLYING.remove(id) && p.field_13974.method_14267()) {
            revokeFlight(p);
            give(p, effect("slow_falling"), 0);   // switched off mid-air: float down instead of dropping
        }
    }

    private static void perks(class_3222 p, EmcData.Player d) {
        for (Def u : DEFS) {
            if (!u.perk()) continue;
            int lv = eff(d, u.id());
            if (lv <= 0) continue;
            int amp = lv - 1;
            switch (u.id()) {
                case "haste" -> give(p, class_1294.field_5917, amp);
                case "speed" -> give(p, class_1294.field_5904, amp);
                case "jump" -> give(p, class_1294.field_5913, amp);
                case "night" -> give(p, class_1294.field_5925, 0);
                case "water" -> give(p, class_1294.field_5923, 0);
                case "fire" -> give(p, class_1294.field_5918, 0);
                case "regen" -> give(p, class_1294.field_5924, amp);
                case "resist" -> give(p, class_1294.field_5907, amp);
                case "food" -> give(p, class_1294.field_5922, 0);
                case "strength" -> give(p, effect("strength"), amp);
                case "feather" -> give(p, effect("slow_falling"), 0);
                case "dolphin" -> give(p, effect("dolphins_grace"), 0);
                case "luck" -> give(p, effect("luck"), amp);
                case "hearts" -> give(p, effect("health_boost"), amp);
                default -> {}   // magnet + fly are handled in tick() / flight()
            }
        }
    }
}

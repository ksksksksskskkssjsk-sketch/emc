# Kavlod Mod – workstation UI (source files)

Drop the `com/` folder over your mod's source tree (same package layout as your sources jar).
UNTESTED: written without Minecraft/Gradle available, using only intermediary names already present in your sources.
Expect to build once and fix any name that doesn't resolve.

## New files
- net/WorkbenchPayload.java      server -> client: which screen to open + recipe data
- emc/Workbench.java             server logic: recipe loading, craft, stonecutter, grindstone (all validated server-side)
- client/WorkbenchScreen.java    crafting table + stonecutter (search, "can craft" filter, recipe variants, Craft 1/10/max)
- client/DisenchantScreen.java   grindstone (strip enchants, curses stay, small XP)

- client/SellScreen.java         sell from inventory: inventory-shaped grid, multi-select, All/Half/One, live total, Select main/all/same item

## Changed files (small patches to your originals)
- UniversalEmc.java              calls Workbench.init()
- net/ServerNet.java             registers payload; actions 40 (craft) and 41 (disenchant); converter buttons open new screens
- emc/Services.java              tablet "open" for crafting / stonecutter / grindstone / enchant uses new screens
- emc/EmcLogic.java              + addXp(), + sellSlots() (action 42)
- client/TabletScreen.java       "Mode" button is now "Sell items..." and opens SellScreen
- emc/Fees.java                  enchant-table open fee 500 -> 0 (each enchant is paid per use)
- client/UniversalEmcClient.java receiver for WorkbenchPayload
- client/EnchantScreen.java      rewritten: one row per enchant, click name = next level, click a level chip (I-VII) = that level, price on the big button, conflicts greyed out
- client/ConverterMenuScreen.java regrouped layout (Workstations / EMC + XP)
- client/ServicesScreen.java     two-line cards (name + price), grouped Workstations / Services
- client/ServiceScreen.java      panel width W is now adjustable per screen

## Behaviour changes
- Crafting/stonecutter craft from your inventory (no EMC). Tablet still charges its open fee for them (10 EMC each).
- Converter "Enchanting" now opens the pick-your-enchant screen (costs EMC). Set
  Workbench.CONVERTER_CUSTOM_ENCHANT = false to get the vanilla random table back.
- Anvil and smithing are unchanged (vanilla screens).

## Round 2: icons + better selling
- client/Icons.java (new): draws vanilla item pictures as icons (cached by item id).
- client/SellScreen.java: item picture card for the hovered/last-clicked stack (name, EMC each, sells for),
  icons on every button, "cart" row of icons showing what will be sold, live total on the Sell button,
  "Balance after", "Inventory worth", and a Quick sell toggle (click a stack = sold instantly; enchanted stacks skipped).
- client/ServicesScreen.java: item icon on every upgrade card.
- client/ConverterMenuScreen.java: item icon on every button; panel widened to 284.

## Round 3: XP shop + easier selling
- client/XpShopScreen.java (new): Buy/Sell toggle, amount presets 1/5/10/30/Max, -5/-1/+1/+5, live "Level a -> b" and EMC cost/gain, one confirm button.
- Tablet and Converter: the 3 loose XP buttons are now one "XP Shop" button.
- Converter: new "Sell everything" one-click button (next to XP Shop).

## Round 4: enchant levels + upgrade system
- Enchant: every enchant can go to level 10 (single-level ones stay 1). Level chips are now 1-10. Price = 1000*L^2 + 2000 (pay the difference).
- emc/Upgrades.java (new): account-bound upgrades bought with EMC, saved in uemc_players.json.
  Tools (need pickaxe/axe/shovel in hand): Hammer 3x3 -> 5x5, Lumberjack (32/96/200), Auto-Repair.
  Walk = hammer. Sneak = tree mode.
  Perks (ON/OFF): Haste, Speed, Jump Boost, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger.
- client/UpgradesScreen.java (new): list with level, price, Unlock/Upgrade, ON/OFF. Opened from Tablet > Upgrades and Converter.
- net/UpgradesPayload.java (new), ServerNet actions 50 (buy), 51 (toggle), 52 (sync).
- Names NOT checked against mappings (fix first if the build complains): field_13974, method_14266, method_26214, method_26215,
  method_8321, method_36454, method_36455, method_5715, method_6092, class_1293 ctor, class_1294.field_*, class_1291, method_12832.

## Round 5: EMC HUD
- client/EmcHud.java (new): always-on balance box in the world (animated number, +/- popups, EMC value of the item in hand).
  Hidden with F1 and while a UEMC screen is open. Default: top-left.
  Client commands: /emchud (toggle), /emchud on|off, /emchud topleft|topright|bottomleft|bottomright.
  Saved in config/uemc_hud.properties.
- emc/HudSync.java (new): server sends your balance every 5 ticks when it changed (and once after joining).
- net/BalancePayload.java (new): the packet for that.
- UniversalEmc.java calls HudSync.init(); client/UniversalEmcClient.java calls EmcHud.init(), receives BalancePayload, resets on disconnect.
- Uses Fabric API HudElementRegistry (needs Fabric API 0.116+; build uses 0.141.x).
- UNTESTED like the rest: all Minecraft names were checked against the real 1.21.11 mappings, but nothing was compiled.

## Round 6: workstations removed, new Enchanting Table
REMOVED: crafting table, stonecutter, grindstone, anvil, smithing table and ender chest screens (tablet + converter), their
server logic, packets and EMC open fees.
- Deleted: emc/Workbench.java, net/WorkbenchPayload.java, client/WorkbenchScreen.java, client/DisenchantScreen.java, menu/Handlers.java
- Cleaned: ServerNet (actions 20-26, 40, 41 and converter buttons gone), Services (open() gone), Fees (OPEN/OPEN_NAMES gone),
  UniversalEmc, UniversalEmcClient, ServicesScreen, ConverterMenuScreen, TabletScreen text.

NEW client/EnchantScreen.java (Enchanting Table), opened from Tablet > Upgrades > Enchanting and from the Converter menu:
- Search box + 8 big rows per page (name + level already on the item). Conflicts greyed out with the reason.
- Click an enchant -> level jumps to X (10). One click on a level chip 1-10 to pick another level.
- Price, "After" balance and the Enchant button are always visible. You only pay the difference to what the item has.
- Every enchant is capped at X (Fees.MAX_ENCHANT_LEVEL = 10); single-level enchants (Mending, Silk Touch...) stay at 1.
  Unbreaking X = 102,000 EMC (1000*L^2 + 2000).
- Server action 7 (Services.enchant) is unchanged and still validates item, level cap, conflicts and EMC.
- Same UNTESTED caveat: only intermediary names already used in your sources were used (class_342 search box copied from TabletScreen).

## Round 7: easier tablet, tablet can't be sold, buy anything with a price
- The EMC Tablet can never be sold or converted (EmcLogic.valueOf returns 0 for it, EmcRegistry removes its price,
  so "Sell all", "Sell offhand" and the sell screen all skip it; its tooltip says "EMC: none").
- Buying no longer needs scanner discovery: every item that has an EMC price is in the Buy list and can be bought
  (EmcLogic.buy lost the "Not discovered yet" check). Items with no price still can't be bought; set one in config/uemc_values.json.
  The list is built on the client from the price list already synced on join (ClientEmc.all()).
- client/TabletScreen.java rewritten as a simple hub:
  big top buttons Buy / Sell / XP Shop / Services; readable category tabs (All, Blocks, Gear, Food, Mats); search;
  click an item, then Buy 1 / 16 / 64 / Max (Max = everything you can afford, shown as "Max x37").
  Buttons you can't afford are greyed out and say what they cost. "Sell offhand item" stays at the bottom right.
- client/TeleportScreen.java: bigger page arrows and buttons; deleting a checkpoint now needs a second press ("Del" -> "Sure?").

## Round 8: 7 new perks (emc/Upgrades.java only)
Appended to Upgrades.DEFS (same ON/OFF perk rows, new pages in Tablet > Upgrades and the Converter menu). Order = network order, so only ever append.
- Magnet (3 lv, 6k / 20k / 60k): pulls dropped items to you, radius 4 / 8 / 16. Skips items still on pickup delay. Sneak = paused.
- Strength (2 lv, 8k / 30k): Strength I / II.
- Slow Fall (4k): Slow Falling (no fall damage).
- Dolphin's Grace (3k).
- Luck (3 lv, 10k / 30k / 80k): Luck I-III (loot, fishing).
- Health Boost (3 lv, 10k / 30k / 80k): +2 hearts per level.
- Flight (150k): survival/adventure flying. Creative/spectator untouched. Switching it OFF (or leaving) takes flight back and gives slow fall for a few seconds.
- New effects are looked up by registry id (strength, slow_falling, dolphins_grace, luck, health_boost), so no unverified field numbers.
- Names checked against Yarn 1.21.11: field_41174 (Registries.STATUS_EFFECT), method_10223 (Registry.getEntry(Identifier)), method_8390, method_6977, method_6983,
  method_5814, method_5649, method_5805, method_7325, method_51469, method_31549, method_7355, field_7478, field_7479, method_14267, class_1542, class_238.
- Still UNTESTED in-game (no Minecraft jar available to compile against). Existing saves are fine: new perks start at level 0.

## Ready-to-use pack (0.2.0)
- Version 0.2.0. Gradle wrapper added (gradlew, gradlew.bat, gradle/wrapper/*, Gradle 9.2.1).
- build.sh / build.bat: check JDK 21, build (retries with intermediary mappings), copy jar to dist/.
- github.sh: init + commit + push (creates the repo with `gh` if logged in). The existing .github/workflows/build.yml then builds and publishes a release.

## Round 9: Reach (emc/Upgrades.java)
- New perk "Reach" (3 lv, 8k / 25k / 70k): block range +2 per level, entity range +1 per level. Put back to vanilla when off or on leaving.

## Round 10: Time & Weather
- client/TimeScreen.java rewritten (Tablet > Services > Time): SKIP TO / SKIP FORWARD (as before), TIME SPEED, WEATHER. Buttons grey out outside the Overworld.
- TIME SPEED: x2 / x5 / x10 / x20 until you press 1x. The player who starts it pays every real second (Fees.SPEED_FEE = 3 / 10 / 25 / 60 EMC per second; first second up front).
  It stops when the payer runs out of EMC, leaves, or someone presses 1x. Anyone with access can take it over (they pay from then on).
  Each server tick adds (x - 1) ticks of day time in the Overworld (ServerWorld.setTimeOfDay, same call the skip uses).
- GROWTH: while a speed runs, the "random tick speed" game rule is raised to original * x (cap Fees.SPEED_MAX_RANDOM_TICK = 100) and put back on stop.
  Crops, saplings, bamboo, cane, trees, vines... all grow on random ticks, so they speed up with it. The original value is saved in
  <world>/uemc_randomtick.txt and restored on the next start if the server crashed mid-speed.
  The rule is looked up in the game rule registry by id ("random_tick_speed", then "randomTickSpeed"); if neither exists the time still speeds up, growth does not (warning in the log).
- WEATHER: Clear 300 / Rain 300 / Storm 600 EMC (Fees.WEATHER_FEE), Overworld only, lasts 20 / 10 / 10 minutes. 5 second cooldown.
- New: net/TimeStatePayload.java (server -> client, running speed). ServerNet actions 16 (set speed), 17 (set weather), 18 (ask speed).
- Names used were checked against Yarn 1.21.11 (GameRules getValue/setValue, Registries.GAME_RULE, ServerWorld.setWeather, World.isRaining/isThundering). Still not compiled.

## Round 11: UI refresh fix
- Screens (Tablet, Converter, every ServiceScreen) no longer pause the single-player server (Screen.shouldPause = false). A paused server does not sync the inventory,
  so sold items stayed in the Sell grid until you closed the UI. Side effects fixed too: furnace jobs, time speed / fast skip and the clock now run while a screen is open.
- ServerNet: after every action the server pushes inventory changes to the client right away (currentScreenHandler.sendContentUpdates).
- Trade-off: in single player the game keeps running behind the tablet, so mobs can still hit you.

## Round: no custom furnace + real time speed
- Removed the fuel-free Furnace service (screen, server logic, packets, prices). Services menu re-laid out.
- Time speed (x2/x5/x10/x20) now sets the real server tick rate (runs vanilla `tick rate`), so EVERYTHING speeds up:
  crops, trees, animals (baby growth + breeding cooldown), furnaces, brewing, eggs, effects, cooldowns, day/night.
  The old trick (extra clock ticks + random tick speed) is gone, so nothing is sped up twice.
- You are charged per real second (wall clock), not per tick, so the price is the same at any speed.
- Stops on: 1x button, out of EMC, payer leaves, server stops. Tick rate goes back to 20.
- Effects of a real tick rate: the player moves faster too (client follows the server), and if the PC cannot keep up the real speed is lower than x.
- UNTESTED: written without Minecraft/Gradle here. The command is run by reflection (found by signature), so it cannot break the build; if it cannot run, you get "Time speed failed (see the log)" and no EMC is taken.

## Round: Repair table (anvil style)
- NEW client/RepairScreen.java (Tablet > Services > Repair). Click any damaged item (inventory, armor, offhand) -> it goes in the left slot, the result slot shows it repaired + price. Click the result (or the big button) to take it.
- REPAIR ALL: fixes every damaged item at once (all or nothing). Items show a durability bar in the picker.
- Server: actions 19 (repair slot) and 20 (repair all) in ServerNet -> Services.repairSlot / repairAll. Old action 10 (repair held item) kept.
- Fees.repairFee(damage) shared by client and server. Still UNTESTED (not compiled here).

## Round: harder economy
All knobs are in emc/Fees.java (BUY_MULT, SELL_PERCENT) and emc/EmcLogic.java (XP_SELL, XP_BUY).
- Buy price = base x3 (Fees.BUY_MULT). Selling gives 40% of base (Fees.SELL_PERCENT, min 1 per item). Buy+sell loop now loses a lot.
- XP: sell 8 -> 3 EMC per point, buy 10 -> 30.
- Services x3: enchants, repair (2 -> 6 per point), teleport (cap 15000), checkpoint 300, time skip 450/h, time speed 9/30/75/180 per second, weather 900/900/1800.
- Tool & perk upgrades x3 (every price in Upgrades.DEFS).
- Tooltip shows "Sells: X  Buy: Y". HUD says "Sells:". Scanner prints sell + buy.
- Server (EmcLogic.valueOf / buy) and client (ClientEmc) both use Fees.sellUnit / buyUnit so displayed prices match what is charged.
- Existing balances are unchanged. Still UNTESTED (not compiled here).

## UI animation pass
- Fx: smooth precise clock (Fx.since), springy panel open, bursts on buy/sell, item-change shockwave, frame-rate independent counter.
- GlowButton: staggered pop-in, press squash + ripple + sparks, frame-rate independent hover.
- EMC HUD removed (EmcHud.java deleted, /emchud gone). Balance sync (HudSync / BalancePayload) kept: screens need it.

## Review pass (Kavlod Mod)
- Renamed to "Kavlod Mod" (display name, jar `kavlod-mod-<version>.jar`); new 256x256 icon. Internal mod id stays `uemc`.
- emc/EmcData.java: loading player data is now fault tolerant. A missing field or one bad entry no longer drops everyone after it,
  and if the file cannot be read (or an entry is skipped) a copy is kept as `uemc_players.json.broken-<time>` before the next autosave can overwrite it.
- emc/Fees.unsellable + EmcLogic.valueOf + ClientEmc.unit: shulker boxes and bundles can no longer be sold (selling destroyed everything inside,
  including via "Sell all" and the converter). They can still be bought. Flip Fees.unsellable to return false to restore the old behaviour.
- client/ClientEmc.clear(): leaving a world also resets the cached balance and teleport list (the old world's numbers could show in the next one).
- README: jar name/version and Fabric API version now match the build.
- Still never compiled against Minecraft: the first real build may flag an intermediary name. Fix that one line and rebuild.

## Round 10: auto-pickup family
- Upgrades.java: Auto-Pickup, Auto-Sell (protected items never sold, enchanted/damageable never sold), Step Assist.
- emc/Config.java (new): config/uemc.json. EmcData: per-player protect list. EmcCommands: /emc protect, /emc protect list.
- Names NOT checked against mappings: ServerLivingEntityEvents.AFTER_DEATH lambda, method_5529 (getAttacker), method_31472 (discard), method_7394 (insertStack), method_14602 (getPlayer), step_height attribute.

## Mines button on the tablet
- TabletScreen: new "Mines" button in the top bar (opens MinesScreen directly, Back returns to the tablet). Still also under Services > Mine Worlds.
- Mine Worlds: Mine World / Nether Mine / End Mine, Fees.MINE_ENTRY = 1,000,000 EMC per trip, return free. Untested (not compiled here).

## Mine prices + richer deep worlds
- Fees.MINE_COST: Mine World 1,000,000 / Nether Mine 5,000,000 / End Mine 10,000,000 EMC per trip (return free). Used by Services.mineEnter, MinesScreen, tablet tooltip.
- More valuable ores to sell as you go deeper: Nether diamond 14->24 (vein 6->8), emerald 14->24 (4->6), ancient debris 14->24 / small 30->45. End diamond 34->60 (8->10), emerald 34->60 (6->8), ancient debris 12->40 (3->5).
- Untested (not compiled here).

## Rare ore blocks
- Rare single/double blocks hidden in the rock of each mine (worldgen rareblock_* features, rarity_filter, size 2). Price comes from the recipe (9 x item).
  Mine World: gold, diamond, emerald blocks. Nether Mine: gold, diamond, emerald. End Mine: diamond, emerald, NETHERITE block (rarest).
- Auto-Sell protects them (diamond/emerald/netherite are protected words); sell by hand in the tablet. Chances are in placed_feature/rareblock_*.json (rarity_filter.chance, lower = more).
- Existing mine chunks already generated will not get them; only new chunks (or a fresh world) do. Untested (not compiled here).

## Prettier, varied mine worlds
- Each mine now mixes several biomes (multi_noise biome source in dimension/*.json), every one with the same rich ores:
  Mine World: meadow (trees + flowers), lush (azalea, vines, moss, flower forest), crystal (amethyst geodes, dripstone, glow lichen, purple sky/water), cherry (cherry trees, pink sky/water).
  Nether Mine: wastes, crimson (nylium veins + fungi + weeping vines), warped (nylium + twisting vines + sprouts), soul (soul sand + soul fire). Different fog colors.
  End Mine: default, chorus (chorus plants), bloom (blue fog).
- Crimson/warped use nylium veins (uemc:nylium_*) so the plants have ground to grow on.
- Only new chunks get this; delete/regenerate the mine dimension folders in the save (dimensions/uemc/mine_*) to see it everywhere.
- All vanilla feature ids used were written from memory (1.21.x): if the game logs an unknown feature, remove that line from the biome json. Untested (not compiled here).

## Huge caves everywhere
- New carvers (data/uemc/worldgen/configured_carver): cavern_a / cavern_b / cavern_giant (Mine World, bedrock up through the surface), nether_cavern / nether_cavern_giant (Nether Mine), end_cavern (hollows the End Mine islands, replaces end_stone only). Added to every biome of each world.
- Tune: probability (1.0 = every chunk), horizontal/vertical_radius_multiplier (bigger = wider halls). Very large values can show flat chunk-edge walls and slow generation.
- The Mine World still has a surface (carved open, not removed): removing it needs custom noise settings, not done. Untested (not compiled here).

## 9x9 Hammer
- Upgrades "Hammer" gets level 3: 9x9 flat square (radius 4), 600,000 EMC. Levels: 3x3 (45,000), 5x5 (180,000), 9x9 (600,000). Sneak = 1 block. Existing saves keep their level.
- Each break can take up to 80 extra blocks, same hardness limit as before. Untested (not compiled here).

## Full underground worlds (Mine World + End Mine)
- New custom terrain: data/uemc/worldgen/noise_settings/mine_overworld.json and mine_end.json (dimension/*.json now point to them).
  The whole world is a solid block of stone/deepslate (End: end stone) with huge caverns inside and a solid ceiling: no sky, no surface.
  Mine World: caves from y -40 to 240, water lakes in the deep ones (sea_level -20), bedrock floor, deepslate below y 0.
  End Mine: end stone block, caves from y 12 to 205, no water.
- Nether Mine keeps vanilla nether terrain (already enclosed) with the extra huge caverns.
- Tune in the noise settings: final_density -> the 0.15 number (higher = more rock, lower = more cave), gradients = floor/ceiling height.
- Teleport search (Services.safeSpot) now scans the new cave heights.
- Surface-only features (trees, flowers) no longer show; lush, dripstone, amethyst and ores still do.
- WRITTEN WITHOUT A GAME TO TEST. If the world fails to load a mine dimension, set "settings" in dimension/mine_overworld.json back to "minecraft:overworld" and mine_end.json to "minecraft:end".

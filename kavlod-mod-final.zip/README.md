# Kavlod Mod (Fabric, Minecraft 1.21.11)

## Build
Needs JDK 21 + internet (Gradle wrapper included).

    ./build.sh        (Windows: build.bat)

Jar: `dist/kavlod-mod-1.0.0.jar` (version comes from `mod_version` in gradle.properties)

## GitHub (builds the jar for you, no JDK needed)

    ./github.sh yourname/kavlod-mod            (private; add --public for public)

Then open the repo > Actions (build log) > Releases (download the jar).

## Install
Fabric Loader >= 0.18.0 + Fabric API 0.139.4+1.21.11 or newer in `mods/`, then drop the jar in.

## Items
- EMC Phone (the only item; recipe in-game: obsidian, diamonds, ender eye). The phone can't be sold. Keep it in your inventory and right-click to open it. Sell items to get EMC, buy any item that has an EMC price.
- Prices: buy = base x3, sell = 40% (knobs in Fees.java). Enchanting Table (Phone > Services > Enchanting): pick any enchant, level 1-10 (X), pay in EMC. No other workstations.
- Upgrades (Phone > Services > Upgrades): tools (Hammer, Lumberjack, Auto-Repair) and ON/OFF perks (Haste, Speed, Jump, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger, Magnet, Strength, Slow Fall, Dolphin's Grace, Luck, Health Boost, Flight, Reach, Auto-Pickup, Step Assist).
- Auto-Pickup: block drops (hammer/lumberjack too) and mob kill drops go straight into your inventory. Step Assist: walk up 1 block (Lv2: 2 blocks).
- Time & Weather (Phone > Services > Time): skip the clock, run time x2 / x3 / x5 (you pay per real second). It raises the real server tick rate (like `/tick rate`), so crops, trees, animals (growing + breeding cooldown), furnaces, brewing, eggs, effects, item cooldowns and day/night all run faster. You move faster too, pick clear / rain / storm.

## Notes
Sources use intermediary names; build.gradle maps them via `-PmapMode=layered` (default) or `intermediary` (fallback).
If one name fails to resolve at first build, fix that one line.

## Auto-Sell (Phone > Sell > Auto-Sell, free, not an upgrade)
- Click items in your inventory to put that item type on your list (click again to remove). Listed items sell for EMC every half second while they are in your inventory.
- Buttons: Auto-Sell ON/OFF, Add ores, Add junk, Clear list. The first item you add switches it on.
- Never sells enchanted or damageable gear. `/emc protect` and the server protect list still keep items.
- Players who bought the old Auto-Sell upgrade get the EMC back the next time they join.

## Auto-Sell protection
- `config/uemc.json` (created on first start): `autosellProtect` (word = any item id containing it, or exact `minecraft:item`). `autosellLevel1Max` / `autosellLevel2Max` are no longer used.
- Default protected: diamond, netherite, emerald, ancient debris, nether star, beacon, elytra, totem, trident, heart of the sea, enchanted golden apple, dragon, shulker, bundle, wither, end crystal, spawner, trial key.
- `/emc protect` (hold item) toggles your own protected item. `/emc protect list` shows both lists.
- Auto-Pickup tells you when your inventory is full; Auto-Sell plays a sound and shows items sold + EMC.

## Upgrades
- Hammer upgrade goes up to 9x9 (level 3, 600,000 EMC).

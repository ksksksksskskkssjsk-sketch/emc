# Kavlod Mod (Fabric, Minecraft 1.21.11)

## Build
Needs JDK 21 + internet (Gradle wrapper included).

    ./build.sh        (Windows: build.bat)

Jar: `dist/kavlod-mod-1.0.0.jar` (version comes from `mod_version` in gradle.properties)

## GitHub (builds the jar for you, no JDK needed)

    ./github.sh yourname/kavlod-mod            (private; add --public for public)

Then open the repo > Actions (build log) > Releases (download the jar).

## Install
Fabric Loader >= 0.18.0 + Fabric API 0.139.4+1.21.11 or newer in `mods/`, then drop the jar in.

## Items
- EMC Scanner, EMC Tablet (recipes in-game). The tablet can't be sold. Buy any item that has an EMC price: no scanning needed.
- Basic / Advanced / Ultimate Energy Converter (right-click with items)
- Prices: buy = base x3, sell = 40% (knobs in Fees.java). Enchanting Table (Tablet > Upgrades, or the Converter menu): pick any enchant, level 1-10 (X), pay in EMC. No other workstations.
- Upgrades (Tablet > Services > Upgrades): tools (Hammer, Vein Miner, Lumberjack, Auto-Repair) and ON/OFF perks (Haste, Speed, Jump, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger, Magnet, Strength, Slow Fall, Dolphin's Grace, Luck, Health Boost, Flight).
- Time & Weather (Tablet > Services > Time): skip the clock, run time x2 / x5 / x10 / x20 (you pay per real second). It raises the real server tick rate (like `/tick rate`), so crops, trees, animals (growing + breeding cooldown), furnaces, brewing, eggs, effects, item cooldowns and day/night all run faster. You move faster too, and x20 needs a strong PC, pick clear / rain / storm.

## Notes
Sources use intermediary names; build.gradle maps them via `-PmapMode=layered` (default) or `intermediary` (fallback).
If one name fails to resolve at first build, fix that one line.

package com.uemc.emc;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

/** All EMC transactions go through here. Server-side only. */
public final class EmcLogic {
    private EmcLogic() {}

    /** Value of a stack. Damaged tools scale by remaining durability. Enchants add nothing (anti-exploit). */
    public static long valueOf(class_1799 s) {
        if (s.method_7960()) return 0;
        if (s.method_31574(com.uemc.ModItems.EMC_TABLET)) return 0;   // the tablet can never be sold
        if (Fees.unsellable(net.minecraft.class_7923.field_41178.method_10221(s.method_7909()))) return 0;   // would destroy what is inside
        long base = Fees.sellUnit(EmcRegistry.get(s.method_7909()));
        if (base <= 0) return 0;
        if (s.method_7963() && s.method_7936() > 0) {
            long left = Math.max(0, s.method_7936() - s.method_7919());
            base = base * left / s.method_7936();
        }
        return base * s.method_7947();
    }

    /** Consumes the stack, adds EMC, unlocks item. Returns EMC gained (0 = nothing happened). */
    public static long convert(class_1657 p, class_1799 s) {
        long v = valueOf(s);
        if (v <= 0) return 0;
        if (!EmcData.add(p.method_5667(), v)) return 0;
        EmcData.get(p.method_5667()).discovered.add(net.minecraft.class_7923.field_41178.method_10221(s.method_7909()));
        s.method_7939(0);
        return v;
    }

    public static boolean discover(class_1657 p, class_1792 item) {
        if (!EmcRegistry.hasValue(item)) return false;
        return EmcData.get(p.method_5667()).discovered.add(net.minecraft.class_7923.field_41178.method_10221(item));
    }

    /** Buys count of any item that has an EMC price (no discovery needed). Returns error text or null on success. */
    public static String buy(class_1657 p, class_1792 item, int count) {
        if (count < 1 || count > 2304) return "Count must be 1-2304";
        long each = Fees.buyUnit(EmcRegistry.get(item));
        if (each <= 0) return "Item has no EMC value";
        long cost = each * count;
        if (!EmcData.add(p.method_5667(), -cost)) return "Not enough EMC (need " + cost + ")";
        int left = count;
        while (left > 0) {
            int n = Math.min(left, item.method_7882());
            class_1799 st = new class_1799(item, n);
            p.method_31548().method_7394(st);
            if (!st.method_7960()) p.method_7328(st, false);
            left -= n;
        }
        return null;
    }

    /** Sell one inventory slot (0-35). Returns EMC gained. */
    public static long sellSlot(class_1657 p, int slot) {
        if (slot < 0 || slot > 35) return 0;
        return convert(p, p.method_31548().method_5438(slot));
    }

    /** Sell every valued, non-enchanted stack in main inventory + hotbar. Returns EMC gained. */
    public static long sellAll(class_1657 p) {
        long total = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 s = p.method_31548().method_5438(i);
            if (s.method_7960() || s.method_7942()) continue;
            total += convert(p, s);
        }
        return total;
    }

    /** Sells the chosen inventory slots (csv of 0-35). mode 0 = whole stack, 1000 = half (min 1), 1..999 = that many from each. Returns EMC gained. */
    public static long sellSlots(class_1657 p, String csv, int mode) {
        long total = 0;
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        for (String part : csv.split(",")) {
            int i;
            try { i = Integer.parseInt(part.trim()); } catch (NumberFormatException e) { continue; }
            if (i < 0 || i > 35 || !seen.add(i)) continue;
            class_1799 s = p.method_31548().method_5438(i);
            if (s.method_7960()) continue;
            int n = mode == 0 ? s.method_7947() : mode == 1000 ? Math.max(1, s.method_7947() / 2) : Math.min(mode, s.method_7947());
            class_1799 chunk = s.method_46651(n);
            long g = convert(p, chunk);
            if (g > 0) { s.method_7934(n); total += g; }
        }
        return total;
    }

    // ---- XP <-> EMC ----
    public static final long XP_SELL = 3, XP_BUY = 30; // EMC per XP point (buy > sell: no profit loop)

    private static int pointsAt(int l) {
        if (l <= 16) return l * l + 6 * l;
        if (l <= 31) return (int) Math.round(2.5 * l * l - 40.5 * l + 360);
        return (int) Math.round(4.5 * l * l - 162.5 * l + 2220);
    }

    private static int xpForNext(int l) {
        if (l >= 30) return 112 + (l - 30) * 9;
        if (l >= 15) return 37 + (l - 15) * 5;
        return 7 + l * 2;
    }

    public static int xpTotal(class_1657 p) {
        return pointsAt(p.field_7520) + Math.round(p.field_7510 * xpForNext(p.field_7520));
    }

    private static void setXp(class_1657 p, int pts) {
        pts = Math.max(0, pts);
        int l = 0;
        while (l < 100000 && pointsAt(l + 1) <= pts) l++;
        p.field_7520 = l;
        p.field_7510 = (pts - pointsAt(l)) / (float) xpForNext(l);
        p.field_7495 = pts;
        if (p instanceof net.minecraft.class_3222 sp)
            sp.field_13987.method_14364(new net.minecraft.class_2748(
                    p.field_7510, p.field_7495, p.field_7520));
    }

    /** Gives raw XP points. */
    public static void addXp(class_1657 p, int pts) {
        if (pts > 0) setXp(p, xpTotal(p) + pts);
    }

    /** Sells levels (levels <= 0 = all XP). Returns EMC gained. */
    public static long sellXp(class_1657 p, int levels) {
        int cur = xpTotal(p);
        if (cur <= 0) return 0;
        int target = levels <= 0 ? 0 : pointsAt(Math.max(0, p.field_7520 - levels));
        long take = cur - target;
        if (take <= 0) return 0;
        long gain = take * XP_SELL;
        if (!EmcData.add(p.method_5667(), gain)) return 0;
        setXp(p, target);
        return gain;
    }

    /** Buys levels (1-100). Returns error text or null on success. */
    public static String buyXp(class_1657 p, int levels) {
        if (levels < 1 || levels > 100) return "Levels must be 1-100";
        int cur = xpTotal(p);
        int target = pointsAt(p.field_7520 + levels);
        long cost = (long) (target - cur) * XP_BUY;
        if (!EmcData.add(p.method_5667(), -cost)) return "Not enough EMC (need " + cost + ")";
        setXp(p, target);
        return null;
    }
}

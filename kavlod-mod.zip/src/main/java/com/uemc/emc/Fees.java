package com.uemc.emc;

/** EMC prices of tablet upgrades. Shared by server (charges) and client (display). */
public final class Fees {
    private Fees() {}

    // ---- ECONOMY KNOBS (change these to make it easier / harder) ----
    /** Buying an item costs base value x this. */
    public static final int BUY_MULT = 3;
    /** Selling an item gives this % of its base value (min 1 EMC per item). */
    public static final int SELL_PERCENT = 40;
    /** Price of one item when you BUY it. */
    public static long buyUnit(long base) { return base <= 0 ? 0 : base * BUY_MULT; }
    /** EMC you get for SELLING one (undamaged) item. */
    public static long sellUnit(long base) { return base <= 0 ? 0 : Math.max(1, base * SELL_PERCENT / 100); }

    /**
     * Containers (shulker boxes, bundles) are never sold: selling one destroys everything inside it.
     * Shared by server (EmcLogic) and client (tooltip / lists) so both agree.
     */
    public static boolean unsellable(net.minecraft.class_2960 id) {
        String p = id.method_12832();
        return p.endsWith("shulker_box") || p.endsWith("bundle");
    }

    public static final long REPAIR_PER_POINT = 6;

    /** Price of repairing an item with this much damage. Shared by server and client. */
    public static long repairFee(long damage) { return Math.max(0, damage) * REPAIR_PER_POINT; }

    /** Total price of having an enchant at this level. Upgrading pays the difference. */
    public static long enchant(int level) { return level <= 0 ? 0 : 3 * (1000L * level * level + 2000); }

    /** Hard cap for every enchant: level X (10). */
    public static final int MAX_ENCHANT_LEVEL = 10;

    /** Highest level you can buy: single-level enchants (Mending, Silk Touch...) stay 1, everything else goes to X (10). */
    public static int maxLevel(int vanillaMax) { return vanillaMax <= 1 ? 1 : MAX_ENCHANT_LEVEL; }

    // ---- time skip (Overworld) ----
    public static final long TIME_HOUR_FEE = 450;     // EMC per in-game hour (1000 ticks) skipped, rounded up
    public static final int TIME_FAST_STEP = 200;     // ticks of game time added per server tick in "fast" mode
    public static final int[] TIME_TARGETS = {0, 6000, 12000, 18000};
    public static final String[] TIME_NAMES = {"Morning", "Noon", "Sunset", "Midnight"};
    public static final int[] TIME_HOURS = {1, 3, 6, 12};

    /** Ticks from now to the next time-of-day target (0 = already there). */
    public static long timeDelta(long now, int target) { return (((target - now) % 24000) + 24000) % 24000; }
    public static long timeCost(long delta) { return delta <= 0 ? 0 : ((delta + 999) / 1000) * TIME_HOUR_FEE; }

    // ---- time speed: runs until stopped, the player who started it pays every real second ----
    public static final int[] SPEED_X = {1, 2, 5, 10, 20};            // 1 = normal
    public static final long[] SPEED_FEE = {0, 9, 30, 75, 180};        // EMC per real second

    // ---- weather (Overworld) ----
    public static final String[] WEATHER_NAMES = {"Clear", "Rain", "Storm"};
    public static final long[] WEATHER_FEE = {900, 900, 1800};
    public static final int[] WEATHER_TICKS = {24000, 12000, 12000};  // how long it lasts

    public static final int MAX_CHECKPOINTS = 12;
    public static final long CHECKPOINT = 300;
    public static final int TP_COOLDOWN_TICKS = 100;

    /** Teleport price: x3 of: 100 + 1 EMC per 10 blocks (same dimension) or flat 1000 across dimensions. Max 15000. */
    public static long tp(boolean sameDim, double dist) {
        return 3 * Math.min(5000, 100 + (sameDim ? (long) (dist / 10) : 1000));
    }
}

package com.uemc.client;

import com.uemc.emc.Upgrades;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/**
 * Upgrades control panel. One row per upgrade:
 *   ON/OFF switch (every upgrade), [-] [+] to run a lower or higher level of what you own (free), and Buy for the next level.
 * Bottom: ALL ON, ALL OFF, ALL MAX (everything on at its highest level). The server checks everything.
 */
public class UpgradesScreen extends ServiceScreen {
    private static final int PER = 5, ROW = 30, TOP = 28;

    private final Runnable onBack;
    private int page = 0;
    private boolean synced = false;
    private long lastBal = Long.MIN_VALUE;

    public UpgradesScreen(Runnable onBack) {
        super("TOOL & PERK UPGRADES");
        this.onBack = onBack;
        W = 350;
        H = 214;
        accent = Fx.PURPLE;
    }

    /** Called when the server sends new upgrade levels. */
    public void refresh() { method_41843(); }

    private static void send(int action, String id, int n) { ClientPlayNetworking.send(new ActionPayload(action, id, n)); }

    private static void tip(GlowButton b, String s) { b.method_47400(class_7919.method_47407(class_2561.method_43470(s))); }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; send(52, "", 0); }
        lastBal = ClientEmc.balance;
        int total = Upgrades.DEFS.length;
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= total) break;
            final Upgrades.Def u = Upgrades.DEFS[idx];
            final int own = ClientUpgrades.level(idx);
            final int run = ClientUpgrades.running(idx);
            int y = top + TOP + i * ROW + 4;
            int max = u.cost().length;

            // ON / OFF for every upgrade
            boolean on = ClientUpgrades.on(idx);
            GlowButton t = GlowButton.of(on ? "ON" : "OFF", left + 172, y, 34, 20, b -> send(51, u.id(), 0));
            t.accent = on ? Fx.GREEN : Fx.RED;
            t.field_22763 = own > 0;
            tip(t, "Switch " + u.name() + " on or off");
            method_37063(t);

            // lower / higher level (free, only between 1 and what you own)
            GlowButton dn = GlowButton.of("-", left + 210, y, 16, 20, b -> send(53, u.id(), run - 1));
            dn.accent = Fx.CYAN;
            dn.field_22763 = own > 1 && run > 1;
            tip(dn, "Run a lower level");
            method_37063(dn);
            GlowButton up = GlowButton.of("+", left + 228, y, 16, 20, b -> send(53, u.id(), run + 1));
            up.accent = Fx.CYAN;
            up.field_22763 = own > 1 && run < own;
            tip(up, "Run a higher level");
            method_37063(up);

            if (own >= max) {
                GlowButton m = GlowButton.of("MAX", left + 250, y, 92, 20, b -> {});
                m.accent = Fx.GREEN;
                m.field_22763 = false;
                method_37063(m);
            } else {
                long fee = u.cost()[own];
                boolean ok = fee <= ClientEmc.balance;
                GlowButton buy = GlowButton.of("Buy " + Fx.num(fee), left + 250, y, 92, 20, b -> send(50, u.id(), 0));
                buy.accent = ok ? Fx.GOLD : Fx.RED;
                buy.field_22763 = ok;
                tip(buy, u.name() + " level " + (own + 1) + "\n" + Fx.num(fee) + " EMC");
                method_37063(buy);
            }
        }

        int by = top + 188;
        method_37063(GlowButton.of("<", left + 8, by, 20, 18, b -> { if (page > 0) { page--; method_41843(); } }));
        method_37063(GlowButton.of(">", left + 32, by, 20, 18, b -> { if ((page + 1) * PER < total) { page++; method_41843(); } }));
        GlowButton allOn = GlowButton.of("ALL ON", left + 92, by, 62, 18, b -> send(54, "", 1));
        allOn.accent = Fx.GREEN;
        tip(allOn, "Switch every upgrade on");
        method_37063(allOn);
        GlowButton allOff = GlowButton.of("ALL OFF", left + 158, by, 62, 18, b -> send(54, "", 0));
        allOff.accent = Fx.RED;
        tip(allOff, "Switch every upgrade off");
        method_37063(allOff);
        GlowButton allMax = GlowButton.of("ALL MAX", left + 224, by, 62, 18, b -> send(54, "", 2));
        allMax.accent = Fx.GOLD;
        tip(allMax, "Everything on, at its highest level");
        method_37063(allMax);
        GlowButton back = GlowButton.of("Back", left + 290, by, 52, 18, b -> onBack.run());
        back.accent = Fx.GOLD;
        method_37063(back);
    }

    @Override
    public void method_25393() {
        if (ClientEmc.balance != lastBal) method_41843();
    }

    private void small(class_332 c, String s, int x, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.7f, 0.7f);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (x / 0.7f), (int) (y / 0.7f), color, false);
        m.popMatrix();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        int total = Upgrades.DEFS.length;
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= total) break;
            Upgrades.Def u = Upgrades.DEFS[idx];
            int own = ClientUpgrades.level(idx), run = ClientUpgrades.running(idx), max = u.cost().length;
            boolean on = ClientUpgrades.on(idx);
            int y = top + TOP + i * ROW;
            int bg = own > 0 ? (on ? 0x1A3A2A : 0x3A1A22) : 0x14202C;
            ctx.method_25294(left + 6, y + 1, left + W - 6, y + ROW - 1, Fx.argb(70, bg));
            if (own > 0 && on) ctx.method_25294(left + 6, y + 1, left + 8, y + ROW - 1, Fx.argb(200, Fx.GREEN));
            Icons.draw(ctx, u.icon(), left + 20, y + ROW / 2f, 0.9f);
            txt(ctx, u.name(), left + 34, y + 5, own > 0 && !on ? 0xFF8A8A8A : WHITE);
            String lvTxt = own <= 0 ? "Lv 0/" + max : run < own ? "Lv " + run + " of " + own : "Lv " + own + "/" + max;
            int lc = own <= 0 ? 0xFF7A8A99 : !on ? 0xFFFF8080 : run < own ? 0xFFE0B040 : 0xFF9FE8A0;
            txt(ctx, lvTxt, left + 34 + field_22793.method_1727(u.name()) + 6, y + 5, lc);
            small(ctx, field_22793.method_27523(u.desc(), 175), left + 34, y + 17, GREY);
        }
        int pages = Math.max(1, (total + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 58, top + 193, GREY);
        small(ctx, "ON/OFF = switch.  - / + = run a lower or higher level (free).  Sneak = tree mode.", left + 8, top + 180, 0xFF7A8A99);
    }
}

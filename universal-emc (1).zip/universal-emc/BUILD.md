# Build without installing anything
1. Create a GitHub repo, upload this folder's contents (keep .github folder).
2. Open the Actions tab -> "build" runs automatically (or Run workflow).
3. When green, open the run -> Artifacts -> download universal-emc (contains the JAR; use the one WITHOUT "-sources").
4. If red, open the log and send me the error lines.
Local: JDK 21 + `gradle build` (Gradle 9.2.1), JAR in build/libs.

# Status
Built OK on GitHub Actions (v1). v2 below is NOT yet compiled.
v2 adds: creative tab "Universal EMC", recipe-unlock advancements, converter menu (right-click empty hand:
 crafting, enchanting, anvil, stonecutter, grindstone, smithing, EMC shop, sell all), tablet Sell mode (sell by stack / all),
 /emc sellall, always-on dim glow + glow on any interaction, animated status lights (idle slow, active fast), antenna.
NOT done: furnace (needs block entity), moving 3D parts, batteries/cables/generators/upgrades, favorites.
Known risks: ItemStack.hasEnchantments, FabricItemGroup.builder, vanilla handler subclasses (canUse override), drawText/Tooltip calls.
v3: EMC value shown under item name in every tooltip (values synced to client on join). NOT yet compiled.
v4: buy/sell XP (tablet, converter menu, /emc sellxp, /emc buyxp). Sell 8 EMC/pt, buy 10. NOT yet compiled.
v5: mod items also in vanilla Functional/Tools creative tabs.
v6: tablet Upgrades screen: workstations, chosen enchants, fuel-free furnace (4 speeds), repair, ender chest; all EMC. NOT compiled.
v7: UI overhaul: Fx toolkit (glow panels, particles, shine, scanlines, item showcase/orbit, rolling counter, +/- popups, fade-in), GlowButton, flames. NOT compiled.
v8: teleport screen: home + up to 12 checkpoints, EMC by distance (100 + 1/10 blocks, 1000 cross-dim, max 5000), 5s cooldown. NOT compiled.
v9: fixed build errors (getServer, GlowButton drawIcon + Text shadowing). Re-run Actions.

package com.uemc;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroup {
    private ModItemGroup() {}

    public static void init() {
        ItemGroup g = FabricItemGroup.builder()
                .icon(() -> new ItemStack(ModBlocks.CONVERTER_ULTIMATE))
                .displayName(Text.translatable("itemGroup.uemc"))
                .entries((ctx, entries) -> {
                    entries.add(ModBlocks.CONVERTER_BASIC);
                    entries.add(ModBlocks.CONVERTER_ADVANCED);
                    entries.add(ModBlocks.CONVERTER_ULTIMATE);
                    entries.add(ModItems.EMC_SCANNER);
                    entries.add(ModItems.EMC_TABLET);
                })
                .build();
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.item.ItemGroups.FUNCTIONAL).register(e -> {
            e.add(ModBlocks.CONVERTER_BASIC);
            e.add(ModBlocks.CONVERTER_ADVANCED);
            e.add(ModBlocks.CONVERTER_ULTIMATE);
        });
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.item.ItemGroups.TOOLS).register(e -> {
            e.add(ModItems.EMC_SCANNER);
            e.add(ModItems.EMC_TABLET);
        });
        Registry.register(Registries.ITEM_GROUP, RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(UniversalEmc.ID, "main")), g);
    }
}

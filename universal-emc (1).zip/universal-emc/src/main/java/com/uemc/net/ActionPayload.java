package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server. action 1 = buy(item,count), 2 = convert offhand stack. */
public record ActionPayload(int action, String item, int count) implements CustomPayload {
    public static final CustomPayload.Id<ActionPayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "action"));

    public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC = new PacketCodec<>() {
        @Override
        public ActionPayload decode(RegistryByteBuf buf) {
            return new ActionPayload(buf.readVarInt(), buf.readString(256), buf.readVarInt());
        }

        @Override
        public void encode(RegistryByteBuf buf, ActionPayload p) {
            buf.writeVarInt(p.action);
            buf.writeString(p.item);
            buf.writeVarInt(p.count);
        }
    };

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

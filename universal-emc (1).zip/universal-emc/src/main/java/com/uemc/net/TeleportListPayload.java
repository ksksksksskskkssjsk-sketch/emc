package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: home + checkpoints. If hasHome, entry 0 is the home. coords = x,y,z per entry. */
public record TeleportListPayload(boolean hasHome, List<String> names, List<String> dims, List<Double> coords) implements CustomPayload {
    public static final CustomPayload.Id<TeleportListPayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "tp_list"));

    public static final PacketCodec<RegistryByteBuf, TeleportListPayload> CODEC = new PacketCodec<>() {
        @Override
        public TeleportListPayload decode(RegistryByteBuf buf) {
            boolean h = buf.readBoolean();
            int n = buf.readVarInt();
            List<String> names = new ArrayList<>(), dims = new ArrayList<>();
            List<Double> co = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                names.add(buf.readString(64));
                dims.add(buf.readString(128));
                co.add(buf.readDouble()); co.add(buf.readDouble()); co.add(buf.readDouble());
            }
            return new TeleportListPayload(h, names, dims, co);
        }

        @Override
        public void encode(RegistryByteBuf buf, TeleportListPayload p) {
            buf.writeBoolean(p.hasHome);
            buf.writeVarInt(p.names.size());
            for (int i = 0; i < p.names.size(); i++) {
                buf.writeString(p.names.get(i));
                buf.writeString(p.dims.get(i));
                buf.writeDouble(p.coords.get(i * 3)); buf.writeDouble(p.coords.get(i * 3 + 1)); buf.writeDouble(p.coords.get(i * 3 + 2));
            }
        }
    };

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

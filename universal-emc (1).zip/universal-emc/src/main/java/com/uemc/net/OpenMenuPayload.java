package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client: open the converter menu for the block at pos. */
public record OpenMenuPayload(long pos) implements CustomPayload {
    public static final CustomPayload.Id<OpenMenuPayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "open_menu"));
    public static final PacketCodec<RegistryByteBuf, OpenMenuPayload> CODEC = new PacketCodec<>() {
        @Override public OpenMenuPayload decode(RegistryByteBuf buf) { return new OpenMenuPayload(buf.readLong()); }
        @Override public void encode(RegistryByteBuf buf, OpenMenuPayload p) { buf.writeLong(p.pos); }
    };
    @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

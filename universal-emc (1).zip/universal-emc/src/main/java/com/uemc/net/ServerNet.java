package com.uemc.net;

import com.uemc.ModItems;
import com.uemc.block.ConverterBlock;
import com.uemc.emc.*;
import com.uemc.menu.Handlers;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.*;

public final class ServerNet {
    private ServerNet() {}

    /** Converter each player last opened (validated again on every packet). */
    private record Open(ServerWorld world, BlockPos pos) {}
    private static final Map<UUID, Open> OPEN = new HashMap<>();

    public static void init() {
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenMenuPayload.ID, OpenMenuPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ValuesPayload.ID, ValuesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TeleportListPayload.ID, TeleportListPayload.CODEC);
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendValues(handler.player));
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MenuActionPayload.ID, MenuActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, ctx) -> {
            ServerPlayerEntity p = ctx.player();
            if (!hasAccess(p)) return;
            switch (payload.action()) {
                case 1 -> {
                    Identifier id = Identifier.tryParse(payload.item());
                    if (id == null || !Registries.ITEM.containsId(id)) return;
                    String err = EmcLogic.buy(p, Registries.ITEM.get(id), payload.count());
                    if (err != null) p.sendMessage(Text.literal(err), true);
                    else p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 2 -> {
                    long g = EmcLogic.convert(p, p.getOffHandStack());
                    p.sendMessage(Text.literal(g > 0 ? "+" + g + " EMC" : "Offhand item has no EMC value"), true);
                }
                case 3 -> {
                    long g = EmcLogic.sellSlot(p, payload.count());
                    p.sendMessage(Text.literal(g > 0 ? "Sold +" + g + " EMC" : "Can't sell that"), true);
                    if (g > 0) p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 4 -> {
                    long g = EmcLogic.sellAll(p);
                    p.sendMessage(Text.literal(g > 0 ? "Sold everything: +" + g + " EMC" : "Nothing to sell"), true);
                    if (g > 0) p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 5 -> {
                    long g = EmcLogic.sellXp(p, payload.count());
                    p.sendMessage(Text.literal(g > 0 ? "Sold XP: +" + g + " EMC" : "No XP to sell"), true);
                    if (g > 0) p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 6 -> {
                    String err = EmcLogic.buyXp(p, payload.count());
                    if (err != null) p.sendMessage(Text.literal(err), true);
                    else p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 7 -> Services.enchant(p, payload.item(), payload.count());
                case 8 -> Services.startSmelt(p, payload.count());
                case 9 -> Services.stopSmelt(p);
                case 10 -> Services.repair(p);
                case 11 -> {}
                case 20, 21, 22, 23, 24, 25, 26 -> { Services.open(p, payload.action() - 20); return; }
                case 30 -> { Services.tpSetHome(p); return; }
                case 31 -> { Services.tpGo(p, -1); return; }
                case 32 -> { Services.tpAdd(p, payload.item()); return; }
                case 33 -> { Services.tpDelete(p, payload.count()); return; }
                case 34 -> { Services.tpGo(p, payload.count()); return; }
                case 35 -> { Services.sendTp(p); return; }
                default -> { return; }
            }
            sendState(p);
        });

        ServerPlayNetworking.registerGlobalReceiver(MenuActionPayload.ID, (payload, ctx) -> {
            ServerPlayerEntity p = ctx.player();
            Open o = OPEN.get(p.getUuid());
            BlockPos pos = BlockPos.fromLong(payload.pos());
            if (o == null || !o.pos.equals(pos) || !valid(p, o)) return;
            ConverterBlock.pulse(o.world, pos);
            ScreenHandlerContext sc = ScreenHandlerContext.create(o.world, pos);
            switch (payload.which()) {
                case 0 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Craft(id, inv, sc), Text.literal("Crafting")));
                case 1 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Enchant(id, inv, sc), Text.literal("Enchant")));
                case 2 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Anvil(id, inv, sc), Text.literal("Anvil")));
                case 3 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Stonecut(id, inv, sc), Text.literal("Stonecutter")));
                case 4 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Grind(id, inv, sc), Text.literal("Grindstone")));
                case 5 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Smith(id, inv, sc), Text.literal("Smithing")));
                case 8 -> sendState(p);
                default -> {}
            }
        });
    }

    public static void openMenu(ServerPlayerEntity p, ServerWorld w, BlockPos pos) {
        OPEN.put(p.getUuid(), new Open(w, pos.toImmutable()));
        ServerPlayNetworking.send(p, new OpenMenuPayload(pos.asLong()));
    }

    private static boolean valid(ServerPlayerEntity p, Open o) {
        return p.squaredDistanceTo(o.pos.getX() + 0.5, o.pos.getY() + 0.5, o.pos.getZ() + 0.5) <= 64
                && o.world.getBlockState(o.pos).getBlock() instanceof ConverterBlock;
    }

    /** Tablet in inventory, or standing next to the converter you opened. */
    public static boolean hasAccess(ServerPlayerEntity p) {
        if (hasTablet(p)) return true;
        Open o = OPEN.get(p.getUuid());
        return o != null && valid(p, o);
    }

    public static boolean hasTablet(ServerPlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(ModItems.EMC_TABLET)) return true;
        return false;
    }

    public static void sendValues(ServerPlayerEntity p) {
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        EmcRegistry.all().forEach((id, v) -> { ids.add(id.toString()); vals.add(v); });
        ServerPlayNetworking.send(p, new ValuesPayload(ids, vals));
    }

    public static void sendState(ServerPlayerEntity p) {
        EmcData.Player d = EmcData.get(p.getUuid());
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        for (Identifier id : d.discovered) {
            long v = EmcRegistry.get(Registries.ITEM.get(id));
            if (v > 0) { ids.add(id.toString()); vals.add(v); }
        }
        List<Long> slots = new ArrayList<>(36);
        for (int i = 0; i < 36; i++) {
            var st = p.getInventory().getStack(i);
            slots.add(st.isEmpty() ? 0L : EmcLogic.valueOf(st));
        }
        ServerPlayNetworking.send(p, new StatePayload(d.emc, EmcRegistry.size(), ids, vals, slots));
    }
}

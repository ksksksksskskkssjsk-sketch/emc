package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: every item's EMC value, sent on join so tooltips work everywhere. */
public record ValuesPayload(List<String> ids, List<Long> values) implements CustomPayload {
    public static final CustomPayload.Id<ValuesPayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "values"));

    public static final PacketCodec<RegistryByteBuf, ValuesPayload> CODEC = new PacketCodec<>() {
        @Override
        public ValuesPayload decode(RegistryByteBuf buf) {
            int n = buf.readVarInt();
            List<String> ids = new ArrayList<>(n);
            List<Long> vals = new ArrayList<>(n);
            for (int i = 0; i < n; i++) { ids.add(buf.readString()); vals.add(buf.readVarLong()); }
            return new ValuesPayload(ids, vals);
        }

        @Override
        public void encode(RegistryByteBuf buf, ValuesPayload p) {
            buf.writeVarInt(p.ids.size());
            for (int i = 0; i < p.ids.size(); i++) { buf.writeString(p.ids.get(i)); buf.writeVarLong(p.values.get(i)); }
        }
    };

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

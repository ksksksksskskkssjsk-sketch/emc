package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: player's EMC balance and discovered items with values. */
public record StatePayload(long emc, int total, List<String> ids, List<Long> values, List<Long> slots) implements CustomPayload {
    public static final CustomPayload.Id<StatePayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "state"));

    public static final PacketCodec<RegistryByteBuf, StatePayload> CODEC = new PacketCodec<>() {
        @Override
        public StatePayload decode(RegistryByteBuf buf) {
            long emc = buf.readLong();
            int total = buf.readVarInt();
            int n = buf.readVarInt();
            List<String> ids = new ArrayList<>(n);
            List<Long> vals = new ArrayList<>(n);
            for (int i = 0; i < n; i++) { ids.add(buf.readString()); vals.add(buf.readLong()); }
            int m = buf.readVarInt();
            List<Long> slots = new ArrayList<>(m);
            for (int i = 0; i < m; i++) slots.add(buf.readLong());
            return new StatePayload(emc, total, ids, vals, slots);
        }

        @Override
        public void encode(RegistryByteBuf buf, StatePayload p) {
            buf.writeLong(p.emc);
            buf.writeVarInt(p.total);
            buf.writeVarInt(p.ids.size());
            for (int i = 0; i < p.ids.size(); i++) { buf.writeString(p.ids.get(i)); buf.writeLong(p.values.get(i)); }
            buf.writeVarInt(p.slots.size());
            for (long s : p.slots) buf.writeLong(s);
        }
    };

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

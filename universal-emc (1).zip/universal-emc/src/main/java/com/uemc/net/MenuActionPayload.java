package com.uemc.net;

import com.uemc.UniversalEmc;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: which(0 craft,1 enchant,2 anvil,3 stonecutter,4 grindstone,5 smithing,8 EMC shop). */
public record MenuActionPayload(long pos, int which) implements CustomPayload {
    public static final CustomPayload.Id<MenuActionPayload> ID = new CustomPayload.Id<>(Identifier.of(UniversalEmc.ID, "menu_action"));
    public static final PacketCodec<RegistryByteBuf, MenuActionPayload> CODEC = new PacketCodec<>() {
        @Override public MenuActionPayload decode(RegistryByteBuf buf) { return new MenuActionPayload(buf.readLong(), buf.readVarInt()); }
        @Override public void encode(RegistryByteBuf buf, MenuActionPayload p) { buf.writeLong(p.pos); buf.writeVarInt(p.which); }
    };
    @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}

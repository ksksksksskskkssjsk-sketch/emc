package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.StatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** EMC Tablet: Buy mode (discovered items) and Sell mode (your inventory). Server validates everything. */
public class TabletScreen extends Screen {
    private static final int W = 250, H = 220, COLS = 7, ROWS = 5, PER = COLS * ROWS;
    private static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA;
    private static final String[] TABS = {"All", "Blocks", "Gear", "Food", "Mats"};
    private static final int[] CAT_RGB = {Fx.CYAN, Fx.GREEN, Fx.GOLD, 0xFF7070, Fx.PURPLE};

    private record Entry(String key, ItemStack stack, String name, long value, int cat, int slot) {}

    private long emc;
    private int total;
    private final List<Entry> buyAll = new ArrayList<>();
    private final List<Entry> sellAll = new ArrayList<>();
    private final List<Entry> filtered = new ArrayList<>();
    private final List<GlowButton> cells = new ArrayList<>();
    private final List<GlowButton> tabs = new ArrayList<>();
    private GlowButton modeBtn, b1, b2, b3, conv;
    private TextFieldWidget search;
    private String query = "";
    private String selectedKey = null;
    private boolean sell = false;
    private int page = 0, tab = 0, left, top;

    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;
    private final float openT = Fx.t();
    private float pageT = Fx.t();

    public TabletScreen(StatePayload s) {
        super(Text.literal("EMC Tablet"));
        load(s);
    }

    private int accent() { return sell ? Fx.GOLD : Fx.CYAN; }

    private static int category(ItemStack st) {
        if (st.isDamageable()) return 2;
        if (st.contains(DataComponentTypes.FOOD)) return 3;
        if (st.getItem() instanceof BlockItem) return 1;
        return 4;
    }

    private void load(StatePayload s) {
        emc = s.emc();
        ClientEmc.balance = emc;
        total = s.total();
        buyAll.clear();
        for (int i = 0; i < s.ids().size(); i++) {
            Identifier id = Identifier.tryParse(s.ids().get(i));
            if (id == null || !Registries.ITEM.containsId(id)) continue;
            Item it = Registries.ITEM.get(id);
            ItemStack st = new ItemStack(it);
            buyAll.add(new Entry(id.toString(), st, it.getName().getString(), s.values().get(i), category(st), -1));
        }
        buyAll.sort((a, b) -> a.name.compareToIgnoreCase(b.name));

        sellAll.clear();
        var mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            for (int i = 0; i < s.slots().size() && i < 36; i++) {
                long v = s.slots().get(i);
                ItemStack st = mc.player.getInventory().getStack(i);
                if (v <= 0 || st.isEmpty()) continue;
                sellAll.add(new Entry("slot" + i, st.copy(), st.getName().getString(), v, category(st), i));
            }
        }
    }

    public void update(StatePayload s) {
        load(s);
        refilter();
    }

    private List<Entry> source() { return sell ? sellAll : buyAll; }

    private void restyle() {
        for (GlowButton b : tabs) b.accent = accent();
        modeBtn.accent = accent();
        b1.accent = b2.accent = b3.accent = accent();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;

        tabs.clear();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            GlowButton b = GlowButton.of(TABS[i], left + 8 + i * 29, top + 20, 28, 14, x -> { tab = idx; page = 0; pageT = Fx.t(); refilter(); });
            tabs.add(b);
            addDrawableChild(b);
        }
        search = new TextFieldWidget(textRenderer, left + 8, top + 37, 140, 14, Text.literal("Search"));
        search.setText(query);
        search.setChangedListener(t -> { query = t; page = 0; pageT = Fx.t(); refilter(); });
        addDrawableChild(search);

        cells.clear();
        for (int i = 0; i < PER; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % COLS) * 18, top + 55 + (i / COLS) * 18, x -> pick(idx));
            cells.add(b);
            addDrawableChild(b);
        }
        int py = top + 149;
        addDrawableChild(GlowButton.of("<", left + 8, py, 20, 16, b -> { if (page > 0) { page--; pageT = Fx.t(); refilter(); } }));
        addDrawableChild(GlowButton.of(">", left + 114, py, 20, 16, b -> { if ((page + 1) * PER < filtered.size()) { page++; pageT = Fx.t(); refilter(); } }));

        int bx = left + 152;
        modeBtn = GlowButton.of("", bx, top + 44, 90, 14, b -> { sell = !sell; page = 0; selectedKey = null; pageT = Fx.t(); refilter(); });
        modeBtn.setTooltip(Tooltip.of(Text.literal("Switch between buying items and selling your inventory")));
        addDrawableChild(modeBtn);
        b1 = GlowButton.of("", bx, top + 106, 90, 16, b -> act(1));
        b2 = GlowButton.of("", bx, top + 123, 90, 16, b -> act(2));
        b3 = GlowButton.of("", bx, top + 140, 90, 16, b -> act(3));
        addDrawableChild(b1);
        addDrawableChild(b2);
        addDrawableChild(b3);
        conv = GlowButton.of("Convert offhand", bx, top + 157, 90, 16, b -> ClientPlayNetworking.send(new ActionPayload(2, "", 1)));
        conv.setTooltip(Tooltip.of(Text.literal("Turns the item in your offhand into EMC")));
        conv.accent = Fx.GREEN;
        addDrawableChild(conv);

        GlowButton bxp = GlowButton.of("Buy 1 lvl", left + 8, top + 176, 66, 16, b -> ClientPlayNetworking.send(new ActionPayload(6, "", 1)));
        bxp.setTooltip(Tooltip.of(Text.literal("Buy 1 XP level (10 EMC per XP point)")));
        bxp.accent = Fx.GREEN;
        addDrawableChild(bxp);
        GlowButton sxp = GlowButton.of("Sell 1 lvl", left + 78, top + 176, 66, 16, b -> ClientPlayNetworking.send(new ActionPayload(5, "", 1)));
        sxp.setTooltip(Tooltip.of(Text.literal("Sell 1 XP level (8 EMC per XP point)")));
        sxp.accent = Fx.GREEN;
        addDrawableChild(sxp);
        GlowButton axp = GlowButton.of("Sell all XP", bx, top + 176, 90, 16, b -> ClientPlayNetworking.send(new ActionPayload(5, "", 0)));
        axp.setTooltip(Tooltip.of(Text.literal("Sell all your XP for EMC (8 EMC per XP point)")));
        axp.accent = Fx.GREEN;
        addDrawableChild(axp);
        GlowButton up = GlowButton.of("Upgrades: crafting, enchant, furnace, anvil...", left + 8, top + 196, 234, 16,
                b -> MinecraftClient.getInstance().setScreen(new ServicesScreen()));
        up.setTooltip(Tooltip.of(Text.literal("Spend EMC on workstations, chosen enchants, a fuel-free furnace and repair")));
        up.accent = Fx.PURPLE;
        addDrawableChild(up);
        refilter();
    }

    private void refilter() {
        filtered.clear();
        String q = query.toLowerCase();
        for (Entry e : source()) {
            if (tab != 0 && e.cat != tab) continue;
            if (q.isEmpty() || e.name.toLowerCase().contains(q) || e.key.contains(q)) filtered.add(e);
        }
        int maxPage = Math.max(0, (filtered.size() - 1) / PER);
        if (page > maxPage) page = maxPage;
        for (int i = 0; i < cells.size(); i++) {
            GlowButton c = cells.get(i);
            int idx = page * PER + i;
            c.active = idx < filtered.size();
            if (idx < filtered.size()) {
                Entry e = filtered.get(idx);
                c.accent = CAT_RGB[e.cat];
                c.setTooltip(Tooltip.of(Text.literal(e.name + (sell ? " x" + e.stack.getCount() + "\nSells for " + Fx.num(e.value) : "\n" + Fx.num(e.value) + " EMC"))));
            } else c.setTooltip(null);
        }
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).selected = i == tab;

        modeBtn.setMessage(Text.literal(sell ? "Mode: SELL" : "Mode: BUY"));
        if (sell) {
            b1.setMessage(Text.literal("Sell this stack"));
            b2.setMessage(Text.literal("Sell ALL items"));
            b3.visible = false;
        } else {
            b1.setMessage(Text.literal("Buy 1"));
            b2.setMessage(Text.literal("Buy 16"));
            b3.setMessage(Text.literal("Buy 64"));
            b3.visible = true;
        }
        restyle();
    }

    private void pick(int idx) {
        int i = page * PER + idx;
        if (i < filtered.size()) selectedKey = filtered.get(i).key;
    }

    private Entry selected() {
        if (selectedKey == null) return null;
        for (Entry e : source()) if (e.key.equals(selectedKey)) return e;
        return null;
    }

    private void act(int n) {
        if (sell) {
            if (n == 1) {
                Entry e = selected();
                if (e != null) ClientPlayNetworking.send(new ActionPayload(3, "", e.slot));
            } else if (n == 2) {
                ClientPlayNetworking.send(new ActionPayload(4, "", 0));
            }
        } else {
            Entry e = selected();
            if (e == null) return;
            int count = n == 1 ? 1 : n == 2 ? 16 : 64;
            ClientPlayNetworking.send(new ActionPayload(1, e.key, count));
        }
    }

    private void txt(DrawContext c, String s, int x, int y, int color) {
        c.drawText(textRenderer, Text.literal(s), x, y, color, true);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, accent());
        ctx.fillGradient(left + 148, top + 20, left + 149, top + H - 8, Fx.argb(0, accent()), Fx.argb(200, accent()));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int acc = accent();
        Fx.title(ctx, textRenderer, sell ? "EMC TABLET - SELL" : "EMC TABLET - BUY", left + 8, top + 8, acc);

        if (lastBal != Long.MIN_VALUE && emc != lastBal) Fx.pop(emc - lastBal);
        lastBal = emc;
        String bal = "EMC " + Fx.num(counter.get(emc));
        int bxr = left + W - 8 - textRenderer.getWidth(bal);
        Fx.orb(ctx, bxr - 9, top + 12, acc);
        Fx.glowText(ctx, textRenderer, bal, bxr, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, textRenderer, left + W - 8, top + 18);

        float now = Fx.t();
        for (int i = 0; i < cells.size(); i++) {
            int idx = page * PER + i;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + 55 + (i / COLS) * 18 + 1;
            float appear = Fx.ease((now - pageT) * 4f - ((i % COLS) + (i / COLS)) * 0.08f);
            boolean isSel = e.key.equals(selectedKey);
            Fx.item(ctx, e.stack, x, y, cells.get(i).isHovered(), isSel, appear, CAT_RGB[e.cat]);
            if (sell && e.stack.getCount() > 1 && appear > 0.9f) {
                String cnt = String.valueOf(e.stack.getCount());
                txt(ctx, cnt, x + 17 - textRenderer.getWidth(cnt), y + 9, WHITE);
            }
        }
        int pages = Math.max(1, (filtered.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 64, top + 153, GREY);

        int bx = left + 152, bw = 90;
        float frac = total <= 0 ? 0 : (float) buyAll.size() / total;
        Fx.bar(ctx, bx, top + 24, bw, 6, frac, acc);
        txt(ctx, "Discovered " + buyAll.size() + "/" + total, bx, top + 33, GREY);

        Entry sel = selected();
        if (sel == null) {
            txt(ctx, sell ? "Select a stack" : "Select an item", bx, top + 72, GREY);
        } else {
            Fx.showcase(ctx, sel.stack, bx + 14, top + 74, 1.6f, CAT_RGB[sel.cat]);
            txt(ctx, textRenderer.trimToWidth(sel.name, 58), bx + 32, top + 62, WHITE);
            if (sell) {
                Fx.glowText(ctx, textRenderer, Fx.num(sel.value) + " EMC", bx + 32, top + 76, Fx.GOLD);
                txt(ctx, "Stack x" + sel.stack.getCount(), bx + 32, top + 90, GREY);
            } else {
                Fx.glowText(ctx, textRenderer, Fx.num(sel.value) + " EMC", bx + 32, top + 76, Fx.CYAN);
                boolean can = emc >= sel.value;
                txt(ctx, can ? "Afford " + Fx.num(emc / sel.value) : "Not enough", bx + 32, top + 90, can ? 0xFF7FFFB0 : 0xFFFF7070);
            }
        }
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

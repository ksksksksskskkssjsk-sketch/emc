package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Home + checkpoints. Teleports cost EMC by distance. Server does the real work. */
public class TeleportScreen extends ServiceScreen {
    private static final int PER = 5;
    private int page = 0;
    private String name = "";

    public TeleportScreen() {
        super("TELEPORT");
        H = 232;
        accent = Fx.mix(Fx.CYAN, Fx.GREEN, 0.5f);
        ClientPlayNetworking.send(new ActionPayload(35, "", 0));
    }

    public void refresh() { clearAndInit(); }

    private static long cost(ClientTp.Loc l) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return Fees.tp(true, 0);
        boolean same = mc.world.getRegistryKey().getValue().toString().equals(l.dim());
        double dx = mc.player.getX() - l.x(), dy = mc.player.getY() - l.y(), dz = mc.player.getZ() - l.z();
        return Fees.tp(same, Math.sqrt(dx * dx + dy * dy + dz * dz));
    }

    private static String pos(ClientTp.Loc l) { return (int) l.x() + ", " + (int) l.y() + ", " + (int) l.z(); }

    @Override
    protected void init() {
        super.init();
        ClientTp.Loc home = ClientTp.home;
        GlowButton set = GlowButton.of("Set home here", left + 10, top + 38, 112, 18, b -> ClientPlayNetworking.send(new ActionPayload(30, "", 0)));
        set.accent = Fx.GOLD;
        set.setTooltip(Tooltip.of(Text.literal("Save your current spot as home (free)")));
        addDrawableChild(set);
        GlowButton go = GlowButton.of(home == null ? "No home" : "Home - " + Fx.num(cost(home)) + " EMC", left + 128, top + 38, 112, 18,
                b -> ClientPlayNetworking.send(new ActionPayload(31, "", 0)));
        go.active = home != null;
        go.accent = Fx.GREEN;
        addDrawableChild(go);

        List<ClientTp.Loc> cps = ClientTp.checkpoints;
        page = Math.max(0, Math.min(page, (Math.max(1, cps.size()) - 1) / PER));
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= cps.size()) break;
            ClientTp.Loc l = cps.get(idx);
            final int fi = idx;
            GlowButton g = GlowButton.of(l.name() + " - " + Fx.num(cost(l)) + " EMC", left + 10, top + 78 + i * 20, 206, 18,
                    b -> ClientPlayNetworking.send(new ActionPayload(34, "", fi)));
            g.accent = Fx.CYAN;
            g.setTooltip(Tooltip.of(Text.literal(pos(l) + "\n" + l.dim())));
            addDrawableChild(g);
            GlowButton del = GlowButton.of("x", left + 220, top + 78 + i * 20, 20, 18, b -> ClientPlayNetworking.send(new ActionPayload(33, "", fi)));
            del.accent = Fx.RED;
            del.setTooltip(Tooltip.of(Text.literal("Delete checkpoint")));
            addDrawableChild(del);
        }
        addDrawableChild(GlowButton.of("<", left + 200, top + 62, 18, 12, b -> { if (page > 0) { page--; clearAndInit(); } }));
        addDrawableChild(GlowButton.of(">", left + 222, top + 62, 18, 12, b -> { if ((page + 1) * PER < ClientTp.checkpoints.size()) { page++; clearAndInit(); } }));

        TextFieldWidget f = new TextFieldWidget(textRenderer, left + 10, top + 186, 142, 16, Text.literal("Name"));
        f.setMaxLength(20);
        f.setText(name);
        f.setChangedListener(s -> name = s);
        addDrawableChild(f);
        GlowButton add = GlowButton.of("Add here - " + Fees.CHECKPOINT, left + 158, top + 186, 82, 16, b -> {
            ClientPlayNetworking.send(new ActionPayload(32, name, 0));
            name = "";
            clearAndInit();
        });
        add.accent = Fx.GOLD;
        add.setTooltip(Tooltip.of(Text.literal("Save a checkpoint at your position (" + Fees.CHECKPOINT + " EMC)")));
        addDrawableChild(add);
        GlowButton back = GlowButton.of("Back", left + 10, top + 208, 230, 16, b -> MinecraftClient.getInstance().setScreen(new ServicesScreen()));
        back.accent = Fx.GOLD;
        addDrawableChild(back);
    }

    @Override
    protected void drawContent(DrawContext ctx, int mx, int my, float delta) {
        ClientTp.Loc home = ClientTp.home;
        txt(ctx, home == null ? "Home: not set" : "Home: " + pos(home), left + 10, top + 26, GREY);
        txt(ctx, "Checkpoints " + ClientTp.checkpoints.size() + "/" + Fees.MAX_CHECKPOINTS, left + 10, top + 64, WHITE);
        if (ClientTp.checkpoints.isEmpty()) txt(ctx, "None yet - add one below", left + 10, top + 84, GREY);
        float t = Fx.t();
        for (int i = 0; i < 3; i++) {
            float a = t * 2f + i * 2.094f;
            int sx = left + W - 14 + (int) (Math.cos(a) * 5), sy = top + 30 + (int) (Math.sin(a) * 5);
            ctx.fill(sx, sy, sx + 2, sy + 2, Fx.argb(200, i == 0 ? Fx.WHITE : Fx.GREEN));
        }
    }
}

package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.MenuActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.text.Text;

/** Menu of the Energy Converter: workstations + EMC shop. Server re-checks distance and block. */
public class ConverterMenuScreen extends Screen {
    private static final int W = 190, H = 140;
    private final long pos;
    private int left, top;
    private final float openT = Fx.t();
    boolean shopRequested = false;

    public ConverterMenuScreen(long pos) {
        super(Text.literal("Energy Converter"));
        this.pos = pos;
    }

    private void add(String label, String tip, int col, int row, int which) {
        GlowButton b = GlowButton.of(label, left + 10 + col * 90, top + 26 + row * 22, 84, 18,
                x -> ClientPlayNetworking.send(new MenuActionPayload(pos, which)));
        b.setTooltip(Tooltip.of(Text.literal(tip)));
        b.accent = (col + row) % 2 == 0 ? Fx.CYAN : Fx.mix(Fx.CYAN, Fx.PURPLE, 0.5f);
        addDrawableChild(b);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        add("Crafting", "Crafting table", 0, 0, 0);
        add("Enchanting", "Enchanting table (put bookshelves around the converter)", 1, 0, 1);
        add("Anvil", "Anvil", 0, 1, 2);
        add("Stonecutter", "Stonecutter", 1, 1, 3);
        add("Grindstone", "Grindstone", 0, 2, 4);
        add("Smithing", "Smithing table", 1, 2, 5);
        GlowButton shop = GlowButton.of("EMC Shop", left + 10, top + 92, 84, 18, b -> {
            shopRequested = true;
            ClientPlayNetworking.send(new MenuActionPayload(pos, 8));
        });
        shop.setTooltip(Tooltip.of(Text.literal("Buy items with EMC, or sell items from your inventory")));
        shop.accent = Fx.GOLD;
        addDrawableChild(shop);
        GlowButton sell = GlowButton.of("Sell all items", left + 100, top + 92, 84, 18, b -> ClientPlayNetworking.send(new ActionPayload(4, "", 0)));
        sell.setTooltip(Tooltip.of(Text.literal("Sells every item in your inventory that has EMC (enchanted items are kept)")));
        sell.accent = Fx.GOLD;
        addDrawableChild(sell);
        GlowButton bxp = GlowButton.of("Buy 1 XP lvl", left + 10, top + 114, 84, 18, b -> ClientPlayNetworking.send(new ActionPayload(6, "", 1)));
        bxp.setTooltip(Tooltip.of(Text.literal("Buy 1 XP level (10 EMC per XP point)")));
        bxp.accent = Fx.GREEN;
        addDrawableChild(bxp);
        GlowButton sxp = GlowButton.of("Sell all XP", left + 100, top + 114, 84, 18, b -> ClientPlayNetworking.send(new ActionPayload(5, "", 0)));
        sxp.setTooltip(Tooltip.of(Text.literal("Sell all your XP (8 EMC per XP point)")));
        sxp.accent = Fx.GREEN;
        addDrawableChild(sxp);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, Fx.CYAN);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Fx.title(ctx, textRenderer, "ENERGY CONVERTER", left + 10, top + 10, Fx.CYAN);
        // blinking status lights
        float t = Fx.t();
        for (int i = 0; i < 4; i++) {
            float b = 0.5f + 0.5f * Fx.sin(t * (2f + i) + i * 1.7f);
            int lx = left + W - 12 - i * 7;
            Fx.glow(ctx, lx, top + 11, 3, 3, i % 2 == 0 ? Fx.CYAN : Fx.GREEN, b * 0.8f, 2);
            ctx.fill(lx, top + 11, lx + 3, top + 14, Fx.argb((int) (120 + 135 * b), i % 2 == 0 ? Fx.CYAN : Fx.GREEN));
        }
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

package com.uemc.client;

import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Client copy of all EMC values (synced from server on join). */
public final class ClientEmc {
    private static volatile Map<Identifier, Long> VALUES = new HashMap<>();

    public static volatile long balance = 0;

    private ClientEmc() {}

    public static void set(Map<Identifier, Long> m) { VALUES = m; }
    public static void clear() { VALUES = new HashMap<>(); }

    /** Value of ONE item (damaged tools scale by durability, same as server). */
    public static long unit(ItemStack s) {
        if (s.isEmpty()) return 0;
        long base = VALUES.getOrDefault(Registries.ITEM.getId(s.getItem()), 0L);
        if (base <= 0) return 0;
        if (s.isDamageable() && s.getMaxDamage() > 0) {
            long left = Math.max(0, s.getMaxDamage() - s.getDamage());
            base = base * left / s.getMaxDamage();
        }
        return base;
    }
}

package com.uemc.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Base for tablet upgrade screens: animated panel, title wave, rolling EMC counter, +/- popups, fade-in. */
public abstract class ServiceScreen extends Screen {
    protected static final int W = 250, WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA, CYAN = 0xFF00FFDD;
    protected int H = 190, left, top;
    protected int accent = Fx.CYAN;
    protected final float openT = Fx.t();
    private final String heading;
    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;

    protected ServiceScreen(String heading) {
        super(Text.literal(heading));
        this.heading = heading;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    protected void txt(DrawContext c, String s, int x, int y, int color) {
        c.drawText(textRenderer, Text.literal(s), x, y, color, true);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, accent);
    }

    /** Subclasses draw their own content here (after widgets, before header/fade). */
    protected void drawContent(DrawContext ctx, int mx, int my, float delta) {}

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        drawContent(ctx, mx, my, delta);
        Fx.title(ctx, textRenderer, heading, left + 8, top + 8, accent);
        long target = ClientEmc.balance;
        if (lastBal != Long.MIN_VALUE && target != lastBal) Fx.pop(target - lastBal);
        lastBal = target;
        String bal = "EMC " + Fx.num(counter.get(target));
        int bx = left + W - 8 - textRenderer.getWidth(bal);
        Fx.orb(ctx, bx - 9, top + 12, accent);
        Fx.glowText(ctx, textRenderer, bal, bx, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, textRenderer, left + W - 8, top + 20);
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** Fuel-free furnace. Smelts the item in your hand (then more of the same in your inventory) at the speed you pick. */
public class FurnaceScreen extends ServiceScreen {
    private int ticks = 0;
    private int activeTier = -1;
    private final java.util.List<GlowButton> tierBtns = new java.util.ArrayList<>();

    public FurnaceScreen() {
        super("FUEL-FREE FURNACE");
        H = 170;
        accent = Fx.ORANGE;
    }

    @Override
    protected void init() {
        super.init();
        tierBtns.clear();
        for (int i = 0; i < Fees.SMELT_NAMES.length; i++) {
            final int tier = i;
            double perSec = 20.0 / Fees.SMELT_INTERVAL[i] * Fees.SMELT_BATCH[i];
            GlowButton b = GlowButton.of(
                    Fees.SMELT_NAMES[i] + " - " + (perSec == Math.floor(perSec) ? String.valueOf((int) perSec) : String.valueOf(perSec)) + "/s - " + Fees.SMELT_FEE[i] + " EMC each",
                    left + 10, top + 52 + i * 22, 230, 18,
                    x -> { activeTier = tier; ClientPlayNetworking.send(new ActionPayload(8, "", tier)); });
            b.accent = Fx.mix(Fx.ORANGE, 0xFFE060, tier / 3f);
            tierBtns.add(b);
            b.setTooltip(Tooltip.of(Text.literal("Fee per item. Smelting never earns you EMC.")));
            addDrawableChild(b);
        }
        GlowButton stop = GlowButton.of("Stop", left + 10, top + 142, 112, 18, b -> { activeTier = -1; ClientPlayNetworking.send(new ActionPayload(9, "", 0)); });
        stop.accent = Fx.RED;
        addDrawableChild(stop);
        GlowButton back = GlowButton.of("Back", left + 128, top + 142, 112, 18, b -> MinecraftClient.getInstance().setScreen(new ServicesScreen()));
        back.accent = Fx.GOLD;
        addDrawableChild(back);
    }

    @Override
    public void tick() {
        for (int i = 0; i < tierBtns.size(); i++) tierBtns.get(i).selected = i == activeTier;
        if (++ticks % 40 == 0) ClientPlayNetworking.send(new ActionPayload(11, "", 0)); // refresh balance
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        Fx.flames(ctx, left + 2, top + H - 2, W - 4, activeTier < 0 ? 0.35f : 0.6f + 0.4f * activeTier / 3f);
    }

    @Override
    protected void drawContent(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ItemStack st = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandStack();
        if (st.isEmpty()) { txt(ctx, "Hold the item you want to smelt", left + 8, top + 28, GREY); return; }
        Fx.showcase(ctx, st, left + 18, top + 32, 1.0f, Fx.ORANGE);
        txt(ctx, textRenderer.trimToWidth(st.getName().getString() + " x" + st.getCount(), 200), left + 36, top + 28, WHITE);
    }
}

package com.uemc.client;

import com.uemc.net.StatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

public class UniversalEmcClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.ValuesPayload.ID, (payload, ctx) -> {
            java.util.Map<net.minecraft.util.Identifier, Long> m = new java.util.HashMap<>();
            for (int i = 0; i < payload.ids().size(); i++) {
                var id = net.minecraft.util.Identifier.tryParse(payload.ids().get(i));
                if (id != null) m.put(id, payload.values().get(i));
            }
            ClientEmc.set(m);
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.TeleportListPayload.ID, (payload, ctx) -> {
            java.util.List<ClientTp.Loc> all = new java.util.ArrayList<>();
            for (int i = 0; i < payload.names().size(); i++)
                all.add(new ClientTp.Loc(payload.names().get(i), payload.dims().get(i),
                        payload.coords().get(i * 3), payload.coords().get(i * 3 + 1), payload.coords().get(i * 3 + 2)));
            ClientTp.home = payload.hasHome() && !all.isEmpty() ? all.remove(0) : null;
            ClientTp.checkpoints = all;
            if (ctx.client().currentScreen instanceof TeleportScreen ts) ts.refresh();
        });
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> ClientEmc.clear());
        net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register((stack, ctx, type, lines) -> {
            long one = ClientEmc.unit(stack);
            net.minecraft.text.MutableText t;
            if (one <= 0) {
                t = net.minecraft.text.Text.literal("EMC: none").formatted(net.minecraft.util.Formatting.DARK_GRAY);
            } else {
                t = net.minecraft.text.Text.literal("EMC: ").formatted(net.minecraft.util.Formatting.GOLD)
                        .append(net.minecraft.text.Text.literal(String.format("%,d", one)).formatted(net.minecraft.util.Formatting.YELLOW));
                if (stack.getCount() > 1)
                    t.append(net.minecraft.text.Text.literal("  (stack " + String.format("%,d", one * stack.getCount()) + ")").formatted(net.minecraft.util.Formatting.GRAY));
            }
            lines.add(Math.min(1, lines.size()), t);
        });
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, ctx) -> {
            MinecraftClient mc = ctx.client();
            if (mc.currentScreen instanceof ConverterMenuScreen m && !m.shopRequested) return;
            if (mc.currentScreen instanceof ServiceScreen) { ClientEmc.balance = payload.emc(); return; }
            if (mc.currentScreen instanceof TabletScreen ts) ts.update(payload);
            else mc.setScreen(new TabletScreen(payload));
        });
        ClientPlayNetworking.registerGlobalReceiver(com.uemc.net.OpenMenuPayload.ID, (payload, ctx) ->
                ctx.client().setScreen(new ConverterMenuScreen(payload.pos())));
    }
}

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Tablet upgrades menu. Server charges the EMC and re-checks everything. */
public class ServicesScreen extends ServiceScreen {
    public ServicesScreen() {
        super("TABLET UPGRADES");
        H = 200;
    }

    private void btn(String label, String tip, int col, int row, Runnable r) {
        GlowButton b = GlowButton.of(label, left + 10 + col * 118, top + 24 + row * 24, 112, 20, x -> r.run());
        b.accent = (col + row) % 2 == 0 ? Fx.CYAN : Fx.mix(Fx.CYAN, Fx.PURPLE, 0.5f);
        b.setTooltip(Tooltip.of(Text.literal(tip)));
        addDrawableChild(b);
    }

    @Override
    protected void init() {
        super.init();
        for (int i = 0; i < Fees.OPEN.length; i++) {
            final int which = i;
            String nm = Fees.OPEN_NAMES[i];
            btn(nm + " - " + Fees.OPEN[i], "Open " + nm + " for " + Fees.OPEN[i] + " EMC", i % 2, i / 2,
                    () -> ClientPlayNetworking.send(new ActionPayload(20 + which, "", 0)));
        }
        btn("Enchant (choose)", "Pick the exact enchant and level for the item in your hand", 1, 3,
                () -> MinecraftClient.getInstance().setScreen(new EnchantScreen()));
        btn("Furnace (no fuel)", "Smelt with no fuel. Pick the speed.", 0, 4,
                () -> MinecraftClient.getInstance().setScreen(new FurnaceScreen()));
        btn("Repair hand", "Fully repair the held item. " + Fees.REPAIR_PER_POINT + " EMC per durability point", 1, 4,
                () -> ClientPlayNetworking.send(new ActionPayload(10, "", 0)));
        GlowButton tp = GlowButton.of("Teleport: home + checkpoints", left + 10, top + 24 + 5 * 24, 232, 20,
                b -> MinecraftClient.getInstance().setScreen(new TeleportScreen()));
        tp.accent = Fx.GREEN;
        tp.setTooltip(Tooltip.of(Text.literal("Set a home and checkpoints, teleport for EMC")));
        addDrawableChild(tp);
        GlowButton back = GlowButton.of("Back to tablet", left + 10, top + 24 + 6 * 24, 232, 18, b -> {
            MinecraftClient.getInstance().setScreen(null);
            ClientPlayNetworking.send(new ActionPayload(11, "", 0));
        });
        back.accent = Fx.GOLD;
        addDrawableChild(back);
    }
}

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Choose exactly which enchant and level to put on the item in your hand. Price in EMC. */
public class EnchantScreen extends ServiceScreen {
    private record Row(RegistryEntry<Enchantment> e, String id, String name, int max) {}

    private static final int PER = 7;
    private final List<Row> rows = new ArrayList<>();
    private ItemStack last = ItemStack.EMPTY;
    private int page = 0, lvl = 1;
    private Row sel;

    public EnchantScreen() {
        super("ENCHANT HELD ITEM");
        H = 190;
        accent = Fx.PURPLE;
    }

    private void rebuild() {
        rows.clear();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        ItemStack st = mc.player.getMainHandStack();
        last = st.copy();
        if (!st.isEmpty()) {
            var reg = mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            reg.streamEntries().forEach(ref -> {
                Enchantment en = ref.value();
                if (en.isAcceptableItem(st))
                    rows.add(new Row(ref, ref.registryKey().getValue().toString(), en.description().getString(), en.getMaxLevel()));
            });
            rows.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        }
        if (sel != null) {
            Row keep = null;
            for (Row r : rows) if (r.id.equals(sel.id)) keep = r;
            sel = keep;
        }
        page = Math.max(0, Math.min(page, (Math.max(1, rows.size()) - 1) / PER));
    }

    private int have() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (sel == null || mc.player == null) return 0;
        return EnchantmentHelper.getLevel(sel.e, mc.player.getMainHandStack());
    }

    private long cost() { return sel == null ? 0 : Math.max(0, Fees.enchant(lvl) - Fees.enchant(have())); }

    @Override
    protected void init() {
        super.init();
        rebuild();
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= rows.size()) break;
            Row r = rows.get(idx);
            String label = textRenderer.trimToWidth(r.name + (r.max > 1 ? " (1-" + r.max + ")" : ""), 138);
            GlowButton rb = GlowButton.of(label, left + 8, top + 40 + i * 18, 144, 16, b -> {
                sel = r;
                lvl = Math.max(1, Math.min(r.max, have() + 1));
                clearAndInit();
            });
            rb.accent = Fx.PURPLE;
            rb.selected = sel != null && sel.id.equals(r.id);
            addDrawableChild(rb);
        }
        addDrawableChild(GlowButton.of("<", left + 8, top + 168, 20, 16, b -> { if (page > 0) { page--; clearAndInit(); } }));
        addDrawableChild(GlowButton.of(">", left + 132, top + 168, 20, 16, b -> { if ((page + 1) * PER < rows.size()) { page++; clearAndInit(); } }));

        int bx = left + 158;
        GlowButton minus = GlowButton.of("-", bx, top + 80, 20, 16, b -> { if (sel != null && lvl > 1) { lvl--; clearAndInit(); } });
        GlowButton plus = GlowButton.of("+", bx + 64, top + 80, 20, 16, b -> { if (sel != null && lvl < sel.max) { lvl++; clearAndInit(); } });
        GlowButton apply = GlowButton.of("Enchant", bx, top + 120, 84, 18,
                b -> { if (sel != null) ClientPlayNetworking.send(new ActionPayload(7, sel.id, lvl)); });
        minus.accent = plus.accent = apply.accent = Fx.PURPLE;
        minus.active = plus.active = apply.active = sel != null;
        if (sel != null && have() >= lvl) apply.active = false;
        addDrawableChild(minus);
        addDrawableChild(plus);
        addDrawableChild(apply);
        GlowButton back = GlowButton.of("Back", bx, top + 168, 84, 16, b -> MinecraftClient.getInstance().setScreen(new ServicesScreen()));
        back.accent = Fx.GOLD;
        addDrawableChild(back);
    }

    @Override
    public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && !ItemStack.areEqual(last, mc.player.getMainHandStack())) clearAndInit();
    }

    @Override
    protected void drawContent(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ItemStack st = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandStack();
        if (st.isEmpty()) { txt(ctx, "Hold an item to enchant", left + 8, top + 26, GREY); return; }
        Fx.showcase(ctx, st, left + 16, top + 28, 1.0f, Fx.PURPLE);
        txt(ctx, textRenderer.trimToWidth(st.getName().getString(), 120), left + 32, top + 24, WHITE);
        if (rows.isEmpty()) txt(ctx, "No enchants fit this item", left + 8, top + 44, GREY);
        int bx = left + 158;
        if (sel == null) { txt(ctx, "Pick an enchant", bx, top + 44, GREY); return; }
        txt(ctx, textRenderer.trimToWidth(sel.name, 88), bx, top + 44, CYAN);
        txt(ctx, "Has: " + have() + " / " + sel.max, bx, top + 60, GREY);
        String l = "Lv " + lvl;
        txt(ctx, l, bx + 42 - textRenderer.getWidth(l) / 2, top + 84, WHITE);
        txt(ctx, "Price", bx, top + 102, GREY);
        Fx.glowText(ctx, textRenderer, Fx.num(cost()) + " EMC", bx, top + 110, cost() <= ClientEmc.balance ? Fx.CYAN : Fx.RED);
    }
}

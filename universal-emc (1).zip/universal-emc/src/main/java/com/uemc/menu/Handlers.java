package com.uemc.menu;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.*;

/** Vanilla workstation handlers whose canUse doesn't depend on the block being a vanilla workstation. */
public final class Handlers {
    private Handlers() {}

    public static class Craft extends CraftingScreenHandler {
        public Craft(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
    public static class Enchant extends EnchantmentScreenHandler {
        public Enchant(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
    public static class Anvil extends AnvilScreenHandler {
        public Anvil(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
    public static class Stonecut extends StonecutterScreenHandler {
        public Stonecut(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
    public static class Grind extends GrindstoneScreenHandler {
        public Grind(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
    public static class Smith extends SmithingScreenHandler {
        public Smith(int id, PlayerInventory inv, ScreenHandlerContext c) { super(id, inv, c); }
        @Override public boolean canUse(PlayerEntity p) { return true; }
    }
}

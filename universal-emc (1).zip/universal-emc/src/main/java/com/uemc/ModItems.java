package com.uemc;

import com.uemc.item.ScannerItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item EMC_SCANNER = register("emc_scanner",
            key -> new ScannerItem(new Item.Settings().registryKey(key).maxCount(1)));

    public static final Item EMC_TABLET = register("emc_tablet",
            key -> new com.uemc.item.TabletItem(new Item.Settings().registryKey(key).maxCount(1)));

    private static Item register(String name, java.util.function.Function<RegistryKey<Item>, Item> f) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(UniversalEmc.ID, name));
        return Registry.register(Registries.ITEM, key, f.apply(key));
    }

    public static void init() {}
}

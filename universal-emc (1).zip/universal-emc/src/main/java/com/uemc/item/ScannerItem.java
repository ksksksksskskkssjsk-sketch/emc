package com.uemc.item;

import com.uemc.emc.EmcLogic;
import com.uemc.emc.EmcRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import com.uemc.ModSounds;
import net.minecraft.world.World;

/** Right-click: scans offhand item. Right-click block: scans that block. Both unlock the item. */
public class ScannerItem extends Item {
    public ScannerItem(Settings settings) { super(settings); }

    private static void report(PlayerEntity p, Item item, int count) {
        long v = EmcRegistry.get(item);
        if (v <= 0) {
            p.sendMessage(Text.literal("[Scanner] " + Registries.ITEM.getId(item) + ": no EMC value"), false);
            return;
        }
        boolean fresh = EmcLogic.discover(p, item);
        p.sendMessage(Text.literal("[Scanner] " + Registries.ITEM.getId(item) + ": " + v + " EMC"
                + (count > 1 ? " (x" + count + " = " + (v * count) + ")" : "")
                + (fresh ? " - NEW DISCOVERY" : "")), false);
    }

    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        if (world.isClient()) return ActionResult.SUCCESS;
        ItemStack off = player.getOffHandStack();
        if (off.isEmpty()) {
            player.sendMessage(Text.literal("[Scanner] Hold an item in offhand, or click a block."), false);
            return ActionResult.FAIL;
        }
        report(player, off.getItem(), off.getCount());
        world.playSound(null, player.getBlockPos(), ModSounds.SCANNER_SCAN, SoundCategory.PLAYERS, 0.6f, 1.2f);
        return ActionResult.SUCCESS;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World w = ctx.getWorld();
        if (w.isClient()) return ActionResult.SUCCESS;
        PlayerEntity p = ctx.getPlayer();
        if (p == null) return ActionResult.PASS;
        Item item = w.getBlockState(ctx.getBlockPos()).getBlock().asItem();
        report(p, item, 1);
        if (w instanceof ServerWorld sw) {
            BlockPos bp = ctx.getBlockPos();
            sw.playSound(null, bp, ModSounds.SCANNER_SCAN, SoundCategory.PLAYERS, 0.6f, 1.0f);
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, bp.getX() + 0.5, bp.getY() + 1.05, bp.getZ() + 0.5, 14, 0.4, 0.05, 0.4, 0.05);
        }
        return ActionResult.SUCCESS;
    }
}

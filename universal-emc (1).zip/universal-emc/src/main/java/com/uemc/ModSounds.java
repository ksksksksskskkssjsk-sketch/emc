package com.uemc;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    public static final SoundEvent CONVERTER_START = reg("converter_start");
    public static final SoundEvent CONVERTER_DONE = reg("converter_done");
    public static final SoundEvent SCANNER_SCAN = reg("scanner_scan");
    public static final SoundEvent TABLET_OPEN = reg("tablet_open");
    public static final SoundEvent EMC_TRANSACT = reg("emc_transact");

    private static SoundEvent reg(String n) {
        Identifier id = Identifier.of(UniversalEmc.ID, n);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {}
}

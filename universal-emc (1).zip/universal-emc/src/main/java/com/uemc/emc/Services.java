package com.uemc.emc;

import com.uemc.menu.Handlers;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;

/** Tablet upgrades: workstations, chosen enchants, fuel-free furnace, repair. All paid in EMC, all server-side. */
public final class Services {
    private Services() {}

    private static final Map<UUID, ServerWorld> WORLDS = new HashMap<>();

    private static final class Job {
        final Item item; final int tier; int timer = 0, done = 0;
        Job(Item item, int tier) { this.item = item; this.tier = tier; }
    }
    private static final Map<UUID, Job> JOBS = new HashMap<>();

    private static MinecraftServer SERVER;
    private static MinecraftServer server() { return SERVER; }

    public static void init() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> { SERVER = null; JOBS.clear(); WORLDS.clear(); });
        ServerTickEvents.END_SERVER_TICK.register(Services::tick);
    }

    public static void rememberWorld(ServerPlayerEntity p, ServerWorld w) { WORLDS.put(p.getUuid(), w); }

    private static void msg(ServerPlayerEntity p, String s) { p.sendMessage(Text.literal(s), true); }

    private static boolean pay(ServerPlayerEntity p, long fee) {
        if (EmcData.add(p.getUuid(), -fee)) return true;
        msg(p, "Not enough EMC (need " + fee + ")");
        return false;
    }

    private static ServerWorld worldOf(ServerPlayerEntity p) {
        for (ServerWorld w : server().getWorlds()) if (w.getPlayerByUuid(p.getUuid()) != null) return w;
        return WORLDS.getOrDefault(p.getUuid(), server().getOverworld());
    }

    // ---------- home + checkpoints ----------
    private static final Map<UUID, Integer> TP_LAST = new HashMap<>();

    private static EmcData.Loc here(ServerPlayerEntity p, String name) {
        return new EmcData.Loc(name, worldOf(p).getRegistryKey().getValue().toString(),
                p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch());
    }

    public static void sendTp(ServerPlayerEntity p) {
        EmcData.Player d = EmcData.get(p.getUuid());
        List<String> names = new ArrayList<>(), dims = new ArrayList<>();
        List<Double> co = new ArrayList<>();
        List<EmcData.Loc> all = new ArrayList<>();
        if (d.home != null) all.add(d.home);
        all.addAll(d.checkpoints);
        for (EmcData.Loc l : all) { names.add(l.name()); dims.add(l.dim()); co.add(l.x()); co.add(l.y()); co.add(l.z()); }
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.uemc.net.TeleportListPayload(d.home != null, names, dims, co));
    }

    public static void tpSetHome(ServerPlayerEntity p) {
        EmcData.get(p.getUuid()).home = here(p, "Home");
        msg(p, "Home set here");
        sendTp(p);
    }

    public static void tpAdd(ServerPlayerEntity p, String raw) {
        EmcData.Player d = EmcData.get(p.getUuid());
        if (d.checkpoints.size() >= Fees.MAX_CHECKPOINTS) { msg(p, "Max " + Fees.MAX_CHECKPOINTS + " checkpoints"); return; }
        String name = raw == null ? "" : raw.replaceAll("[^\\x20-\\x7E]", "").trim();
        if (name.length() > 20) name = name.substring(0, 20);
        if (name.isEmpty()) name = "Checkpoint " + (d.checkpoints.size() + 1);
        if (!pay(p, Fees.CHECKPOINT)) return;
        d.checkpoints.add(here(p, name));
        msg(p, "Checkpoint \"" + name + "\" saved");
        sendTp(p);
    }

    public static void tpDelete(ServerPlayerEntity p, int idx) {
        EmcData.Player d = EmcData.get(p.getUuid());
        if (idx < 0 || idx >= d.checkpoints.size()) return;
        d.checkpoints.remove(idx);
        sendTp(p);
    }

    /** idx -1 = home, otherwise checkpoint index. */
    public static void tpGo(ServerPlayerEntity p, int idx) {
        EmcData.Player d = EmcData.get(p.getUuid());
        EmcData.Loc l = idx < 0 ? d.home : (idx < d.checkpoints.size() ? d.checkpoints.get(idx) : null);
        if (l == null) { msg(p, idx < 0 ? "No home set" : "No such checkpoint"); return; }
        int now = server().getTicks();
        Integer last = TP_LAST.get(p.getUuid());
        if (last != null && now - last < Fees.TP_COOLDOWN_TICKS && now >= last) { msg(p, "Teleport cooling down"); return; }
        ServerWorld dest = null;
        for (ServerWorld w : server().getWorlds()) if (w.getRegistryKey().getValue().toString().equals(l.dim())) dest = w;
        if (dest == null) { msg(p, "That dimension is not available"); return; }
        ServerWorld cur = worldOf(p);
        boolean same = cur == dest;
        double dist = same ? Math.sqrt(p.squaredDistanceTo(l.x(), l.y(), l.z())) : 0;
        long fee = Fees.tp(same, dist);
        if (!pay(p, fee)) return;
        cur.spawnParticles(net.minecraft.particle.ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.3, 0.6, 0.3, 0.2);
        boolean ok = p.teleport(dest, l.x(), l.y(), l.z(), java.util.Set.of(), l.yaw(), l.pitch(), true);
        if (!ok) { EmcData.add(p.getUuid(), fee); msg(p, "Teleport failed"); return; }
        TP_LAST.put(p.getUuid(), now);
        dest.spawnParticles(net.minecraft.particle.ParticleTypes.PORTAL, l.x(), l.y() + 1, l.z(), 40, 0.3, 0.6, 0.3, 0.2);
        p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.8f, 0.6f);
        msg(p, "Teleported to " + l.name() + " for " + fee + " EMC");
    }

    // ---------- workstations ----------
    public static void open(ServerPlayerEntity p, int which) {
        if (which < 0 || which >= Fees.OPEN.length) return;
        ServerWorld w = worldOf(p);
        ScreenHandlerContext sc = ScreenHandlerContext.create(w, p.getBlockPos());
        if (!pay(p, Fees.OPEN[which])) return;
        switch (which) {
            case 0 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Craft(id, inv, sc), Text.literal("Crafting")));
            case 1 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Anvil(id, inv, sc), Text.literal("Anvil")));
            case 2 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Stonecut(id, inv, sc), Text.literal("Stonecutter")));
            case 3 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Grind(id, inv, sc), Text.literal("Grindstone")));
            case 4 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Smith(id, inv, sc), Text.literal("Smithing")));
            case 5 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) -> new Handlers.Enchant(id, inv, sc), Text.literal("Enchant")));
            case 6 -> p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                    (id, inv, pl) -> GenericContainerScreenHandler.createGeneric9x3(id, inv, p.getEnderChestInventory()), Text.literal("Ender Chest")));
            default -> {}
        }
    }

    // ---------- repair ----------
    public static void repair(ServerPlayerEntity p) {
        ItemStack st = p.getMainHandStack();
        if (st.isEmpty() || !st.isDamageable() || st.getDamage() <= 0) { msg(p, "Hold a damaged item"); return; }
        long fee = (long) st.getDamage() * Fees.REPAIR_PER_POINT;
        if (!pay(p, fee)) return;
        st.setDamage(0);
        msg(p, "Repaired for " + fee + " EMC");
    }

    // ---------- chosen enchant ----------
    public static void enchant(ServerPlayerEntity p, String idStr, int level) {
        ItemStack st = p.getMainHandStack();
        if (st.isEmpty()) { msg(p, "Hold an item"); return; }
        Identifier id = Identifier.tryParse(idStr);
        if (id == null) return;
        var reg = server().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        var opt = reg.getOptional(RegistryKey.of(RegistryKeys.ENCHANTMENT, id));
        if (opt.isEmpty()) return;
        RegistryEntry<Enchantment> e = opt.get();
        Enchantment en = e.value();
        if (level < 1 || level > en.getMaxLevel()) { msg(p, "Bad level"); return; }
        if (!en.isAcceptableItem(st)) { msg(p, "Can't go on this item"); return; }
        ItemEnchantmentsComponent cur = EnchantmentHelper.getEnchantments(st);
        for (RegistryEntry<Enchantment> o : cur.getEnchantments())
            if (!o.equals(e) && !Enchantment.canBeCombined(e, o)) { msg(p, "Conflicts with " + o.value().description().getString()); return; }
        int have = cur.getLevel(e);
        if (have >= level) { msg(p, "Already has that level"); return; }
        long fee = Fees.enchant(level) - Fees.enchant(have);
        if (!pay(p, fee)) return;
        EnchantmentHelper.apply(st, b -> b.set(e, level));
        msg(p, "Enchanted for " + fee + " EMC");
    }

    // ---------- furnace (no fuel, chosen speed) ----------
    private static ItemStack smelt(MinecraftServer s, ItemStack in) {
        ServerWorld w = s.getOverworld();
        var input = new SingleStackRecipeInput(in);
        var r = w.getRecipeManager().getFirstMatch(RecipeType.SMELTING, input, w);
        if (r.isEmpty()) return ItemStack.EMPTY;
        return r.get().value().craft(input, w.getRegistryManager());
    }

    public static void startSmelt(ServerPlayerEntity p, int tier) {
        if (tier < 0 || tier >= Fees.SMELT_FEE.length) return;
        ItemStack st = p.getMainHandStack();
        if (st.isEmpty() || smelt(server(), st.copyWithCount(1)).isEmpty()) { msg(p, "Hold something smeltable"); return; }
        JOBS.put(p.getUuid(), new Job(st.getItem(), tier));
        msg(p, Fees.SMELT_NAMES[tier] + " furnace started");
    }

    public static void stopSmelt(ServerPlayerEntity p) {
        Job j = JOBS.remove(p.getUuid());
        if (j != null) msg(p, "Furnace stopped. Smelted " + j.done);
    }

    private static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Job>> it = JOBS.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            Job j = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null) { it.remove(); continue; }
            if (++j.timer < Fees.SMELT_INTERVAL[j.tier]) continue;
            j.timer = 0;
            String stop = null;
            for (int b = 0; b < Fees.SMELT_BATCH[j.tier] && stop == null; b++) stop = step(server, p, j);
            if (stop != null) { it.remove(); msg(p, stop + " Smelted " + j.done); }
            else msg(p, "Smelting... " + j.done);
        }
    }

    /** One item. Returns null to keep going, or the reason to stop. */
    private static String step(MinecraftServer server, ServerPlayerEntity p, Job j) {
        var inv = p.getInventory();
        ItemStack st = null;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && s.isOf(j.item)) { st = s; break; }
        }
        if (st == null) return "Done.";
        ItemStack one = st.copyWithCount(1);
        ItemStack out = smelt(server, one);
        if (out.isEmpty()) return "Can't smelt.";
        long gain = Math.max(0, EmcLogic.valueOf(out) - EmcLogic.valueOf(one)); // never profitable
        long fee = Fees.SMELT_FEE[j.tier] + gain;
        if (!EmcData.add(p.getUuid(), -fee)) return "Not enough EMC.";
        st.decrement(1);
        j.done += out.getCount();
        inv.insertStack(out);
        if (!out.isEmpty()) p.dropItem(out, false);
        return null;
    }
}

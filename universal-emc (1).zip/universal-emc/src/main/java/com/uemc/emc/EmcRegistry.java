package com.uemc.emc;

import com.google.gson.*;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import com.uemc.UniversalEmc;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Central EMC values. Defaults + config/uemc_values.json overrides. Value 0 = excluded. */
public final class EmcRegistry {
    private static final Map<Identifier, Long> VALUES = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private EmcRegistry() {}

    public static void load(MinecraftServer server) {
        VALUES.clear();
        java.util.Set<Identifier> locked = new java.util.HashSet<>();
        try (var in = EmcRegistry.class.getResourceAsStream("/data/uemc/base_values.json")) {
            JsonObject o = JsonParser.parseReader(new java.io.InputStreamReader(in)).getAsJsonObject();
            for (var e : o.entrySet()) { Identifier id = Identifier.of(e.getKey()); VALUES.put(id, e.getValue().getAsLong()); locked.add(id); }
        } catch (Exception ex) {
            UniversalEmc.LOG.error("Failed reading base_values.json", ex);
        }
        Path file = server.getPath("config").resolve("uemc_values.json");
        try {
            if (!Files.exists(file)) {
                Files.createDirectories(file.getParent());
                JsonObject o = new JsonObject();
                o.addProperty("_comment", "Overrides. \"minecraft:diamond\": 5000. Set 0 to exclude an item.");
                Files.writeString(file, GSON.toJson(o));
            } else {
                JsonObject o = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
                for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                    if (e.getKey().startsWith("_")) continue;
                    Identifier id = Identifier.of(e.getKey());
                    VALUES.put(id, Math.max(0, e.getValue().getAsLong()));
                    locked.add(id);
                }
            }
        } catch (IOException | RuntimeException ex) {
            UniversalEmc.LOG.error("Failed reading EMC config", ex);
        }
        RecipeEmc.compute(server, VALUES, locked);
        VALUES.values().removeIf(v -> v <= 0);
    }

    public static long get(Item item) {
        return VALUES.getOrDefault(Registries.ITEM.getId(item), 0L);
    }

    public static Map<Identifier, Long> all() { return Collections.unmodifiableMap(VALUES); }

    public static boolean hasValue(Item item) { return get(item) > 0; }
    public static int size() { return VALUES.size(); }
}

package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Per-player EMC balance + discoveries. Server-side only; saved to <world>/uemc_players.json. */
public final class EmcData {
    public record Loc(String name, String dim, double x, double y, double z, float yaw, float pitch) {}

    private static JsonObject locJson(Loc l) {
        JsonObject o = new JsonObject();
        o.addProperty("name", l.name()); o.addProperty("dim", l.dim());
        o.addProperty("x", l.x()); o.addProperty("y", l.y()); o.addProperty("z", l.z());
        o.addProperty("yaw", l.yaw()); o.addProperty("pitch", l.pitch());
        return o;
    }

    private static Loc jsonLoc(JsonObject o) {
        return new Loc(o.get("name").getAsString(), o.get("dim").getAsString(), o.get("x").getAsDouble(),
                o.get("y").getAsDouble(), o.get("z").getAsDouble(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat());
    }

    public static final class Player {
        public long emc = 0;
        public Loc home = null;
        public final java.util.List<Loc> checkpoints = new java.util.ArrayList<>();
        public final Set<Identifier> discovered = new HashSet<>();
    }

    private static final Map<UUID, Player> PLAYERS = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private EmcData() {}

    private static Path file(MinecraftServer s) { return s.getSavePath(WorldSavePath.ROOT).resolve("uemc_players.json"); }

    public static Player get(UUID id) { return PLAYERS.computeIfAbsent(id, k -> new Player()); }

    /** Atomic add: returns false (no change) if it would go below 0 or overflow. */
    public static boolean add(UUID id, long amount) {
        Player p = get(id);
        long n;
        try { n = Math.addExact(p.emc, amount); } catch (ArithmeticException e) { return false; }
        if (n < 0) return false;
        p.emc = n;
        return true;
    }

    public static void load(MinecraftServer s) {
        PLAYERS.clear();
        Path f = file(s);
        if (!Files.exists(f)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                JsonObject o = e.getValue().getAsJsonObject();
                Player p = new Player();
                p.emc = o.get("emc").getAsLong();
                for (JsonElement d : o.getAsJsonArray("discovered")) p.discovered.add(Identifier.of(d.getAsString()));
                try {
                    if (o.has("home")) p.home = jsonLoc(o.getAsJsonObject("home"));
                    if (o.has("checkpoints")) for (JsonElement c : o.getAsJsonArray("checkpoints")) p.checkpoints.add(jsonLoc(c.getAsJsonObject()));
                } catch (RuntimeException ignored) {}
                PLAYERS.put(UUID.fromString(e.getKey()), p);
            }
        } catch (IOException | RuntimeException ex) {
            UniversalEmc.LOG.error("Failed loading player EMC data", ex);
        }
    }

    public static void save(MinecraftServer s) {
        JsonObject root = new JsonObject();
        PLAYERS.forEach((id, p) -> {
            JsonObject o = new JsonObject();
            o.addProperty("emc", p.emc);
            JsonArray a = new JsonArray();
            p.discovered.forEach(i -> a.add(i.toString()));
            o.add("discovered", a);
            if (p.home != null) o.add("home", locJson(p.home));
            JsonArray cps = new JsonArray();
            p.checkpoints.forEach(l -> cps.add(locJson(l)));
            o.add("checkpoints", cps);
            root.add(id.toString(), o);
        });
        try {
            Path f = file(s), tmp = f.resolveSibling("uemc_players.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            UniversalEmc.LOG.error("Failed saving player EMC data", ex);
        }
    }
}

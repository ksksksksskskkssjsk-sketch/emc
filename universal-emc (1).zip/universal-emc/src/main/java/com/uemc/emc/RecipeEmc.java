package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.resource.Resource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;

import java.io.Reader;
import java.util.*;

/**
 * Derives EMC for craftable items from recipe JSONs (vanilla + any datapack/mod).
 * Output value = floor(sum(inputs) / output count), repeated until stable.
 * Values only ever decrease -> no craft/uncraft loop can create EMC.
 */
final class RecipeEmc {
    private record Rec(Identifier out, int count, List<List<Identifier>> ingredients) {}

    private RecipeEmc() {}

    static void compute(MinecraftServer server, Map<Identifier, Long> values, Set<Identifier> locked) {
        List<Rec> recs = new ArrayList<>();
        var found = server.getResourceManager().findResources("recipe", id -> id.getPath().endsWith(".json"));
        for (Map.Entry<Identifier, Resource> e : found.entrySet()) {
            try (Reader r = e.getValue().getReader()) {
                JsonElement el = JsonParser.parseReader(r);
                if (el.isJsonObject()) parse(el.getAsJsonObject(), recs);
            } catch (Exception ex) {
                UniversalEmc.LOG.debug("Skipped recipe {}: {}", e.getKey(), ex.toString());
            }
        }
        for (int pass = 0; pass < 60; pass++) {
            boolean changed = false;
            for (Rec rec : recs) {
                if (locked.contains(rec.out)) continue;
                long sum = 0;
                boolean ok = true;
                for (List<Identifier> opts : rec.ingredients) {
                    long best = Long.MAX_VALUE;
                    for (Identifier i : opts) {
                        long v = values.getOrDefault(i, 0L);
                        if (v > 0 && v < best) best = v;
                    }
                    if (best == Long.MAX_VALUE) { ok = false; break; }
                    sum += best;
                }
                if (!ok) continue;
                long cand = sum / rec.count;
                if (cand <= 0) continue;
                Long cur = values.get(rec.out);
                if (cur == null || cur <= 0 || cand < cur) { values.put(rec.out, cand); changed = true; }
            }
            if (!changed) break;
        }
        UniversalEmc.LOG.info("Recipes parsed for EMC: {}", recs.size());
    }

    private static void parse(JsonObject o, List<Rec> out) {
        if (!o.has("type")) return;
        String type = o.get("type").getAsString().replace("minecraft:", "");
        switch (type) {
            case "crafting_shaped" -> {
                JsonObject key = o.getAsJsonObject("key");
                Map<String, List<Identifier>> k = new HashMap<>();
                for (var e : key.entrySet()) k.put(e.getKey(), ing(e.getValue()));
                List<List<Identifier>> list = new ArrayList<>();
                for (JsonElement row : o.getAsJsonArray("pattern"))
                    for (char c : row.getAsString().toCharArray()) {
                        if (c == ' ') continue;
                        List<Identifier> x = k.get(String.valueOf(c));
                        if (x == null) return;
                        list.add(x);
                    }
                add(out, o.get("result"), list);
            }
            case "crafting_shapeless" -> {
                List<List<Identifier>> list = new ArrayList<>();
                for (JsonElement i : o.getAsJsonArray("ingredients")) list.add(ing(i));
                add(out, o.get("result"), list);
            }
            case "smelting", "blasting", "smoking", "campfire_cooking", "stonecutting" ->
                add(out, o.get("result"), List.of(ing(o.get("ingredient"))));
            case "crafting_transmute" ->
                add(out, o.get("result"), List.of(ing(o.get("input")), ing(o.get("material"))));
            case "smithing_transform" ->
                add(out, o.get("result"), List.of(ing(o.get("template")), ing(o.get("base")), ing(o.get("addition"))));
            default -> {}
        }
    }

    private static void add(List<Rec> out, JsonElement result, List<List<Identifier>> ings) {
        String id; int count = 1;
        if (result.isJsonPrimitive()) id = result.getAsString();
        else {
            JsonObject r = result.getAsJsonObject();
            id = r.has("id") ? r.get("id").getAsString() : r.get("item").getAsString();
            if (r.has("count")) count = Math.max(1, r.get("count").getAsInt());
        }
        for (List<Identifier> l : ings) if (l.isEmpty()) return;
        out.add(new Rec(Identifier.of(id), count, ings));
    }

    /** Ingredient -> candidate item ids (string, "#tag", array, or legacy {item}/{tag}). */
    private static List<Identifier> ing(JsonElement e) {
        List<Identifier> res = new ArrayList<>();
        if (e == null) return res;
        if (e.isJsonArray()) { for (JsonElement x : e.getAsJsonArray()) res.addAll(ing(x)); return res; }
        String s;
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("item")) s = o.get("item").getAsString();
            else if (o.has("tag")) s = "#" + o.get("tag").getAsString();
            else return res;
        } else s = e.getAsString();
        if (s.startsWith("#")) {
            TagKey<Item> tag = TagKey.of(RegistryKeys.ITEM, Identifier.of(s.substring(1)));
            for (RegistryEntry<Item> en : Registries.ITEM.iterateEntries(tag)) res.add(Registries.ITEM.getId(en.value()));
        } else res.add(Identifier.of(s));
        return res;
    }
}

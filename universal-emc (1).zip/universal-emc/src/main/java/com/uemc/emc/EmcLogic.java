package com.uemc.emc;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;

/** All EMC transactions go through here. Server-side only. */
public final class EmcLogic {
    private EmcLogic() {}

    /** Value of a stack. Damaged tools scale by remaining durability. Enchants add nothing (anti-exploit). */
    public static long valueOf(ItemStack s) {
        if (s.isEmpty()) return 0;
        long base = EmcRegistry.get(s.getItem());
        if (base <= 0) return 0;
        if (s.isDamageable() && s.getMaxDamage() > 0) {
            long left = Math.max(0, s.getMaxDamage() - s.getDamage());
            base = base * left / s.getMaxDamage();
        }
        return base * s.getCount();
    }

    /** Consumes the stack, adds EMC, unlocks item. Returns EMC gained (0 = nothing happened). */
    public static long convert(PlayerEntity p, ItemStack s) {
        long v = valueOf(s);
        if (v <= 0) return 0;
        if (!EmcData.add(p.getUuid(), v)) return 0;
        EmcData.get(p.getUuid()).discovered.add(net.minecraft.registry.Registries.ITEM.getId(s.getItem()));
        s.setCount(0);
        return v;
    }

    public static boolean discover(PlayerEntity p, Item item) {
        if (!EmcRegistry.hasValue(item)) return false;
        return EmcData.get(p.getUuid()).discovered.add(net.minecraft.registry.Registries.ITEM.getId(item));
    }

    /** Buys count of a discovered item. Returns error text or null on success. */
    public static String buy(PlayerEntity p, Item item, int count) {
        if (count < 1 || count > 2304) return "Count must be 1-2304";
        long each = EmcRegistry.get(item);
        if (each <= 0) return "Item has no EMC value";
        var id = net.minecraft.registry.Registries.ITEM.getId(item);
        if (!EmcData.get(p.getUuid()).discovered.contains(id)) return "Not discovered yet";
        long cost = each * count;
        if (!EmcData.add(p.getUuid(), -cost)) return "Not enough EMC (need " + cost + ")";
        int left = count;
        while (left > 0) {
            int n = Math.min(left, item.getMaxCount());
            ItemStack st = new ItemStack(item, n);
            p.getInventory().insertStack(st);
            if (!st.isEmpty()) p.dropItem(st, false);
            left -= n;
        }
        return null;
    }

    /** Sell one inventory slot (0-35). Returns EMC gained. */
    public static long sellSlot(PlayerEntity p, int slot) {
        if (slot < 0 || slot > 35) return 0;
        return convert(p, p.getInventory().getStack(slot));
    }

    /** Sell every valued, non-enchanted stack in main inventory + hotbar. Returns EMC gained. */
    public static long sellAll(PlayerEntity p) {
        long total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty() || s.hasEnchantments()) continue;
            total += convert(p, s);
        }
        return total;
    }

    // ---- XP <-> EMC ----
    public static final long XP_SELL = 8, XP_BUY = 10; // EMC per XP point (buy > sell: no profit loop)

    private static int pointsAt(int l) {
        if (l <= 16) return l * l + 6 * l;
        if (l <= 31) return (int) Math.round(2.5 * l * l - 40.5 * l + 360);
        return (int) Math.round(4.5 * l * l - 162.5 * l + 2220);
    }

    private static int xpForNext(int l) {
        if (l >= 30) return 112 + (l - 30) * 9;
        if (l >= 15) return 37 + (l - 15) * 5;
        return 7 + l * 2;
    }

    public static int xpTotal(PlayerEntity p) {
        return pointsAt(p.experienceLevel) + Math.round(p.experienceProgress * xpForNext(p.experienceLevel));
    }

    private static void setXp(PlayerEntity p, int pts) {
        pts = Math.max(0, pts);
        int l = 0;
        while (l < 100000 && pointsAt(l + 1) <= pts) l++;
        p.experienceLevel = l;
        p.experienceProgress = (pts - pointsAt(l)) / (float) xpForNext(l);
        p.totalExperience = pts;
        if (p instanceof net.minecraft.server.network.ServerPlayerEntity sp)
            sp.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.ExperienceBarUpdateS2CPacket(
                    p.experienceProgress, p.totalExperience, p.experienceLevel));
    }

    /** Sells levels (levels <= 0 = all XP). Returns EMC gained. */
    public static long sellXp(PlayerEntity p, int levels) {
        int cur = xpTotal(p);
        if (cur <= 0) return 0;
        int target = levels <= 0 ? 0 : pointsAt(Math.max(0, p.experienceLevel - levels));
        long take = cur - target;
        if (take <= 0) return 0;
        long gain = take * XP_SELL;
        if (!EmcData.add(p.getUuid(), gain)) return 0;
        setXp(p, target);
        return gain;
    }

    /** Buys levels (1-100). Returns error text or null on success. */
    public static String buyXp(PlayerEntity p, int levels) {
        if (levels < 1 || levels > 100) return "Levels must be 1-100";
        int cur = xpTotal(p);
        int target = pointsAt(p.experienceLevel + levels);
        long cost = (long) (target - cur) * XP_BUY;
        if (!EmcData.add(p.getUuid(), -cost)) return "Not enough EMC (need " + cost + ")";
        setXp(p, target);
        return null;
    }
}

package com.uemc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.uemc.emc.*;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public final class EmcCommands {
    private EmcCommands() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((d, access, env) -> d.register(
            CommandManager.literal("emc")
                .then(CommandManager.literal("balance").executes(c -> {
                    PlayerEntity p = c.getSource().getPlayerOrThrow();
                    msg(p, "EMC: " + EmcData.get(p.getUuid()).emc + " | Discovered: " + EmcData.get(p.getUuid()).discovered.size());
                    return 1;
                }))
                .then(CommandManager.literal("convert").executes(c -> {
                    PlayerEntity p = c.getSource().getPlayerOrThrow();
                    ItemStack s = p.getMainHandStack();
                    long g = EmcLogic.convert(p, s);
                    msg(p, g > 0 ? "+" + g + " EMC" : "Item has no EMC value");
                    return 1;
                }))
                .then(CommandManager.literal("give")
                    .then(CommandManager.argument("item", ItemStackArgumentType.itemStack(access))
                        .executes(c -> give(c, 1))
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 2304))
                            .executes(c -> give(c, IntegerArgumentType.getInteger(c, "count"))))))
                .then(CommandManager.literal("sellall").executes(c -> {
                    PlayerEntity p = c.getSource().getPlayerOrThrow();
                    long g = EmcLogic.sellAll(p);
                    msg(p, g > 0 ? "Sold everything: +" + g + " EMC" : "Nothing to sell");
                    return 1;
                }))
                .then(CommandManager.literal("sellxp").executes(c -> {
                    PlayerEntity p = c.getSource().getPlayerOrThrow();
                    long g = EmcLogic.sellXp(p, 0);
                    msg(p, g > 0 ? "Sold XP: +" + g + " EMC" : "No XP to sell");
                    return 1;
                }))
                .then(CommandManager.literal("buyxp")
                    .then(CommandManager.argument("levels", IntegerArgumentType.integer(1, 100)).executes(c -> {
                        PlayerEntity p = c.getSource().getPlayerOrThrow();
                        String err = EmcLogic.buyXp(p, IntegerArgumentType.getInteger(c, "levels"));
                        msg(p, err == null ? "Bought XP levels" : err);
                        return err == null ? 1 : 0;
                    })))
                .then(CommandManager.literal("list").executes(c -> {
                    PlayerEntity p = c.getSource().getPlayerOrThrow();
                    var set = EmcData.get(p.getUuid()).discovered;
                    msg(p, set.isEmpty() ? "Nothing discovered" : String.join(", ", set.stream().map(Object::toString).sorted().toList()));
                    return 1;
                }))
        ));
    }

    private static int give(com.mojang.brigadier.context.CommandContext<net.minecraft.server.command.ServerCommandSource> c, int n) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        PlayerEntity p = c.getSource().getPlayerOrThrow();
        Item item = ItemStackArgumentType.getItemStackArgument(c, "item").getItem();
        String err = EmcLogic.buy(p, item, n);
        msg(p, err == null ? "Got " + n + "x " + Registries.ITEM.getId(item) : err);
        return err == null ? 1 : 0;
    }

    private static void msg(PlayerEntity p, String s) { p.sendMessage(Text.literal(s), false); }
}

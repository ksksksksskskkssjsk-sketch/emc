# Status — NOTHING COMPILED OR RUN IN-GAME YET
Done (code written, unverified):
- EMC registry (base_values.json + recipe-derived + config), per-player data, EmcLogic
- EMC Scanner (animated texture, sound, particles), EMC Tablet (animated texture, sound, tabs/search/tooltips/progress bar GUI)
- 3 Energy Converters (basic/advanced/ultimate): 3D elements model, animated active core, charge state 0-8 (light, particles, beam, sounds), recipes, loot
- 5 original sounds (synthesized OGG), sounds.json, lang
NOT done: batteries, cables, generators, upgrades, machine GUI/inventories, rotating/moving parts (needs block entity renderer), favorites, GUI transitions, permissions
Known risks: 1.21.11 API names (onUseWithItem, input, particles), untested
Next: build, fix errors, then energy network

## API check against 1.21.11 Yarn javadoc (build.1/build.4)
Verified: AbstractBlock.onUse/onUseWithItem/scheduledTick/getCodec/createCodec signatures.
Fixed: DrawContext.drawText String overload not guaranteed in 1.21.11 -> all text now uses Text overload.
Verified: ServerWorld.spawnParticles(9-arg) exists unchanged through 1.21.5+.
Still unverified: CustomPayload/PacketCodec anonymous codecs,
 Screen.renderBackground override, Entity.playSound, ItemStack.copyWithCount, Item.use/useOnBlock return types.

Added .github/workflows/build.yml + BUILD.md so the JAR can be built in the cloud (no local setup).

Build log #1: Gradle got 403 from repo.maven.apache.org (asm-tree 9.9 pom) -> added Google Maven Central mirror in settings.gradle/build.gradle. Compile not reached yet.

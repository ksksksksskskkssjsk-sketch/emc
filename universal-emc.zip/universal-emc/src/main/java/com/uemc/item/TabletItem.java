package com.uemc.item;

import com.uemc.net.ServerNet;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class TabletItem extends Item {
    public TabletItem(Settings s) { super(s); }

    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient() && player instanceof ServerPlayerEntity sp) {
            ServerNet.sendState(sp);
            world.playSound(null, player.getBlockPos(), com.uemc.ModSounds.TABLET_OPEN, net.minecraft.sound.SoundCategory.PLAYERS, 0.6f, 1.0f);
        }
        return ActionResult.SUCCESS;
    }
}

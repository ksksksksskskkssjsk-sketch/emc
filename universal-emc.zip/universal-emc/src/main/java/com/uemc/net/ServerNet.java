package com.uemc.net;

import com.uemc.ModItems;
import com.uemc.emc.*;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class ServerNet {
    private ServerNet() {}

    public static void init() {
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, ctx) -> {
            ServerPlayerEntity p = ctx.player();
            if (!hasTablet(p)) return;
            if (payload.action() == 1) {
                Identifier id = Identifier.tryParse(payload.item());
                if (id == null || !Registries.ITEM.containsId(id)) return;
                String err = EmcLogic.buy(p, Registries.ITEM.get(id), payload.count());
                if (err != null) p.sendMessage(Text.literal(err), true);
                else p.playSound(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
            } else if (payload.action() == 2) {
                long g = EmcLogic.convert(p, p.getOffHandStack());
                p.sendMessage(Text.literal(g > 0 ? "+" + g + " EMC" : "Offhand item has no EMC value"), true);
            }
            sendState(p);
        });
    }

    public static boolean hasTablet(ServerPlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(ModItems.EMC_TABLET)) return true;
        return false;
    }

    public static void sendState(ServerPlayerEntity p) {
        EmcData.Player d = EmcData.get(p.getUuid());
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        for (Identifier id : d.discovered) {
            long v = EmcRegistry.get(Registries.ITEM.get(id));
            if (v > 0) { ids.add(id.toString()); vals.add(v); }
        }
        ServerPlayNetworking.send(p, new StatePayload(d.emc, EmcRegistry.size(), ids, vals));
    }
}

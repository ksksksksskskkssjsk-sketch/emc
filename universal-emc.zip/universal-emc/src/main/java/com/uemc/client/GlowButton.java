package com.uemc.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Button with animated hover glow, shine sweep and accent line. cell=true makes it an item slot. */
public class GlowButton extends ButtonWidget {
    private float hover = 0;
    public int accent = Fx.CYAN;
    public boolean cell = false;
    public boolean selected = false;

    private GlowButton(int x, int y, int w, int h, Text msg, PressAction a) {
        super(x, y, w, h, msg, a, DEFAULT_NARRATION_SUPPLIER);
    }

    public static GlowButton of(String label, int x, int y, int w, int h, PressAction a) {
        return new GlowButton(x, y, w, h, Text.literal(label), a);
    }

    public static GlowButton slot(int x, int y, PressAction a) {
        GlowButton b = new GlowButton(x, y, 18, 18, Text.empty(), a);
        b.cell = true;
        return b;
    }

    @Override
    public void renderWidget(DrawContext c, int mx, int my, float delta) {
        float target = (isHovered() && active) ? 1f : 0f;
        hover += (target - hover) * 0.25f;
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        float t = Fx.t();
        int acc = accent;
        float glowAmt = Math.max(hover, selected ? 0.7f + 0.2f * Fx.sin(t * 4f) : 0f);

        if (!cell && glowAmt > 0.03f && active) Fx.glow(c, x, y, w, h, acc, glowAmt * 0.6f, 3);
        int borderA = !active ? 30 : cell ? (int) (50 + 160 * hover) : (int) (70 + 160 * glowAmt);
        c.fill(x, y, x + w, y + h, Fx.argb(255, 0x05090D));
        int top = active ? Fx.mix(0x1F2D3A, Fx.mix(0x1F2D3A, acc, 0.35f), glowAmt) : 0x151C23;
        int bot = active ? Fx.mix(0x111A22, Fx.mix(0x111A22, acc, 0.22f), glowAmt) : 0x0D1218;
        c.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, Fx.argb(255, top), Fx.argb(255, bot));
        Fx.ring(c, x, y, w, h, Fx.argb(borderA, acc));
        c.fill(x + 1, y + 1, x + w - 1, y + 2, 0x18FFFFFF);
        if (!cell && active) c.fill(x + 2, y + h - 2, x + w - 2, y + h - 1, Fx.argb((int) (60 + 195 * glowAmt), acc));

        if (hover > 0.05f && active) {
            float sx = (t * 70f) % (w + 30) - 15;
            int a = (int) Math.max(x + 1, x + sx), b = (int) Math.min(x + w - 1, x + sx + 10);
            if (b > a) c.fill(a, y + 1, b, y + h - 1, Fx.argb((int) (40 * hover), Fx.WHITE));
        }

        if (!cell) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            String s = tr.trimToWidth(getMessage().getString(), w - 6);
            int col = !active ? 0xFF6A7580 : Fx.argb(255, Fx.mix(0xE8F4F8, Fx.WHITE, glowAmt));
            int tx = x + (w - tr.getWidth(s)) / 2, ty = y + (h - 8) / 2;
            if (glowAmt > 0.3f && active) Fx.glowText(c, tr, s, tx, ty, Fx.mix(0xE8F4F8, acc, 0.35f));
            else c.drawText(tr, Text.literal(s), tx, ty, col, true);
        }
    }
}

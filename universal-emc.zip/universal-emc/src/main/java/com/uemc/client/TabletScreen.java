package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.StatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** EMC Tablet: category tabs, search, discovery bar, tooltips, buy / convert. Server validates everything. */
public class TabletScreen extends Screen {
    private static final int W = 250, H = 176, COLS = 7, ROWS = 5, PER = COLS * ROWS;
    private static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA, CYAN = 0xFF00FFDD, PANEL = 0xFF1C2833, DARK = 0xFF101820;
    private static final String[] TABS = {"All", "Blocks", "Gear", "Food", "Mats"};

    private record Entry(String id, Item item, String name, long value, int cat) {}

    private long emc;
    private int total;
    private final List<Entry> all = new ArrayList<>();
    private final List<Entry> filtered = new ArrayList<>();
    private final List<ButtonWidget> cells = new ArrayList<>();
    private final List<ButtonWidget> tabs = new ArrayList<>();
    private TextFieldWidget search;
    private String query = "";
    private String selectedId = null;
    private int page = 0, tab = 0, left, top;

    public TabletScreen(StatePayload s) {
        super(Text.literal("EMC Tablet"));
        load(s);
    }

    private static int category(Item it) {
        ItemStack st = it.getDefaultStack();
        if (st.isDamageable()) return 2;
        if (st.contains(DataComponentTypes.FOOD)) return 3;
        if (it instanceof BlockItem) return 1;
        return 4;
    }

    private void load(StatePayload s) {
        emc = s.emc();
        total = s.total();
        all.clear();
        for (int i = 0; i < s.ids().size(); i++) {
            Identifier id = Identifier.tryParse(s.ids().get(i));
            if (id == null || !Registries.ITEM.containsId(id)) continue;
            Item it = Registries.ITEM.get(id);
            all.add(new Entry(id.toString(), it, it.getName().getString(), s.values().get(i), category(it)));
        }
        all.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    public void update(StatePayload s) {
        load(s);
        refilter();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;

        tabs.clear();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.literal(TABS[i]), x -> { tab = idx; page = 0; refilter(); })
                    .dimensions(left + 8 + i * 29, top + 20, 28, 14).build();
            tabs.add(b);
            addDrawableChild(b);
        }
        search = new TextFieldWidget(textRenderer, left + 8, top + 37, 140, 14, Text.literal("Search"));
        search.setText(query);
        search.setChangedListener(t -> { query = t; page = 0; refilter(); });
        addDrawableChild(search);

        cells.clear();
        for (int i = 0; i < PER; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.empty(), x -> pick(idx))
                    .dimensions(left + 8 + (i % COLS) * 18, top + 55 + (i / COLS) * 18, 18, 18).build();
            cells.add(b);
            addDrawableChild(b);
        }
        int py = top + 149;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { if (page > 0) { page--; refilter(); } })
                .dimensions(left + 8, py, 20, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { if ((page + 1) * PER < filtered.size()) { page++; refilter(); } })
                .dimensions(left + 114, py, 20, 16).build());

        int bx = left + 152;
        addDrawableChild(ButtonWidget.builder(Text.literal("Buy 1"), b -> buy(1)).dimensions(bx, top + 94, 90, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Buy 16"), b -> buy(16)).dimensions(bx, top + 112, 90, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Buy 64"), b -> buy(64)).dimensions(bx, top + 130, 90, 16).build());
        ButtonWidget conv = ButtonWidget.builder(Text.literal("Convert offhand"),
                b -> ClientPlayNetworking.send(new ActionPayload(2, "", 1))).dimensions(bx, top + 149, 90, 16).build();
        conv.setTooltip(Tooltip.of(Text.literal("Turns the item in your offhand into EMC")));
        addDrawableChild(conv);
        refilter();
    }

    private void refilter() {
        filtered.clear();
        String q = query.toLowerCase();
        for (Entry e : all) {
            if (tab != 0 && e.cat != tab) continue;
            if (q.isEmpty() || e.name.toLowerCase().contains(q) || e.id.contains(q)) filtered.add(e);
        }
        int maxPage = Math.max(0, (filtered.size() - 1) / PER);
        if (page > maxPage) page = maxPage;
        for (int i = 0; i < cells.size(); i++) {
            ButtonWidget c = cells.get(i);
            int idx = page * PER + i;
            c.active = idx < filtered.size();
            c.setTooltip(idx < filtered.size()
                    ? Tooltip.of(Text.literal(filtered.get(idx).name + "\n" + filtered.get(idx).value + " EMC"))
                    : null);
        }
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).active = i != tab;
    }

    private void txt(DrawContext c, String s, int x, int y, int color, boolean shadow) {
        c.drawText(textRenderer, Text.literal(s), x, y, color, shadow);
    }

    private void pick(int idx) {
        int i = page * PER + idx;
        if (i < filtered.size()) selectedId = filtered.get(i).id;
    }

    private Entry selected() {
        if (selectedId == null) return null;
        for (Entry e : all) if (e.id.equals(selectedId)) return e;
        return null;
    }

    private void buy(int n) {
        if (selectedId != null) ClientPlayNetworking.send(new ActionPayload(1, selectedId, n));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        ctx.fill(left, top, left + W, top + H, DARK);
        ctx.fill(left + 1, top + 1, left + W - 1, top + H - 1, PANEL);
        // pulsing accent line (real-time animation)
        int a = 150 + (int) (105 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 400.0)));
        ctx.fill(left + 1, top + 1, left + W - 1, top + 3, (a << 24) | 0x0000FFDD);
        ctx.fill(left + 148, top + 20, left + 149, top + H - 8, DARK);   // divider
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        txt(ctx, "EMC TABLET", left + 8, top + 8, CYAN, true);
        String bal = "EMC " + emc;
        txt(ctx, bal, left + W - 8 - textRenderer.getWidth(bal), top + 8, WHITE, true);

        for (int i = 0; i < cells.size(); i++) {
            int idx = page * PER + i;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + 55 + (i / COLS) * 18 + 1;
            if (e.id.equals(selectedId)) ctx.fill(x - 1, y - 1, x + 17, y + 17, 0x6600FFDD);
            ctx.drawItem(new ItemStack(e.item), x, y);
        }
        int pages = Math.max(1, (filtered.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 64, top + 153, GREY, false);

        // discovery progress bar
        int bx = left + 152, bw = 90;
        ctx.fill(bx, top + 24, bx + bw, top + 30, DARK);
        int fill = total <= 0 ? 0 : (int) Math.min(bw, (long) bw * all.size() / total);
        ctx.fill(bx, top + 24, bx + fill, top + 30, CYAN);
        txt(ctx, "Discovered " + all.size() + "/" + total, bx, top + 33, GREY, false);

        Entry sel = selected();
        if (sel == null) {
            txt(ctx, "Select an item", bx, top + 60, GREY, false);
        } else {
            ctx.drawItem(new ItemStack(sel.item), bx, top + 50);
            txt(ctx, textRenderer.trimToWidth(sel.name, 70), bx + 20, top + 54, WHITE, false);
            txt(ctx, sel.value + " EMC each", bx, top + 74, CYAN, false);
            txt(ctx, (emc >= sel.value ? "Can afford " + (emc / sel.value) : "Not enough EMC"), bx, top + 84, GREY, false);
        }
    }
}

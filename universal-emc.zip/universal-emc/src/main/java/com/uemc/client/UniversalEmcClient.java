package com.uemc.client;

import com.uemc.net.StatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

public class UniversalEmcClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, ctx) -> {
            MinecraftClient mc = ctx.client();
            if (mc.currentScreen instanceof TabletScreen ts) ts.update(payload);
            else mc.setScreen(new TabletScreen(payload));
        });
    }
}

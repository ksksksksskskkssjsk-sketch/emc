package com.uemc.block;

import com.mojang.serialization.MapCodec;
import com.uemc.ModSounds;
import com.uemc.emc.EmcData;
import com.uemc.emc.EmcLogic;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Energy Converter. Right-click with items to convert up to perUse of them into your EMC.
 * CHARGE (0-8) is the visible machine state: drives model, light level, particles and sounds.
 */
public class ConverterBlock extends Block {
    public static final IntProperty CHARGE = IntProperty.of("charge", 0, 8);
    public static final MapCodec<ConverterBlock> CODEC = createCodec(s -> new ConverterBlock(s, 16));

    private final int perUse;

    public ConverterBlock(Settings settings, int perUse) {
        super(settings);
        this.perUse = perUse;
        setDefaultState(getStateManager().getDefaultState().with(CHARGE, 0));
    }

    @Override
    protected MapCodec<? extends Block> getCodec() { return CODEC; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(CHARGE); }

    @Override
    protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos,
                                         PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (stack.isEmpty()) return ActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
        if (world.isClient()) return ActionResult.SUCCESS;
        ServerWorld sw = (ServerWorld) world;

        int n = Math.min(stack.getCount(), perUse);
        ItemStack part = stack.copyWithCount(n);
        long gained = EmcLogic.convert(player, part);
        if (gained <= 0) {
            player.sendMessage(Text.literal("No EMC value"), true);
            return ActionResult.FAIL;
        }
        stack.decrement(n);
        player.sendMessage(Text.literal("+" + gained + " EMC  (" + EmcData.get(player.getUuid()).emc + ")"), true);

        boolean wasIdle = state.get(CHARGE) == 0;
        world.setBlockState(pos, state.with(CHARGE, 8));
        sw.scheduleBlockTick(pos, this, 4);
        if (wasIdle) sw.playSound(null, pos, ModSounds.CONVERTER_START, SoundCategory.BLOCKS, 0.8f, 1.0f);
        sw.playSound(null, pos, ModSounds.EMC_TRANSACT, SoundCategory.BLOCKS, 0.5f, 1.0f);

        // energy beam: machine core -> player
        double sx = pos.getX() + 0.5, sy = pos.getY() + 0.7, sz = pos.getZ() + 0.5;
        double dx = player.getX() - sx, dy = player.getEyeY() - sy, dz = player.getZ() - sz;
        for (int i = 0; i <= 14; i++) {
            double t = i / 14.0;
            sw.spawnParticles(ParticleTypes.END_ROD, sx + dx * t, sy + dy * t, sz + dz * t, 1, 0, 0, 0, 0);
        }
        sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, sx, pos.getY() + 1.0, sz, 12, 0.25, 0.2, 0.25, 0.1);
        return ActionResult.SUCCESS;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient()) player.sendMessage(Text.literal("Energy Converter: right-click with items (" + perUse + " per use)"), true);
        return ActionResult.SUCCESS;
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        int c = state.get(CHARGE);
        if (c <= 0) return;
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pos.getX() + 0.5, pos.getY() + 1.0 + c * 0.03, pos.getZ() + 0.5,
                2, 0.2, 0.05, 0.2, 0.02);
        if (c == 1) {
            world.playSound(null, pos, ModSounds.CONVERTER_DONE, SoundCategory.BLOCKS, 0.7f, 1.0f);
            world.spawnParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 6, 0.15, 0.1, 0.15, 0.03);
        } else {
            world.scheduleBlockTick(pos, this, 4);
        }
        world.setBlockState(pos, state.with(CHARGE, c - 1));
    }
}

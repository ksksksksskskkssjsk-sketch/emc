package com.uemc.emc;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;

/** All EMC transactions go through here. Server-side only. */
public final class EmcLogic {
    private EmcLogic() {}

    /** Value of a stack. Damaged tools scale by remaining durability. Enchants add nothing (anti-exploit). */
    public static long valueOf(ItemStack s) {
        if (s.isEmpty()) return 0;
        long base = EmcRegistry.get(s.getItem());
        if (base <= 0) return 0;
        if (s.isDamageable() && s.getMaxDamage() > 0) {
            long left = Math.max(0, s.getMaxDamage() - s.getDamage());
            base = base * left / s.getMaxDamage();
        }
        return base * s.getCount();
    }

    /** Consumes the stack, adds EMC, unlocks item. Returns EMC gained (0 = nothing happened). */
    public static long convert(PlayerEntity p, ItemStack s) {
        long v = valueOf(s);
        if (v <= 0) return 0;
        if (!EmcData.add(p.getUuid(), v)) return 0;
        EmcData.get(p.getUuid()).discovered.add(net.minecraft.registry.Registries.ITEM.getId(s.getItem()));
        s.setCount(0);
        return v;
    }

    public static boolean discover(PlayerEntity p, Item item) {
        if (!EmcRegistry.hasValue(item)) return false;
        return EmcData.get(p.getUuid()).discovered.add(net.minecraft.registry.Registries.ITEM.getId(item));
    }

    /** Buys count of a discovered item. Returns error text or null on success. */
    public static String buy(PlayerEntity p, Item item, int count) {
        if (count < 1 || count > 2304) return "Count must be 1-2304";
        long each = EmcRegistry.get(item);
        if (each <= 0) return "Item has no EMC value";
        var id = net.minecraft.registry.Registries.ITEM.getId(item);
        if (!EmcData.get(p.getUuid()).discovered.contains(id)) return "Not discovered yet";
        long cost = each * count;
        if (!EmcData.add(p.getUuid(), -cost)) return "Not enough EMC (need " + cost + ")";
        int left = count;
        while (left > 0) {
            int n = Math.min(left, item.getMaxCount());
            ItemStack st = new ItemStack(item, n);
            p.getInventory().insertStack(st);
            if (!st.isEmpty()) p.dropItem(st, false);
            left -= n;
        }
        return null;
    }
}

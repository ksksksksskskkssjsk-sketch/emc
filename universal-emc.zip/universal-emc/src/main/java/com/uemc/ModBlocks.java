package com.uemc;

import com.uemc.block.ConverterBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    public static final Block CONVERTER_BASIC = converter("converter_basic", 16);
    public static final Block CONVERTER_ADVANCED = converter("converter_advanced", 64);
    public static final Block CONVERTER_ULTIMATE = converter("converter_ultimate", 256);

    private static Block converter(String name, int perUse) {
        Identifier id = Identifier.of(UniversalEmc.ID, name);
        RegistryKey<Block> bk = RegistryKey.of(RegistryKeys.BLOCK, id);
        RegistryKey<Item> ik = RegistryKey.of(RegistryKeys.ITEM, id);
        Block b = Registry.register(Registries.BLOCK, bk, new ConverterBlock(
                AbstractBlock.Settings.create().registryKey(bk).strength(3.5f).sounds(BlockSoundGroup.METAL)
                        .nonOpaque().luminance(s -> s.get(ConverterBlock.CHARGE) > 0 ? 4 + s.get(ConverterBlock.CHARGE) : 0),
                perUse));
        Registry.register(Registries.ITEM, ik, new BlockItem(b, new Item.Settings().registryKey(ik).useBlockPrefixedTranslationKey()));
        return b;
    }

    public static void init() {}
}

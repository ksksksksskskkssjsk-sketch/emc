package com.uemc.emc;

/** EMC prices of tablet upgrades. Shared by server (charges) and client (display). */
public final class Fees {
    private Fees() {}

    public static final String[] OPEN_NAMES = {"Crafting", "Anvil", "Stonecutter", "Grindstone", "Smithing", "Enchant table", "Ender chest"};
    public static final long[] OPEN = {10, 100, 10, 20, 100, 0, 50};
    public static final long REPAIR_PER_POINT = 2;

    public static final String[] SMELT_NAMES = {"Slow", "Fast", "Turbo", "Instant"};
    public static final int[] SMELT_INTERVAL = {10, 4, 1, 1};   // ticks between batches
    public static final int[] SMELT_BATCH = {1, 1, 1, 8};       // items per batch
    public static final long[] SMELT_FEE = {1, 3, 8, 20};       // EMC per item (+ any value gained)

    /** Total price of having an enchant at this level. Upgrading pays the difference. */
    public static long enchant(int level) { return level <= 0 ? 0 : 1000L * level * level + 2000; }

    /** Highest level you can buy: single-level enchants stay 1, everything else goes up to 10. */
    public static int maxLevel(int vanillaMax) { return vanillaMax <= 1 ? 1 : Math.max(vanillaMax, 10); }

    public static final int MAX_CHECKPOINTS = 12;
    public static final long CHECKPOINT = 100;
    public static final int TP_COOLDOWN_TICKS = 100;

    /** Teleport price: 100 + 1 EMC per 10 blocks (same dimension) or flat 1000 across dimensions. Max 5000. */
    public static long tp(boolean sameDim, double dist) {
        return Math.min(5000, 100 + (sameDim ? (long) (dist / 10) : 1000));
    }
}

package com.uemc.emc;

import com.uemc.menu.Handlers;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3914;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_747;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9696;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/** Tablet upgrades: workstations, chosen enchants, fuel-free furnace, repair. All paid in EMC, all server-side. */
public final class Services {
    private Services() {}

    private static final Map<UUID, class_3218> WORLDS = new HashMap<>();

    private static final class Job {
        final class_1792 item; final int tier; int timer = 0, done = 0;
        Job(class_1792 item, int tier) { this.item = item; this.tier = tier; }
    }
    private static final Map<UUID, Job> JOBS = new HashMap<>();

    private static MinecraftServer SERVER;
    private static MinecraftServer server() { return SERVER; }

    public static void init() {
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(s -> SERVER = s);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(s -> { SERVER = null; JOBS.clear(); WORLDS.clear(); });
        ServerTickEvents.END_SERVER_TICK.register(Services::tick);
    }

    public static void rememberWorld(class_3222 p, class_3218 w) { WORLDS.put(p.method_5667(), w); }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    private static boolean pay(class_3222 p, long fee) {
        if (EmcData.add(p.method_5667(), -fee)) return true;
        msg(p, "Not enough EMC (need " + fee + ")");
        return false;
    }

    private static class_3218 worldOf(class_3222 p) {
        for (class_3218 w : server().method_3738()) if (w.method_18470(p.method_5667()) != null) return w;
        return WORLDS.getOrDefault(p.method_5667(), server().method_30002());
    }

    // ---------- home + checkpoints ----------
    private static final Map<UUID, Integer> TP_LAST = new HashMap<>();

    private static EmcData.Loc here(class_3222 p, String name) {
        return new EmcData.Loc(name, worldOf(p).method_27983().method_29177().toString(),
                p.method_23317(), p.method_23318(), p.method_23321(), p.method_36454(), p.method_36455());
    }

    public static void sendTp(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<String> names = new ArrayList<>(), dims = new ArrayList<>();
        List<Double> co = new ArrayList<>();
        List<EmcData.Loc> all = new ArrayList<>();
        if (d.home != null) all.add(d.home);
        all.addAll(d.checkpoints);
        for (EmcData.Loc l : all) { names.add(l.name()); dims.add(l.dim()); co.add(l.x()); co.add(l.y()); co.add(l.z()); }
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.uemc.net.TeleportListPayload(d.home != null, names, dims, co));
    }

    public static void tpSetHome(class_3222 p) {
        EmcData.get(p.method_5667()).home = here(p, "Home");
        msg(p, "Home set here");
        sendTp(p);
    }

    public static void tpAdd(class_3222 p, String raw) {
        EmcData.Player d = EmcData.get(p.method_5667());
        if (d.checkpoints.size() >= Fees.MAX_CHECKPOINTS) { msg(p, "Max " + Fees.MAX_CHECKPOINTS + " checkpoints"); return; }
        String name = raw == null ? "" : raw.replaceAll("[^\\x20-\\x7E]", "").trim();
        if (name.length() > 20) name = name.substring(0, 20);
        if (name.isEmpty()) name = "Checkpoint " + (d.checkpoints.size() + 1);
        if (!pay(p, Fees.CHECKPOINT)) return;
        d.checkpoints.add(here(p, name));
        msg(p, "Checkpoint \"" + name + "\" saved");
        sendTp(p);
    }

    public static void tpDelete(class_3222 p, int idx) {
        EmcData.Player d = EmcData.get(p.method_5667());
        if (idx < 0 || idx >= d.checkpoints.size()) return;
        d.checkpoints.remove(idx);
        sendTp(p);
    }

    /** idx -1 = home, otherwise checkpoint index. */
    public static void tpGo(class_3222 p, int idx) {
        EmcData.Player d = EmcData.get(p.method_5667());
        EmcData.Loc l = idx < 0 ? d.home : (idx < d.checkpoints.size() ? d.checkpoints.get(idx) : null);
        if (l == null) { msg(p, idx < 0 ? "No home set" : "No such checkpoint"); return; }
        int now = server().method_3780();
        Integer last = TP_LAST.get(p.method_5667());
        if (last != null && now - last < Fees.TP_COOLDOWN_TICKS && now >= last) { msg(p, "Teleport cooling down"); return; }
        class_3218 dest = null;
        for (class_3218 w : server().method_3738()) if (w.method_27983().method_29177().toString().equals(l.dim())) dest = w;
        if (dest == null) { msg(p, "That dimension is not available"); return; }
        class_3218 cur = worldOf(p);
        boolean same = cur == dest;
        double dist = same ? Math.sqrt(p.method_5649(l.x(), l.y(), l.z())) : 0;
        long fee = Fees.tp(same, dist);
        if (!pay(p, fee)) return;
        cur.method_65096(net.minecraft.class_2398.field_11214, p.method_23317(), p.method_23318() + 1, p.method_23321(), 40, 0.3, 0.6, 0.3, 0.2);
        boolean ok = p.method_48105(dest, l.x(), l.y(), l.z(), java.util.Set.of(), l.yaw(), l.pitch(), true);
        if (!ok) { EmcData.add(p.method_5667(), fee); msg(p, "Teleport failed"); return; }
        TP_LAST.put(p.method_5667(), now);
        dest.method_65096(net.minecraft.class_2398.field_11214, l.x(), l.y() + 1, l.z(), 40, 0.3, 0.6, 0.3, 0.2);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.8f, 0.6f);
        msg(p, "Teleported to " + l.name() + " for " + fee + " EMC");
    }

    // ---------- workstations ----------
    public static void open(class_3222 p, int which) {
        if (which < 0 || which >= Fees.OPEN.length) return;
        class_3218 w = worldOf(p);
        class_3914 sc = class_3914.method_17392(w, p.method_24515());
        if (!pay(p, Fees.OPEN[which])) return;
        switch (which) {
            case 0 -> Workbench.open(p, Workbench.CRAFT);
            case 1 -> p.method_17355(new class_747((id, inv, pl) -> new Handlers.Anvil(id, inv, sc), class_2561.method_43470("Anvil")));
            case 2 -> Workbench.open(p, Workbench.STONECUT);
            case 3 -> Workbench.open(p, Workbench.GRIND);
            case 4 -> p.method_17355(new class_747((id, inv, pl) -> new Handlers.Smith(id, inv, sc), class_2561.method_43470("Smithing")));
            case 5 -> Workbench.open(p, Workbench.ENCHANT);
            case 6 -> p.method_17355(new class_747(
                    (id, inv, pl) -> class_1707.method_19245(id, inv, p.method_7274()), class_2561.method_43470("Ender Chest")));
            default -> {}
        }
    }

    // ---------- repair ----------
    public static void repair(class_3222 p) {
        class_1799 st = p.method_6047();
        if (st.method_7960() || !st.method_7963() || st.method_7919() <= 0) { msg(p, "Hold a damaged item"); return; }
        long fee = (long) st.method_7919() * Fees.REPAIR_PER_POINT;
        if (!pay(p, fee)) return;
        st.method_7974(0);
        msg(p, "Repaired for " + fee + " EMC");
    }

    // ---------- chosen enchant ----------
    public static void enchant(class_3222 p, String idStr, int level) {
        class_1799 st = p.method_6047();
        if (st.method_7960()) { msg(p, "Hold an item"); return; }
        class_2960 id = class_2960.method_12829(idStr);
        if (id == null) return;
        var reg = server().method_30611().method_30530(class_7924.field_41265);
        var opt = reg.method_46746(class_5321.method_29179(class_7924.field_41265, id));
        if (opt.isEmpty()) return;
        class_6880<class_1887> e = opt.get();
        class_1887 en = e.comp_349();
        if (level < 1 || level > Fees.maxLevel(en.method_8183())) { msg(p, "Bad level"); return; }
        if (!en.method_8192(st)) { msg(p, "Can't go on this item"); return; }
        class_9304 cur = class_1890.method_57532(st);
        for (class_6880<class_1887> o : cur.method_57534())
            if (!o.equals(e) && !class_1887.method_60033(e, o)) { msg(p, "Conflicts with " + o.comp_349().comp_2686().getString()); return; }
        int have = cur.method_57536(e);
        if (have >= level) { msg(p, "Already has that level"); return; }
        long fee = Fees.enchant(level) - Fees.enchant(have);
        if (!pay(p, fee)) return;
        class_1890.method_57531(st, b -> b.method_57547(e, level));
        msg(p, "Enchanted for " + fee + " EMC");
    }

    // ---------- furnace (no fuel, chosen speed) ----------
    private static class_1799 smelt(MinecraftServer s, class_1799 in) {
        class_3218 w = s.method_30002();
        var input = new class_9696(in);
        var r = w.method_64577().method_8132(class_3956.field_17546, input, w);
        if (r.isEmpty()) return class_1799.field_8037;
        return r.get().comp_1933().method_59998(input, w.method_30349());
    }

    public static void startSmelt(class_3222 p, int tier) {
        if (tier < 0 || tier >= Fees.SMELT_FEE.length) return;
        class_1799 st = p.method_6047();
        if (st.method_7960() || smelt(server(), st.method_46651(1)).method_7960()) { msg(p, "Hold something smeltable"); return; }
        JOBS.put(p.method_5667(), new Job(st.method_7909(), tier));
        msg(p, Fees.SMELT_NAMES[tier] + " furnace started");
    }

    public static void stopSmelt(class_3222 p) {
        Job j = JOBS.remove(p.method_5667());
        if (j != null) msg(p, "Furnace stopped. Smelted " + j.done);
    }

    private static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Job>> it = JOBS.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            Job j = en.getValue();
            class_3222 p = server.method_3760().method_14602(en.getKey());
            if (p == null) { it.remove(); continue; }
            if (++j.timer < Fees.SMELT_INTERVAL[j.tier]) continue;
            j.timer = 0;
            String stop = null;
            for (int b = 0; b < Fees.SMELT_BATCH[j.tier] && stop == null; b++) stop = step(server, p, j);
            if (stop != null) { it.remove(); msg(p, stop + " Smelted " + j.done); }
            else msg(p, "Smelting... " + j.done);
        }
    }

    /** One item. Returns null to keep going, or the reason to stop. */
    private static String step(MinecraftServer server, class_3222 p, Job j) {
        var inv = p.method_31548();
        class_1799 st = null;
        for (int i = 0; i < 36; i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960() && s.method_31574(j.item)) { st = s; break; }
        }
        if (st == null) return "Done.";
        class_1799 one = st.method_46651(1);
        class_1799 out = smelt(server, one);
        if (out.method_7960()) return "Can't smelt.";
        long gain = Math.max(0, EmcLogic.valueOf(out) - EmcLogic.valueOf(one)); // never profitable
        long fee = Fees.SMELT_FEE[j.tier] + gain;
        if (!EmcData.add(p.method_5667(), -fee)) return "Not enough EMC.";
        st.method_7934(1);
        j.done += out.method_7947();
        inv.method_7394(out);
        if (!out.method_7960()) p.method_7328(out, false);
        return null;
    }
}

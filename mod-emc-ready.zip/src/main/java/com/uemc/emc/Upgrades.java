package com.uemc.emc;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/**
 * Account-bound upgrades bought with EMC. They apply to whatever tool you hold (no item data needed).
 * Tools: Hammer (3x3 / 5x5), Vein Miner, Lumberjack, Auto-Repair.  Sneak = vein / tree mode, no sneak = hammer mode.
 * Perks: potion-style effects you can switch on and off.
 * Shared by server (logic, price) and client (display).
 */
public final class Upgrades {
    private Upgrades() {}

    public record Def(String id, String name, String desc, String icon, boolean perk, long[] cost) {}

    public static final Def[] DEFS = {
            new Def("area", "Hammer", "Mine 3x3, then 5x5. Sneak = 1 block", "minecraft:diamond_pickaxe", false, new long[]{15000, 60000}),
            new Def("vein", "Vein Miner", "Sneak + mine ore: whole vein", "minecraft:iron_ore", false, new long[]{10000, 30000, 90000}),
            new Def("lumber", "Lumberjack", "Sneak + chop: fells the tree", "minecraft:diamond_axe", false, new long[]{8000, 25000, 60000}),
            new Def("repair", "Auto-Repair", "Held tool heals itself", "minecraft:anvil", false, new long[]{5000, 15000, 40000}),
            new Def("haste", "Haste", "Mine and swing faster", "minecraft:golden_pickaxe", true, new long[]{6000, 20000, 60000}),
            new Def("speed", "Speed", "Run faster", "minecraft:sugar", true, new long[]{5000, 15000, 45000}),
            new Def("jump", "Jump Boost", "Jump higher", "minecraft:rabbit_foot", true, new long[]{4000, 12000, 36000}),
            new Def("night", "Night Vision", "See in the dark", "minecraft:golden_carrot", true, new long[]{3000}),
            new Def("water", "Water Breathing", "Never drown", "minecraft:heart_of_the_sea", true, new long[]{3000}),
            new Def("fire", "Fire Resistance", "Immune to fire and lava", "minecraft:magma_cream", true, new long[]{4000}),
            new Def("regen", "Regeneration", "Heal over time", "minecraft:ghast_tear", true, new long[]{10000, 40000}),
            new Def("resist", "Resistance", "Take less damage", "minecraft:iron_chestplate", true, new long[]{15000, 60000}),
            new Def("food", "No Hunger", "Food bar stays full", "minecraft:cooked_beef", true, new long[]{12000}),
    };

    public static final int[] VEIN_MAX = {12, 32, 64};
    public static final int[] TREE_MAX = {32, 96, 200};
    public static final int[] REPAIR_TICKS = {100, 40, 10};   // ticks per durability point
    public static final int AREA_RADIUS_1 = 1, AREA_RADIUS_2 = 2;

    public static int indexOf(String id) {
        for (int i = 0; i < DEFS.length; i++) if (DEFS[i].id().equals(id)) return i;
        return -1;
    }

    private static int lvl(EmcData.Player d, String id) { return d.upgrades.getOrDefault(id, 0); }

    // ---------------- buying ----------------
    public static void buy(class_3222 p, String id) {
        int i = indexOf(id);
        if (i < 0) return;
        Def u = DEFS[i];
        EmcData.Player d = EmcData.get(p.method_5667());
        int lv = lvl(d, id);
        if (lv >= u.cost().length) { msg(p, u.name() + " is max level"); return; }
        long fee = u.cost()[lv];
        if (!EmcData.add(p.method_5667(), -fee)) { msg(p, "Not enough EMC (need " + fee + ")"); return; }
        d.upgrades.put(id, lv + 1);
        d.off.remove(id);
        msg(p, u.name() + " level " + (lv + 1) + " unlocked");
    }

    public static void toggle(class_3222 p, String id) {
        int i = indexOf(id);
        if (i < 0 || !DEFS[i].perk()) return;
        EmcData.Player d = EmcData.get(p.method_5667());
        if (lvl(d, id) <= 0) return;
        if (!d.off.add(id)) d.off.remove(id);
        msg(p, DEFS[i].name() + (d.off.contains(id) ? " off" : " on"));
    }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    // ---------------- events ----------------
    private static boolean busy = false;
    private static int counter = 0;

    public static void init() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy) return;
            if (!(player instanceof class_3222 sp) || !(world instanceof class_3218 sw)) return;
            busy = true;
            try { onBreak(sp, sw, pos, state); }
            catch (RuntimeException ex) { com.uemc.UniversalEmc.LOG.warn("Upgrade break failed", ex); }
            finally { busy = false; }
        });
        ServerTickEvents.END_SERVER_TICK.register(Upgrades::tick);
    }

    // ---------------- mining ----------------
    private static String itemPath(class_1799 st) {
        return class_7923.field_41178.method_10221(st.method_7909()).method_12832();
    }

    private static String blockPath(class_2680 s) {
        return class_7923.field_41175.method_10221(s.method_26204()).method_12832();
    }

    private static boolean isOre(String b) { return b.endsWith("_ore") || b.equals("ancient_debris"); }
    private static boolean isLog(String b) { return b.endsWith("_log") || b.endsWith("_stem") || b.endsWith("_wood") || b.endsWith("_hyphae"); }
    private static String oreKey(String b) { return b.startsWith("deepslate_") ? b.substring(10) : b; }

    private static boolean toolLow(class_1799 t) {
        return t.method_7960() || (t.method_7963() && t.method_7936() - t.method_7919() <= 2);
    }

    private static void onBreak(class_3222 sp, class_3218 w, class_2338 pos, class_2680 state) {
        EmcData.Player d = EmcData.get(sp.method_5667());
        if (d.upgrades.isEmpty()) return;
        class_1799 tool = sp.method_6047();
        if (tool.method_7960()) return;
        String it = itemPath(tool);
        boolean pick = it.endsWith("_pickaxe"), axe = it.endsWith("_axe"), shovel = it.endsWith("_shovel");
        if (!pick && !axe && !shovel) return;
        String bp = blockPath(state);
        if (sp.method_5715()) {
            int lum = lvl(d, "lumber"), vein = lvl(d, "vein");
            if (axe && lum > 0 && isLog(bp)) { flood(sp, w, pos, bp, false, TREE_MAX[Math.min(lum, 3) - 1]); return; }
            if (pick && vein > 0 && isOre(bp)) { flood(sp, w, pos, oreKey(bp), true, VEIN_MAX[Math.min(vein, 3) - 1]); return; }
        } else {
            int area = lvl(d, "area");
            if (area > 0) area(sp, w, pos, state, area >= 2 ? AREA_RADIUS_2 : AREA_RADIUS_1);
        }
    }

    private static boolean breakAt(class_3222 sp, class_3218 w, class_2338 p, float maxHardness) {
        class_2680 s = w.method_8320(p);
        if (s.method_26215()) return false;
        float h = s.method_26214(w, p);
        if (h < 0 || h > 50 || h > maxHardness) return false;
        if (w.method_8321(p) != null) return false;
        return sp.field_13974.method_14266(p);
    }

    /** Breaks a flat (2r+1) x (2r+1) square around the block, facing the way you look. */
    private static void area(class_3222 sp, class_3218 w, class_2338 c, class_2680 origin, int r) {
        float oh = origin.method_26214(w, c);
        float maxH = Math.max(1.5f, oh + 2f);
        float pitch = sp.method_36455();
        double yaw = Math.toRadians(sp.method_36454());
        double lx = -Math.sin(yaw), lz = Math.cos(yaw);
        int mode = Math.abs(pitch) > 55 ? 0 : (Math.abs(lz) >= Math.abs(lx) ? 1 : 2); // 0 = XZ, 1 = XY, 2 = ZY
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                if (a == 0 && b == 0) continue;
                if (toolLow(sp.method_6047())) return;
                int dx = mode == 0 ? a : mode == 1 ? a : 0;
                int dy = mode == 0 ? 0 : b;
                int dz = mode == 0 ? b : mode == 1 ? 0 : a;
                breakAt(sp, w, new class_2338(c.method_10263() + dx, c.method_10264() + dy, c.method_10260() + dz), maxH);
            }
        }
    }

    /** Breaks connected blocks of the same kind (ore vein or tree). */
    private static void flood(class_3222 sp, class_3218 w, class_2338 start, String key, boolean ore, int max) {
        Deque<class_2338> q = new ArrayDeque<>();
        Set<Long> seen = new HashSet<>();
        q.add(start);
        seen.add(start.method_10063());
        int broken = 0;
        while (!q.isEmpty() && broken < max) {
            class_2338 cur = q.poll();
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                class_2338 n = new class_2338(cur.method_10263() + dx, cur.method_10264() + dy, cur.method_10260() + dz);
                if (Math.abs(n.method_10263() - start.method_10263()) > 12 || Math.abs(n.method_10260() - start.method_10260()) > 12
                        || Math.abs(n.method_10264() - start.method_10264()) > 40) continue;
                if (!seen.add(n.method_10063())) continue;
                class_2680 s = w.method_8320(n);
                if (s.method_26215()) continue;
                String bp = blockPath(s);
                if (!(ore ? oreKey(bp) : bp).equals(key)) continue;
                if (broken >= max || toolLow(sp.method_6047())) return;
                if (breakAt(sp, w, n, 50f)) { broken++; q.add(n); }
            }
        }
    }

    // ---------------- ticking: auto-repair + perks ----------------
    private static void tick(MinecraftServer s) {
        counter++;
        for (UUID id : EmcData.all()) {
            EmcData.Player d = EmcData.get(id);
            if (d.upgrades.isEmpty()) continue;
            class_3222 p = s.method_3760().method_14602(id);
            if (p == null) continue;
            int rep = lvl(d, "repair");
            if (rep > 0 && counter % REPAIR_TICKS[Math.min(rep, 3) - 1] == 0) { heal(p.method_6047()); heal(p.method_6079()); }
            if (counter % 20 == 0) perks(p, d);
        }
    }

    private static void heal(class_1799 st) {
        if (!st.method_7960() && st.method_7963() && st.method_7919() > 0) st.method_7974(st.method_7919() - 1);
    }

    private static void give(class_3222 p, class_6880<class_1291> e, int amp) {
        p.method_6092(new class_1293(e, 260, amp, true, false));
    }

    private static void perks(class_3222 p, EmcData.Player d) {
        for (Def u : DEFS) {
            if (!u.perk()) continue;
            int lv = lvl(d, u.id());
            if (lv <= 0 || d.off.contains(u.id())) continue;
            int amp = lv - 1;
            switch (u.id()) {
                case "haste" -> give(p, class_1294.field_5917, amp);
                case "speed" -> give(p, class_1294.field_5904, amp);
                case "jump" -> give(p, class_1294.field_5913, amp);
                case "night" -> give(p, class_1294.field_5925, 0);
                case "water" -> give(p, class_1294.field_5923, 0);
                case "fire" -> give(p, class_1294.field_5918, 0);
                case "regen" -> give(p, class_1294.field_5924, amp);
                case "resist" -> give(p, class_1294.field_5907, amp);
                case "food" -> give(p, class_1294.field_5922, 0);
                default -> {}
            }
        }
    }
}

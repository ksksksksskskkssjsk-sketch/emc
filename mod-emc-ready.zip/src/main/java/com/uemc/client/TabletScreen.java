package com.uemc.client;

import com.uemc.net.ActionPayload;
import com.uemc.net.StatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;

/** EMC Tablet: Buy mode (discovered items) and Sell mode (your inventory). Server validates everything. */
public class TabletScreen extends class_437 {
    private static final int W = 250, H = 220, COLS = 7, ROWS = 5, PER = COLS * ROWS;
    private static final int WHITE = 0xFFFFFFFF, GREY = 0xFFAAAAAA;
    private static final String[] TABS = {"All", "Blocks", "Gear", "Food", "Mats"};
    private static final int[] CAT_RGB = {Fx.CYAN, Fx.GREEN, Fx.GOLD, 0xFF7070, Fx.PURPLE};

    private record Entry(String key, class_1799 stack, String name, long value, int cat, int slot) {}

    private long emc;
    private int total;
    private final List<Entry> buyAll = new ArrayList<>();
    private final List<Entry> sellAll = new ArrayList<>();
    private final List<Entry> filtered = new ArrayList<>();
    private final List<GlowButton> cells = new ArrayList<>();
    private final List<GlowButton> tabs = new ArrayList<>();
    private GlowButton modeBtn, b1, b2, b3, conv;
    private class_342 search;
    private String query = "";
    private String selectedKey = null;
    private boolean sell = false;
    private int page = 0, tab = 0, left, top;

    private final Fx.Counter counter = new Fx.Counter();
    private long lastBal = Long.MIN_VALUE;
    private final float openT = Fx.t();
    private float pageT = Fx.t();

    public TabletScreen(StatePayload s) {
        super(class_2561.method_43470("EMC Tablet"));
        load(s);
    }

    private int accent() { return sell ? Fx.GOLD : Fx.CYAN; }

    private static int category(class_1799 st) {
        if (st.method_7963()) return 2;
        if (st.method_57826(class_9334.field_50075)) return 3;
        if (st.method_7909() instanceof class_1747) return 1;
        return 4;
    }

    private void load(StatePayload s) {
        emc = s.emc();
        ClientEmc.balance = emc;
        total = s.total();
        buyAll.clear();
        for (int i = 0; i < s.ids().size(); i++) {
            class_2960 id = class_2960.method_12829(s.ids().get(i));
            if (id == null || !class_7923.field_41178.method_10250(id)) continue;
            class_1792 it = class_7923.field_41178.method_63535(id);
            class_1799 st = new class_1799(it);
            buyAll.add(new Entry(id.toString(), st, it.method_63680().getString(), s.values().get(i), category(st), -1));
        }
        buyAll.sort((a, b) -> a.name.compareToIgnoreCase(b.name));

        sellAll.clear();
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            for (int i = 0; i < s.slots().size() && i < 36; i++) {
                long v = s.slots().get(i);
                class_1799 st = mc.field_1724.method_31548().method_5438(i);
                if (v <= 0 || st.method_7960()) continue;
                sellAll.add(new Entry("slot" + i, st.method_7972(), st.method_7964().getString(), v, category(st), i));
            }
        }
    }

    public void update(StatePayload s) {
        load(s);
        refilter();
    }

    private List<Entry> source() { return sell ? sellAll : buyAll; }

    private void restyle() {
        for (GlowButton b : tabs) b.accent = accent();
        modeBtn.accent = accent();
        b1.accent = b2.accent = b3.accent = accent();
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - W) / 2;
        top = (field_22790 - H) / 2;

        tabs.clear();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            GlowButton b = GlowButton.of(TABS[i], left + 8 + i * 29, top + 20, 28, 14, x -> { tab = idx; page = 0; pageT = Fx.t(); refilter(); });
            tabs.add(b);
            method_37063(b);
        }
        search = new class_342(field_22793, left + 8, top + 37, 140, 14, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; page = 0; pageT = Fx.t(); refilter(); });
        method_37063(search);

        cells.clear();
        for (int i = 0; i < PER; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % COLS) * 18, top + 55 + (i / COLS) * 18, x -> pick(idx));
            cells.add(b);
            method_37063(b);
        }
        int py = top + 149;
        method_37063(GlowButton.of("<", left + 8, py, 20, 16, b -> { if (page > 0) { page--; pageT = Fx.t(); refilter(); } }));
        method_37063(GlowButton.of(">", left + 114, py, 20, 16, b -> { if ((page + 1) * PER < filtered.size()) { page++; pageT = Fx.t(); refilter(); } }));

        int bx = left + 152;
        modeBtn = GlowButton.of("", bx, top + 44, 90, 14, b -> class_310.method_1551().method_1507(new SellScreen(() -> {
            class_310.method_1551().method_1507(null);
            ClientPlayNetworking.send(new ActionPayload(11, "", 0));
        })));
        modeBtn.method_47400(class_7919.method_47407(class_2561.method_43470("Pick stacks from your inventory and sell them")));
        method_37063(modeBtn);
        b1 = GlowButton.of("", bx, top + 106, 90, 16, b -> act(1));
        b2 = GlowButton.of("", bx, top + 123, 90, 16, b -> act(2));
        b3 = GlowButton.of("", bx, top + 140, 90, 16, b -> act(3));
        method_37063(b1);
        method_37063(b2);
        method_37063(b3);
        conv = GlowButton.of("Convert offhand", bx, top + 157, 90, 16, b -> ClientPlayNetworking.send(new ActionPayload(2, "", 1)));
        conv.method_47400(class_7919.method_47407(class_2561.method_43470("Turns the item in your offhand into EMC")));
        conv.accent = Fx.GREEN;
        method_37063(conv);

        GlowButton xps = GlowButton.of("XP Shop: buy / sell levels", left + 8, top + 176, 234, 16, b -> class_310.method_1551().method_1507(new XpShopScreen(() -> {
            class_310.method_1551().method_1507(null);
            ClientPlayNetworking.send(new ActionPayload(11, "", 0));
        })));
        xps.method_47400(class_7919.method_47407(class_2561.method_43470("Pick how many XP levels to buy or sell, with a live price")));
        xps.accent = Fx.GREEN;
        method_37063(xps);
        GlowButton up = GlowButton.of("Upgrades, perks & services", left + 8, top + 196, 234, 16,
                b -> class_310.method_1551().method_1507(new ServicesScreen()));
        up.method_47400(class_7919.method_47407(class_2561.method_43470("Spend EMC on workstations, chosen enchants, a fuel-free furnace and repair")));
        up.accent = Fx.PURPLE;
        method_37063(up);
        refilter();
    }

    private void refilter() {
        filtered.clear();
        String q = query.toLowerCase();
        for (Entry e : source()) {
            if (tab != 0 && e.cat != tab) continue;
            if (q.isEmpty() || e.name.toLowerCase().contains(q) || e.key.contains(q)) filtered.add(e);
        }
        int maxPage = Math.max(0, (filtered.size() - 1) / PER);
        if (page > maxPage) page = maxPage;
        for (int i = 0; i < cells.size(); i++) {
            GlowButton c = cells.get(i);
            int idx = page * PER + i;
            c.field_22763 = idx < filtered.size();
            if (idx < filtered.size()) {
                Entry e = filtered.get(idx);
                c.accent = CAT_RGB[e.cat];
                c.method_47400(class_7919.method_47407(class_2561.method_43470(e.name + (sell ? " x" + e.stack.method_7947() + "\nSells for " + Fx.num(e.value) : "\n" + Fx.num(e.value) + " EMC"))));
            } else c.method_47400(null);
        }
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).selected = i == tab;

        modeBtn.method_25355(class_2561.method_43470("Sell items..."));
        if (sell) {
            b1.method_25355(class_2561.method_43470("Sell this stack"));
            b2.method_25355(class_2561.method_43470("Sell ALL items"));
            b3.field_22764 = false;
        } else {
            b1.method_25355(class_2561.method_43470("Buy 1"));
            b2.method_25355(class_2561.method_43470("Buy 16"));
            b3.method_25355(class_2561.method_43470("Buy 64"));
            b3.field_22764 = true;
        }
        restyle();
    }

    private void pick(int idx) {
        int i = page * PER + idx;
        if (i < filtered.size()) selectedKey = filtered.get(i).key;
    }

    private Entry selected() {
        if (selectedKey == null) return null;
        for (Entry e : source()) if (e.key.equals(selectedKey)) return e;
        return null;
    }

    private void act(int n) {
        if (sell) {
            if (n == 1) {
                Entry e = selected();
                if (e != null) ClientPlayNetworking.send(new ActionPayload(3, "", e.slot));
            } else if (n == 2) {
                ClientPlayNetworking.send(new ActionPayload(4, "", 0));
            }
        } else {
            Entry e = selected();
            if (e == null) return;
            int count = n == 1 ? 1 : n == 2 ? 16 : 64;
            ClientPlayNetworking.send(new ActionPayload(1, e.key, count));
        }
    }

    private void txt(class_332 c, String s, int x, int y, int color) {
        c.method_51439(field_22793, class_2561.method_43470(s), x, y, color, true);
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        super.method_25420(ctx, mx, my, delta);
        Fx.panel(ctx, left, top, W, H, accent());
        ctx.method_25296(left + 148, top + 20, left + 149, top + H - 8, Fx.argb(0, accent()), Fx.argb(200, accent()));
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        int acc = accent();
        Fx.title(ctx, field_22793, sell ? "EMC TABLET - SELL" : "EMC TABLET - BUY", left + 8, top + 8, acc);

        if (lastBal != Long.MIN_VALUE && emc != lastBal) Fx.pop(emc - lastBal);
        lastBal = emc;
        String bal = "EMC " + Fx.num(counter.get(emc));
        int bxr = left + W - 8 - field_22793.method_1727(bal);
        Fx.orb(ctx, bxr - 9, top + 12, acc);
        Fx.glowText(ctx, field_22793, bal, bxr, top + 8, Fx.WHITE);
        Fx.drawPops(ctx, field_22793, left + W - 8, top + 18);

        float now = Fx.t();
        for (int i = 0; i < cells.size(); i++) {
            int idx = page * PER + i;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + 55 + (i / COLS) * 18 + 1;
            float appear = Fx.ease((now - pageT) * 4f - ((i % COLS) + (i / COLS)) * 0.08f);
            boolean isSel = e.key.equals(selectedKey);
            Fx.item(ctx, e.stack, x, y, cells.get(i).method_49606(), isSel, appear, CAT_RGB[e.cat]);
            if (sell && e.stack.method_7947() > 1 && appear > 0.9f) {
                String cnt = String.valueOf(e.stack.method_7947());
                txt(ctx, cnt, x + 17 - field_22793.method_1727(cnt), y + 9, WHITE);
            }
        }
        int pages = Math.max(1, (filtered.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 64, top + 153, GREY);

        int bx = left + 152, bw = 90;
        float frac = total <= 0 ? 0 : (float) buyAll.size() / total;
        Fx.bar(ctx, bx, top + 24, bw, 6, frac, acc);
        txt(ctx, "Discovered " + buyAll.size() + "/" + total, bx, top + 33, GREY);

        Entry sel = selected();
        if (sel == null) {
            txt(ctx, sell ? "Select a stack" : "Select an item", bx, top + 72, GREY);
        } else {
            Fx.showcase(ctx, sel.stack, bx + 14, top + 74, 1.6f, CAT_RGB[sel.cat]);
            txt(ctx, field_22793.method_27523(sel.name, 58), bx + 32, top + 62, WHITE);
            if (sell) {
                Fx.glowText(ctx, field_22793, Fx.num(sel.value) + " EMC", bx + 32, top + 76, Fx.GOLD);
                txt(ctx, "Stack x" + sel.stack.method_7947(), bx + 32, top + 90, GREY);
            } else {
                Fx.glowText(ctx, field_22793, Fx.num(sel.value) + " EMC", bx + 32, top + 76, Fx.CYAN);
                boolean can = emc >= sel.value;
                txt(ctx, can ? "Afford " + Fx.num(emc / sel.value) : "Not enough", bx + 32, top + 90, can ? 0xFF7FFFB0 : 0xFFFF7070);
            }
        }
        Fx.openFade(ctx, left, top, W, H, openT);
    }
}

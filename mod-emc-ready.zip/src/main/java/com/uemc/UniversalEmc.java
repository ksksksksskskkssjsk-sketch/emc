package com.uemc;

import com.uemc.emc.EmcData;
import com.uemc.emc.EmcRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UniversalEmc implements ModInitializer {
    public static final String ID = "uemc";
    public static final Logger LOG = LoggerFactory.getLogger(ID);

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModBlocks.init();
        ModItems.init();
        ModItemGroup.init();
        com.uemc.net.ServerNet.init();
        EmcCommands.init();
        com.uemc.emc.Services.init();
        com.uemc.emc.Workbench.init();
        com.uemc.emc.Upgrades.init();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            EmcRegistry.load(server);
            EmcData.load(server);
            LOG.info("EMC values loaded: {}", EmcRegistry.size());
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(EmcData::save);
    }
}

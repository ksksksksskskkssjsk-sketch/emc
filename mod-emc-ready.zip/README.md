# Universal EMC (Fabric, Minecraft 1.21.11)

## Build
Needs JDK 21 + Gradle 9.2.1 (or push to GitHub: Actions builds it, jar under Artifacts).

    gradle build

Jar: `build/libs/universal-emc-0.1.0.jar`

## Install
Fabric Loader >= 0.18.0 + Fabric API 0.141.1+1.21.11 in `mods/`, then drop the jar in.

## Items
- EMC Scanner, EMC Tablet (recipes in-game)
- Basic / Advanced / Ultimate Energy Converter (right-click with items)

## Notes
Sources use intermediary names; build.gradle maps them via `-PmapMode=intermediary` (default) or `layered`.
If one name fails to resolve at first build, fix that one line.

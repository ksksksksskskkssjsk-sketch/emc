# Universal EMC – workstation UI (source files)

Drop the `com/` folder over your mod's source tree (same package layout as your sources jar).
UNTESTED: written without Minecraft/Gradle available, using only intermediary names already present in your sources.
Expect to build once and fix any name that doesn't resolve.

## New files
- net/WorkbenchPayload.java      server -> client: which screen to open + recipe data
- emc/Workbench.java             server logic: recipe loading, craft, stonecutter, grindstone (all validated server-side)
- client/WorkbenchScreen.java    crafting table + stonecutter (search, "can craft" filter, recipe variants, Craft 1/10/max)
- client/DisenchantScreen.java   grindstone (strip enchants, curses stay, small XP)

- client/SellScreen.java         sell from inventory: inventory-shaped grid, multi-select, All/Half/One, live total, Select main/all/same item

## Changed files (small patches to your originals)
- UniversalEmc.java              calls Workbench.init()
- net/ServerNet.java             registers payload; actions 40 (craft) and 41 (disenchant); converter buttons open new screens
- emc/Services.java              tablet "open" for crafting / stonecutter / grindstone / enchant uses new screens
- emc/EmcLogic.java              + addXp(), + sellSlots() (action 42)
- client/TabletScreen.java       "Mode" button is now "Sell items..." and opens SellScreen
- emc/Fees.java                  enchant-table open fee 500 -> 0 (each enchant is paid per use)
- client/UniversalEmcClient.java receiver for WorkbenchPayload
- client/EnchantScreen.java      rewritten: one row per enchant, click name = next level, click a level chip (I-VII) = that level, price on the big button, conflicts greyed out
- client/ConverterMenuScreen.java regrouped layout (Workstations / EMC + XP)
- client/ServicesScreen.java     two-line cards (name + price), grouped Workstations / Services
- client/ServiceScreen.java      panel width W is now adjustable per screen

## Behaviour changes
- Crafting/stonecutter craft from your inventory (no EMC). Tablet still charges its open fee for them (10 EMC each).
- Converter "Enchanting" now opens the pick-your-enchant screen (costs EMC). Set
  Workbench.CONVERTER_CUSTOM_ENCHANT = false to get the vanilla random table back.
- Anvil and smithing are unchanged (vanilla screens).

## Round 2: icons + better selling
- client/Icons.java (new): draws vanilla item pictures as icons (cached by item id).
- client/SellScreen.java: item picture card for the hovered/last-clicked stack (name, EMC each, sells for),
  icons on every button, "cart" row of icons showing what will be sold, live total on the Sell button,
  "Balance after", "Inventory worth", and a Quick sell toggle (click a stack = sold instantly; enchanted stacks skipped).
- client/ServicesScreen.java: item icon on every upgrade card.
- client/ConverterMenuScreen.java: item icon on every button; panel widened to 284.

## Round 3: XP shop + easier selling
- client/XpShopScreen.java (new): Buy/Sell toggle, amount presets 1/5/10/30/Max, -5/-1/+1/+5, live "Level a -> b" and EMC cost/gain, one confirm button.
- Tablet and Converter: the 3 loose XP buttons are now one "XP Shop" button.
- Converter: new "Sell everything" one-click button (next to XP Shop).

## Round 4: enchant levels + upgrade system
- Enchant: every enchant can go to level 10 (single-level ones stay 1). Level chips are now 1-10. Price = 1000*L^2 + 2000 (pay the difference).
- emc/Upgrades.java (new): account-bound upgrades bought with EMC, saved in uemc_players.json.
  Tools (need pickaxe/axe/shovel in hand): Hammer 3x3 -> 5x5, Vein Miner (12/32/64), Lumberjack (32/96/200), Auto-Repair.
  Walk = hammer. Sneak = vein / tree mode.
  Perks (ON/OFF): Haste, Speed, Jump Boost, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger.
- client/UpgradesScreen.java (new): list with level, price, Unlock/Upgrade, ON/OFF. Opened from Tablet > Upgrades and Converter.
- net/UpgradesPayload.java (new), ServerNet actions 50 (buy), 51 (toggle), 52 (sync).
- Names NOT checked against mappings (fix first if the build complains): field_13974, method_14266, method_26214, method_26215,
  method_8321, method_36454, method_36455, method_5715, method_6092, class_1293 ctor, class_1294.field_*, class_1291, method_12832.

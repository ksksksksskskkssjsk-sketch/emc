#!/usr/bin/env bash
# Builds Universal EMC. Result: dist/universal-emc-<version>.jar  (put it in .minecraft/mods)
# Needs: JDK 21+ and internet (first run downloads Gradle, Fabric Loom and Minecraft mappings).
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "Java not found. Install JDK 21: https://adoptium.net/temurin/releases/?version=21"; exit 1
fi
JV=$(java -version 2>&1 | grep -m1 ' version ' | sed -E 's/.*version "([0-9]+)[^"]*".*/\1/')
if [ "${JV:-0}" -lt 21 ]; then
  echo "Need JDK 21 or newer, found Java ${JV:-unknown}. Install: https://adoptium.net/temurin/releases/?version=21"; exit 1
fi

chmod +x ./gradlew 2>/dev/null || true
echo "==> Building (mappings: layered)"
if ! ./gradlew build --stacktrace -PmapMode=layered; then
  echo "==> Failed. Retrying with intermediary mappings"
  ./gradlew clean build --stacktrace -PmapMode=intermediary
fi

mkdir -p dist
rm -f dist/*.jar
for f in build/libs/*.jar; do
  case "$f" in *-sources.jar) continue ;; esac
  cp "$f" dist/
done
echo
echo "DONE. Jar:"
ls -1 dist/*.jar
echo "Copy it into your Minecraft mods folder (Minecraft 1.21.11 + Fabric Loader 0.18+ + Fabric API 0.141+)."

package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client: level of every upgrade (same order as Upgrades.DEFS) and whether each perk is switched on (1) or off (0). */
public record UpgradesPayload(List<Integer> levels, List<Integer> on) implements class_8710 {
    public static final class_8710.class_9154<UpgradesPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "upgrades"));

    public static final class_9139<class_9129, UpgradesPayload> CODEC = new class_9139<>() {
        @Override
        public UpgradesPayload decode(class_9129 buf) {
            int n = buf.method_10816();
            List<Integer> lv = new ArrayList<>(n), on = new ArrayList<>(n);
            for (int i = 0; i < n; i++) { lv.add(buf.method_10816()); on.add(buf.method_10816()); }
            return new UpgradesPayload(lv, on);
        }

        @Override
        public void encode(class_9129 buf, UpgradesPayload p) {
            buf.method_10804(p.levels.size());
            for (int i = 0; i < p.levels.size(); i++) { buf.method_10804(p.levels.get(i)); buf.method_10804(p.on.get(i)); }
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

package com.uemc.client;

import com.uemc.emc.Upgrades;
import java.util.List;

/** What the server last told us about this player's upgrades. */
public final class ClientUpgrades {
    private ClientUpgrades() {}

    private static int[] levels = new int[Upgrades.DEFS.length];
    private static boolean[] on = new boolean[Upgrades.DEFS.length];

    public static void set(List<Integer> lv, List<Integer> o) {
        levels = new int[Upgrades.DEFS.length];
        on = new boolean[Upgrades.DEFS.length];
        for (int i = 0; i < Upgrades.DEFS.length && i < lv.size(); i++) { levels[i] = lv.get(i); on[i] = o.get(i) != 0; }
    }

    public static int level(int i) { return i >= 0 && i < levels.length ? levels[i] : 0; }
    public static boolean on(int i) { return i >= 0 && i < on.length && on[i]; }
    public static void clear() { levels = new int[Upgrades.DEFS.length]; on = new boolean[Upgrades.DEFS.length]; }
}

package com.uemc.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

/** Shared UI effects: glow, animated panels, particles, item showcase, counters, popups. */
public final class Fx {
    private Fx() {}

    public static final int CYAN = 0x00FFDD, GOLD = 0xFFC040, PURPLE = 0xB080FF, ORANGE = 0xFF8030,
            GREEN = 0x50FF90, RED = 0xFF5060, WHITE = 0xFFFFFF;

    public static float t() { return (System.currentTimeMillis() % 1_000_000L) / 1000f; }
    public static int argb(int a, int rgb) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    public static float clamp01(float x) { return x < 0 ? 0 : Math.min(x, 1); }
    public static float ease(float x) { x = clamp01(x); return 1 - (1 - x) * (1 - x) * (1 - x); }
    public static float sin(float x) { return (float) Math.sin(x); }

    public static int mix(int a, int b, float f) {
        f = clamp01(f);
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }

    static float hash(int i, int k) {
        int n = i * 374761393 + k * 668265263;
        n = (n ^ (n >>> 13)) * 1274126177;
        return ((n ^ (n >>> 16)) & 0xFFFF) / 65535f;
    }

    public static String num(long v) { return String.format("%,d", v); }

    // ---------- glow / outline ----------
    public static void glow(class_332 c, int x, int y, int w, int h, int rgb, float s, int layers) {
        for (int i = layers; i >= 1; i--) c.method_25294(x - i, y - i, x + w + i, y + h + i, argb((int) (s * 60 / (i + 0.5f)), rgb));
    }

    public static void ring(class_332 c, int x, int y, int w, int h, int argb) {
        c.method_25294(x, y, x + w, y + 1, argb);
        c.method_25294(x, y + h - 1, x + w, y + h, argb);
        c.method_25294(x, y + 1, x + 1, y + h - 1, argb);
        c.method_25294(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    // ---------- animated panel ----------
    public static void panel(class_332 c, int x, int y, int w, int h, int rgb) {
        float t = t();
        float pulse = 0.55f + 0.35f * sin(t * 2f);
        glow(c, x, y, w, h, rgb, pulse, 6);
        c.method_25294(x, y, x + w, y + h, 0xFF081016);
        c.method_25296(x + 1, y + 1, x + w - 1, y + h - 1, argb(255, mix(0x1F2F3D, rgb, 0.10f)), 0xFF0A131B);
        // scanlines
        for (int yy = y + 2; yy < y + h - 2; yy += 3) c.method_25294(x + 1, yy, x + w - 1, yy + 1, 0x14000000);
        // drifting particles
        for (int i = 0; i < 30; i++) {
            float sp = 6 + hash(i, 2) * 16;
            int px = x + 2 + (int) (hash(i, 1) * (w - 5));
            float cycle = (t * sp + hash(i, 3) * h) % (h - 4);
            int py = y + h - 3 - (int) cycle;
            float tw = 0.5f + 0.5f * sin(t * 3f + i);
            int col = argb((int) (30 + 110 * tw), i % 3 == 0 ? WHITE : rgb);
            c.method_25294(px, py, px + 1 + (i % 4 == 0 ? 1 : 0), py + 1 + (i % 4 == 0 ? 1 : 0), col);
        }
        // moving shine band
        float sx = (t * 45f) % (w + 80) - 40;
        int x0 = (int) Math.max(x + 1, x + sx), x1 = (int) Math.min(x + w - 1, x + sx + 26);
        if (x1 > x0) c.method_25294(x0, y + 1, x1, y + h - 1, 0x09FFFFFF);
        int m0 = (int) Math.max(x + 1, x + sx + 8), m1 = (int) Math.min(x + w - 1, x + sx + 16);
        if (m1 > m0) c.method_25294(m0, y + 1, m1, y + h - 1, 0x0CFFFFFF);
        // animated top/bottom edges
        for (int sxp = 0; sxp < w; sxp += 4) {
            float a = 0.5f + 0.5f * sin(t * 3f - sxp * 0.06f);
            int col = argb((int) (60 + 195 * a * a), rgb);
            c.method_25294(x + sxp, y, Math.min(x + w, x + sxp + 4), y + 1, col);
            c.method_25294(x + sxp, y + h - 1, Math.min(x + w, x + sxp + 4), y + h, argb((int) (40 + 120 * (1 - a)), rgb));
        }
        c.method_25294(x, y, x + 1, y + h, argb(110, rgb));
        c.method_25294(x + w - 1, y, x + w, y + h, argb(110, rgb));
        // glowing accent strip under the top edge
        c.method_25296(x + 1, y + 1, x + w - 1, y + 4, argb(70, rgb), argb(0, rgb));
        // corner brackets
        int cb = argb(255, mix(rgb, WHITE, 0.5f));
        for (int k = 0; k < 2; k++) {
            int xx = k == 0 ? x : x + w - 6, yy = k == 0 ? y : y + h - 1;
            c.method_25294(xx, y, xx + 6, y + 1, cb);
            c.method_25294(xx, y + h - 1, xx + 6, y + h, cb);
        }
        c.method_25294(x, y, x + 1, y + 6, cb);
        c.method_25294(x + w - 1, y, x + w, y + 6, cb);
        c.method_25294(x, y + h - 6, x + 1, y + h, cb);
        c.method_25294(x + w - 1, y + h - 6, x + w, y + h, cb);
    }

    /** Fade-in with a scanning line, run on top of everything for the first ~0.35s. */
    public static void openFade(class_332 c, int x, int y, int w, int h, float openT) {
        float p = (t() - openT) / 0.35f;
        if (p >= 1 || p < 0) return;
        float e = ease(p);
        c.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, argb((int) ((1 - e) * 255), 0x081016));
        int ly = y + (int) (e * h);
        c.method_25296(x, ly - 8, x + w, ly, argb(0, CYAN), argb(120, CYAN));
        c.method_25294(x, ly, x + w, ly + 1, argb(255, WHITE));
    }

    // ---------- text ----------
    public static void text(class_332 c, class_327 tr, String s, int x, int y, int argb) {
        c.method_51439(tr, class_2561.method_43470(s), x, y, argb, true);
    }

    public static void glowText(class_332 c, class_327 tr, String s, int x, int y, int rgb) {
        int g = argb(45, rgb);
        c.method_51439(tr, class_2561.method_43470(s), x - 1, y, g, false);
        c.method_51439(tr, class_2561.method_43470(s), x + 1, y, g, false);
        c.method_51439(tr, class_2561.method_43470(s), x, y - 1, g, false);
        c.method_51439(tr, class_2561.method_43470(s), x, y + 1, g, false);
        c.method_51439(tr, class_2561.method_43470(s), x, y, argb(255, rgb), true);
    }

    /** Title with a light wave running through the letters. */
    public static void title(class_332 c, class_327 tr, String s, int x, int y, int rgb) {
        float t = t();
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            float b = 0.5f + 0.5f * sin(t * 3.2f - i * 0.45f);
            c.method_51439(tr, class_2561.method_43470(ch), cx, y, argb(255, mix(rgb, WHITE, b * b * 0.9f)), true);
            cx += tr.method_1727(ch);
        }
    }

    // ---------- bar ----------
    public static void bar(class_332 c, int x, int y, int w, int h, float frac, int rgb) {
        float t = t();
        c.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF05090D);
        c.method_25294(x, y, x + w, y + h, 0xFF101820);
        int fw = (int) (w * clamp01(frac));
        if (fw <= 0) return;
        c.method_25296(x, y, x + fw, y + h, argb(255, mix(rgb, WHITE, 0.4f)), argb(255, rgb));
        float sx = (t * 40f) % (fw + 24) - 12;
        int a = (int) Math.max(x, x + sx), b = (int) Math.min(x + fw, x + sx + 8);
        if (b > a) c.method_25294(a, y, b, y + h, 0x70FFFFFF);
        glow(c, x + fw - 1, y, 1, h, rgb, 0.5f, 2);
    }

    // ---------- items ----------
    /** Draws a stack scaled (about its centre) with an optional bob. */
    public static void itemScaled(class_332 c, class_1799 st, float cx, float cy, float scale) {
        if (scale <= 0.02f) return;
        var m = c.method_51448();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        m.translate(-8, -8);
        c.method_51427(st, 0, 0);
        m.popMatrix();
    }

    /** Grid item: pop-in, hover zoom, selected glow + bob + orbiting sparkles. */
    public static void item(class_332 c, class_1799 st, int x, int y, boolean hover, boolean sel, float appear, int rgb) {
        if (appear <= 0.02f) return;
        float t = t();
        float s = appear;
        float bob = 0;
        if (sel) { s *= 1.15f + 0.05f * sin(t * 4f); bob = sin(t * 3f) * 1.4f; }
        else if (hover) s *= 1.22f;
        if (sel || hover) glow(c, x, y, 16, 16, rgb, sel ? 0.9f : 0.55f, 3);
        if (sel) {
            ring(c, x - 1, y - 1, 18, 18, argb((int) (110 + 110 * (0.5f + 0.5f * sin(t * 5f))), rgb));
            for (int i = 0; i < 3; i++) {
                float a = t * 2.4f + i * 2.094f;
                int sx = x + 8 + (int) (Math.cos(a) * 11), sy = y + 8 + (int) (Math.sin(a) * 11);
                c.method_25294(sx, sy, sx + 2, sy + 2, argb(230, i == 0 ? WHITE : rgb));
            }
        }
        itemScaled(c, st, x + 8, y + 8 + bob, s);
    }

    /** Big showcase item with halo and orbiting sparks. */
    public static void showcase(class_332 c, class_1799 st, int cx, int cy, float scale, int rgb) {
        float t = t();
        int r = (int) (8 * scale);
        for (int i = 5; i >= 1; i--) {
            int rr = r + i * 2 + (int) (sin(t * 2f) * 1.5f);
            c.method_25294(cx - rr, cy - rr, cx + rr, cy + rr, argb((int) (14 + 10 * (6 - i)) / 2, rgb));
        }
        for (int i = 0; i < 5; i++) {
            float a = t * 1.8f + i * 1.2566f;
            int sx = cx + (int) (Math.cos(a) * (r + 6)), sy = cy + (int) (Math.sin(a) * (r + 6));
            c.method_25294(sx, sy, sx + 2, sy + 2, argb(220, i % 2 == 0 ? WHITE : rgb));
        }
        itemScaled(c, st, cx, cy + sin(t * 3f) * 1.5f, scale);
    }

    /** Fire strip along the bottom edge of a panel. */
    public static void flames(class_332 c, int x, int y, int w, float intensity) {
        float t = t();
        for (int cx = 0; cx < w; cx += 3) {
            float n = 0.5f * sin(t * 8f + cx * 0.55f) + 0.5f * sin(t * 5.3f + cx * 0.29f);
            int hh = (int) (4 + 20 * intensity * (0.65f + 0.35f * n));
            c.method_25296(x + cx, y - hh, x + cx + 3, y, argb(0, ORANGE), argb((int) (150 + 80 * intensity), 0xFFD060));
        }
    }

    // ---------- counter + popups ----------
    public static final class Counter {
        private double v = -1;
        public long get(long target) {
            if (v < 0) v = target;
            v += (target - v) * 0.18;
            if (Math.abs(target - v) < 1) v = target;
            return Math.round(v);
        }
    }

    private record Pop(long delta, float start) {}
    private static final List<Pop> POPS = new ArrayList<>();

    public static void pop(long delta) {
        if (delta != 0) POPS.add(new Pop(delta, t()));
        if (POPS.size() > 8) POPS.remove(0);
    }

    public static void drawPops(class_332 c, class_327 tr, int rightX, int y) {
        float now = t();
        POPS.removeIf(p -> now - p.start > 1.5f || now < p.start);
        for (Pop p : POPS) {
            float age = now - p.start;
            String s = (p.delta > 0 ? "+" : "-") + num(Math.abs(p.delta));
            int col = argb((int) (255 * (1 - age / 1.5f)), p.delta > 0 ? GREEN : RED);
            c.method_51439(tr, class_2561.method_43470(s), rightX - tr.method_1727(s), y + (int) (age * 16), col, true);
        }
    }

    /** Animated energy orb next to the balance. */
    public static void orb(class_332 c, int x, int y, int rgb) {
        float t = t();
        int s = 4 + (int) (1.2f * sin(t * 4f));
        glow(c, x - s, y - s, s * 2, s * 2, rgb, 0.8f, 3);
        c.method_25294(x - s, y - s, x + s, y + s, argb(255, mix(rgb, WHITE, 0.3f)));
        c.method_25294(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
    }
}

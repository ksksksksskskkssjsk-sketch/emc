package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_6880;
import net.minecraft.class_7919;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import java.util.ArrayList;
import java.util.List;

/**
 * Enchanting Table: hold an item, then
 *   1. pick an enchant on the left (type in the search box to find it fast),
 *   2. pick its level on the right: one click on 1..10 (X is the cap for every enchant),
 *   3. press Enchant. The price is always visible; you only pay the difference to what the item already has.
 * Enchants that clash with something already on the item are greyed out and say why.
 * The server re-checks everything (item, level cap, conflicts, EMC).
 */
public class EnchantScreen extends ServiceScreen {
    private record Row(class_6880<class_1887> e, String id, String name, int max, String conflict) {}

    private static final int PER = 8, ROW_H = 20, LIST_Y = 42, LIST_W = 138, CHIPS = 10;
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private final Runnable back;
    private final List<Row> all = new ArrayList<>();
    private final List<Row> shown = new ArrayList<>();
    private final GlowButton[] slots = new GlowButton[PER];
    private final GlowButton[] chips = new GlowButton[CHIPS];
    private class_342 search;
    private GlowButton apply, prev, next;
    private String query = "";
    private class_1799 last = class_1799.field_8037;
    private long lastBal = Long.MIN_VALUE;
    private int page = 0, lvl = 0;
    private Row sel;
    private boolean synced = false;

    public EnchantScreen(Runnable back) {
        super("ENCHANTING TABLE");
        this.back = back;
        W = 312;
        H = 228;
        accent = Fx.PURPLE;
    }

    private static String roman(int k) { return k >= 0 && k < ROMAN.length ? ROMAN[k] : String.valueOf(k); }

    private int rx() { return left + 158; }

    private class_1799 held() {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
    }

    private int have(Row r) {
        class_1799 st = held();
        return st.method_7960() ? 0 : class_1890.method_8225(r.e, st);
    }

    private long price(int level) { return sel == null ? 0 : Math.max(0, Fees.enchant(level) - Fees.enchant(have(sel))); }

    // ---------- data ----------
    /** Everything that can go on the held item (sorted: usable first, then A-Z). */
    private void rebuildRows() {
        all.clear();
        class_310 mc = class_310.method_1551();
        class_1799 st = held();
        last = st.method_7972();
        if (mc.field_1724 != null && mc.field_1687 != null && !st.method_7960()) {
            var reg = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
            class_9304 cur = class_1890.method_57532(st);
            reg.method_42017().forEach(ref -> {
                class_1887 en = ref.comp_349();
                if (!en.method_8192(st)) return;
                String conflict = null;
                for (class_6880<class_1887> o : cur.method_57534()) {
                    if (!o.equals(ref) && !class_1887.method_60033(ref, o)) { conflict = o.comp_349().comp_2686().getString(); break; }
                }
                all.add(new Row(ref, ref.method_40237().method_29177().toString(), en.comp_2686().getString(),
                        Fees.maxLevel(en.method_8183()), conflict));
            });
            all.sort((a, b) -> {
                int ca = a.conflict == null ? 0 : 1, cb = b.conflict == null ? 0 : 1;
                return ca != cb ? ca - cb : a.name.compareToIgnoreCase(b.name);
            });
        }
        if (sel != null) {
            Row keep = null;
            for (Row r : all) if (r.id.equals(sel.id)) keep = r;
            sel = keep;
        }
        refilter();
    }

    private void refilter() {
        shown.clear();
        String q = query.trim().toLowerCase();
        for (Row r : all) if (q.isEmpty() || r.name.toLowerCase().contains(q) || r.id.contains(q)) shown.add(r);
        page = Math.max(0, Math.min(page, (Math.max(1, shown.size()) - 1) / PER));
        if (sel != null) lvl = Math.max(1, Math.min(sel.max, lvl));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); } // sync EMC balance

        search = new class_342(field_22793, left + 8, top + 24, LIST_W, 14, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; page = 0; refilter(); refresh(); });
        method_37063(search);

        for (int i = 0; i < PER; i++) {
            final int idx = i;
            slots[i] = GlowButton.of("", left + 8, top + LIST_Y + i * ROW_H, LIST_W, 18, b -> pickRow(idx));
            method_37063(slots[i]);
        }

        prev = GlowButton.of("<", left + 8, top + 204, 20, 16, b -> { if (page > 0) { page--; refresh(); } });
        next = GlowButton.of(">", left + 30, top + 204, 20, 16, b -> { if ((page + 1) * PER < shown.size()) { page++; refresh(); } });
        method_37063(prev);
        method_37063(next);

        for (int k = 0; k < CHIPS; k++) {
            final int level = k + 1;
            chips[k] = GlowButton.of(String.valueOf(level), rx() + (k % 5) * 29, top + 82 + (k / 5) * 22, 27, 20, b -> { lvl = level; refresh(); });
            method_37063(chips[k]);
        }

        apply = GlowButton.of("", rx(), top + 160, 146, 26, b -> {
            if (sel != null) ClientPlayNetworking.send(new ActionPayload(7, sel.id, lvl));
        });
        apply.accent = Fx.PURPLE;
        method_37063(apply);

        GlowButton close = GlowButton.of("Back", rx(), top + 204, 146, 16, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);

        rebuildRows();
        refresh();
    }

    private void pickRow(int slot) {
        int idx = page * PER + slot;
        if (idx >= shown.size()) return;
        sel = shown.get(idx);
        lvl = sel.max;               // jump straight to the top level (X); click a lower chip if you want less
        refresh();
    }

    private static void tip(GlowButton b, String s) {
        b.method_47400(s == null ? null : class_7919.method_47407(class_2561.method_43470(s)));
    }

    /** Re-style every widget from the current state (cheap: 8 rows + 10 chips + 1 button). */
    private void refresh() {
        if (apply == null) return;
        lastBal = ClientEmc.balance;

        for (int i = 0; i < PER; i++) {
            GlowButton b = slots[i];
            int idx = page * PER + i;
            if (idx >= shown.size()) { b.field_22764 = false; continue; }
            Row r = shown.get(idx);
            int h = have(r);
            b.field_22764 = true;
            b.method_25355(class_2561.method_43470(field_22793.method_27523(r.name, 104) + (h > 0 ? "  " + roman(h) : "")));
            boolean blocked = r.conflict != null, maxed = h >= r.max;
            b.field_22763 = !blocked && !maxed;
            b.selected = sel != null && sel.id.equals(r.id);
            b.accent = maxed ? Fx.GREEN : h > 0 ? Fx.CYAN : Fx.PURPLE;
            tip(b, blocked ? "Conflicts with " + r.conflict : maxed ? "Already at max level" : null);
        }

        for (int k = 0; k < CHIPS; k++) {
            GlowButton c = chips[k];
            int level = k + 1;
            if (sel == null || level > sel.max) { c.field_22764 = false; continue; }
            c.field_22764 = true;
            int h = have(sel);
            boolean owned = level <= h;
            long p = price(level);
            c.field_22763 = !owned;
            c.selected = level == lvl;
            c.accent = owned ? Fx.GREEN : p <= ClientEmc.balance ? Fx.PURPLE : Fx.RED;
            tip(c, owned ? "Already on the item" : sel.name + " " + roman(level) + "\n" + Fx.num(p) + " EMC");
        }

        int pages = Math.max(1, (shown.size() + PER - 1) / PER);
        prev.field_22763 = page > 0;
        next.field_22763 = page + 1 < pages;

        if (sel == null) { apply.method_25355(class_2561.method_43470("Pick an enchant")); apply.field_22763 = false; return; }
        if (have(sel) >= lvl) { apply.method_25355(class_2561.method_43470("Already has it")); apply.field_22763 = false; return; }
        long c = price(lvl);
        if (c > ClientEmc.balance) { apply.method_25355(class_2561.method_43470("Need " + Fx.num(c) + " EMC")); apply.field_22763 = false; return; }
        apply.method_25355(class_2561.method_43470("Enchant  " + Fx.num(c) + " EMC"));
        apply.field_22763 = true;
    }

    @Override
    public void method_25393() {
        boolean itemChanged = !class_1799.method_7973(last, held());
        if (itemChanged) rebuildRows();
        if (itemChanged || ClientEmc.balance != lastBal) refresh();
    }

    // ---------- drawing ----------
    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        int x0 = rx();
        ctx.method_25294(left + 150, top + 24, left + 151, top + H - 8, Fx.argb(110, Fx.PURPLE));

        class_1799 st = held();
        if (st.method_7960()) {
            txt(ctx, "Hold the item you", x0, top + 34, WHITE);
            txt(ctx, "want to enchant", x0, top + 46, WHITE);
            txt(ctx, "Max level is X (10)", x0, top + 70, GREY);
            return;
        }
        Fx.showcase(ctx, st, x0 + 12, top + 38, 1.0f, Fx.PURPLE);
        txt(ctx, field_22793.method_27523(st.method_7964().getString(), 116), x0 + 30, top + 26, WHITE);
        txt(ctx, "Max level: X (10)", x0 + 30, top + 38, GREY);

        if (all.isEmpty()) txt(ctx, "No enchants fit this item", left + 10, top + 60, GREY);
        else if (shown.isEmpty()) txt(ctx, "No match", left + 10, top + 60, GREY);

        if (sel == null) {
            txt(ctx, "1. Pick an enchant", x0, top + 90, GREY);
            txt(ctx, "2. Pick a level", x0, top + 102, GREY);
            txt(ctx, "3. Press Enchant", x0, top + 114, GREY);
        } else {
            txt(ctx, field_22793.method_27523(sel.name + " " + roman(lvl), 146), x0, top + 56, CYAN);
            int h = have(sel);
            txt(ctx, "On item: " + (h > 0 ? roman(h) : "-") + "    Max: " + roman(sel.max), x0, top + 67, GREY);
            if (h < lvl) {
                long c = price(lvl);
                boolean ok = c <= ClientEmc.balance;
                txt(ctx, "Price: " + Fx.num(c) + " EMC", x0, top + 130, ok ? 0xFFE0B040 : 0xFFFF7070);
                txt(ctx, "After: " + Fx.num(ClientEmc.balance - c) + " EMC", x0, top + 142, ok ? GREY : 0xFFFF7070);
            }
        }
        int pages = Math.max(1, (shown.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 56, top + 208, GREY);
    }
}

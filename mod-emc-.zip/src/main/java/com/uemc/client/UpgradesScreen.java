package com.uemc.client;

import com.uemc.emc.Upgrades;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/** Tool + perk upgrades: one row each with level, price, Buy and (perks) On/Off. Server charges and applies everything. */
public class UpgradesScreen extends ServiceScreen {
    private static final int PER = 5, ROW = 30, TOP = 28;

    private final Runnable onBack;
    private int page = 0;
    private boolean synced = false;
    private long lastBal = Long.MIN_VALUE;

    public UpgradesScreen(Runnable onBack) {
        super("TOOL & PERK UPGRADES");
        this.onBack = onBack;
        W = 300;
        H = 214;
        accent = Fx.PURPLE;
    }

    /** Called when the server sends new upgrade levels. */
    public void refresh() { method_41843(); }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(52, "", 0)); }
        lastBal = ClientEmc.balance;
        int total = Upgrades.DEFS.length;
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= total) break;
            final Upgrades.Def u = Upgrades.DEFS[idx];
            int lv = ClientUpgrades.level(idx);
            int y = top + TOP + i * ROW + 4;
            int max = u.cost().length;

            if (u.perk()) {
                boolean on = ClientUpgrades.on(idx);
                GlowButton t = GlowButton.of(on ? "ON" : "OFF", left + 160, y, 34, 20, b -> ClientPlayNetworking.send(new ActionPayload(51, u.id(), 0)));
                t.accent = on ? Fx.GREEN : Fx.RED;
                t.field_22763 = lv > 0;
                t.method_47400(class_7919.method_47407(class_2561.method_43470("Switch " + u.name() + " on or off")));
                method_37063(t);
            }

            if (lv >= max) {
                GlowButton m = GlowButton.of("MAX", left + 198, y, 94, 20, b -> {});
                m.accent = Fx.GREEN;
                m.field_22763 = false;
                method_37063(m);
            } else {
                long fee = u.cost()[lv];
                boolean ok = fee <= ClientEmc.balance;
                GlowButton buy = GlowButton.of((lv == 0 ? "Unlock " : "Upgrade ") + Fx.num(fee), left + 198, y, 94, 20,
                        b -> ClientPlayNetworking.send(new ActionPayload(50, u.id(), 0)));
                buy.accent = ok ? Fx.GOLD : Fx.RED;
                buy.field_22763 = ok;
                buy.method_47400(class_7919.method_47407(class_2561.method_43470(u.name() + " level " + (lv + 1) + "\n" + Fx.num(fee) + " EMC")));
                method_37063(buy);
            }
        }
        int by = top + 186;
        method_37063(GlowButton.of("<", left + 8, by, 20, 18, b -> { if (page > 0) { page--; method_41843(); } }));
        method_37063(GlowButton.of(">", left + 32, by, 20, 18, b -> { if ((page + 1) * PER < total) { page++; method_41843(); } }));
        GlowButton back = GlowButton.of("Back", left + 236, by, 56, 18, b -> onBack.run());
        back.accent = Fx.GOLD;
        method_37063(back);
    }

    @Override
    public void method_25393() {
        if (ClientEmc.balance != lastBal) method_41843();
    }

    private void small(class_332 c, String s, int x, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.7f, 0.7f);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (x / 0.7f), (int) (y / 0.7f), color, false);
        m.popMatrix();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        int total = Upgrades.DEFS.length;
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= total) break;
            Upgrades.Def u = Upgrades.DEFS[idx];
            int lv = ClientUpgrades.level(idx), max = u.cost().length;
            int y = top + TOP + i * ROW;
            ctx.method_25294(left + 6, y + 1, left + W - 6, y + ROW - 1, Fx.argb(70, lv > 0 ? 0x1A3A2A : 0x14202C));
            Icons.draw(ctx, u.icon(), left + 18, y + ROW / 2f, 0.9f);
            txt(ctx, u.name(), left + 32, y + 5, WHITE);
            String lvTxt = "Lv " + lv + "/" + max;
            txt(ctx, lvTxt, left + 32 + field_22793.method_1727(u.name()) + 6, y + 5, lv > 0 ? 0xFF9FE8A0 : 0xFF7A8A99);
            small(ctx, field_22793.method_27523(u.desc(), 190), left + 32, y + 17, GREY);
        }
        int pages = Math.max(1, (total + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 58, top + 191, GREY);
        small(ctx, "Sneak = vein / tree mode. Walk = hammer mode.", left + 84, top + 192, 0xFF7A8A99);
    }
}

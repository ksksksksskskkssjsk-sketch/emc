@echo off
rem Builds Universal EMC on Windows. Result: dist\universal-emc-<version>.jar
rem Needs JDK 21+ (https://adoptium.net/temurin/releases/?version=21) and internet.
cd /d "%~dp0"
call gradlew.bat build --stacktrace -PmapMode=layered
if errorlevel 1 (
  echo Retrying with intermediary mappings...
  call gradlew.bat clean build --stacktrace -PmapMode=intermediary
  if errorlevel 1 exit /b 1
)
if not exist dist mkdir dist
del /q dist\*.jar 2>nul
for %%f in (build\libs\*.jar) do (
  echo %%f | findstr /i "sources" >nul || copy /y "%%f" dist\ >nul
)
echo.
echo DONE. Jar is in the dist folder. Copy it into your Minecraft mods folder.

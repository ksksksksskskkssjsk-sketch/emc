# Universal EMC – workstation UI (source files)

Drop the `com/` folder over your mod's source tree (same package layout as your sources jar).
UNTESTED: written without Minecraft/Gradle available, using only intermediary names already present in your sources.
Expect to build once and fix any name that doesn't resolve.

## New files
- net/WorkbenchPayload.java      server -> client: which screen to open + recipe data
- emc/Workbench.java             server logic: recipe loading, craft, stonecutter, grindstone (all validated server-side)
- client/WorkbenchScreen.java    crafting table + stonecutter (search, "can craft" filter, recipe variants, Craft 1/10/max)
- client/DisenchantScreen.java   grindstone (strip enchants, curses stay, small XP)

- client/SellScreen.java         sell from inventory: inventory-shaped grid, multi-select, All/Half/One, live total, Select main/all/same item

## Changed files (small patches to your originals)
- UniversalEmc.java              calls Workbench.init()
- net/ServerNet.java             registers payload; actions 40 (craft) and 41 (disenchant); converter buttons open new screens
- emc/Services.java              tablet "open" for crafting / stonecutter / grindstone / enchant uses new screens
- emc/EmcLogic.java              + addXp(), + sellSlots() (action 42)
- client/TabletScreen.java       "Mode" button is now "Sell items..." and opens SellScreen
- emc/Fees.java                  enchant-table open fee 500 -> 0 (each enchant is paid per use)
- client/UniversalEmcClient.java receiver for WorkbenchPayload
- client/EnchantScreen.java      rewritten: one row per enchant, click name = next level, click a level chip (I-VII) = that level, price on the big button, conflicts greyed out
- client/ConverterMenuScreen.java regrouped layout (Workstations / EMC + XP)
- client/ServicesScreen.java     two-line cards (name + price), grouped Workstations / Services
- client/ServiceScreen.java      panel width W is now adjustable per screen

## Behaviour changes
- Crafting/stonecutter craft from your inventory (no EMC). Tablet still charges its open fee for them (10 EMC each).
- Converter "Enchanting" now opens the pick-your-enchant screen (costs EMC). Set
  Workbench.CONVERTER_CUSTOM_ENCHANT = false to get the vanilla random table back.
- Anvil and smithing are unchanged (vanilla screens).

## Round 2: icons + better selling
- client/Icons.java (new): draws vanilla item pictures as icons (cached by item id).
- client/SellScreen.java: item picture card for the hovered/last-clicked stack (name, EMC each, sells for),
  icons on every button, "cart" row of icons showing what will be sold, live total on the Sell button,
  "Balance after", "Inventory worth", and a Quick sell toggle (click a stack = sold instantly; enchanted stacks skipped).
- client/ServicesScreen.java: item icon on every upgrade card.
- client/ConverterMenuScreen.java: item icon on every button; panel widened to 284.

## Round 3: XP shop + easier selling
- client/XpShopScreen.java (new): Buy/Sell toggle, amount presets 1/5/10/30/Max, -5/-1/+1/+5, live "Level a -> b" and EMC cost/gain, one confirm button.
- Tablet and Converter: the 3 loose XP buttons are now one "XP Shop" button.
- Converter: new "Sell everything" one-click button (next to XP Shop).

## Round 4: enchant levels + upgrade system
- Enchant: every enchant can go to level 10 (single-level ones stay 1). Level chips are now 1-10. Price = 1000*L^2 + 2000 (pay the difference).
- emc/Upgrades.java (new): account-bound upgrades bought with EMC, saved in uemc_players.json.
  Tools (need pickaxe/axe/shovel in hand): Hammer 3x3 -> 5x5, Vein Miner (12/32/64), Lumberjack (32/96/200), Auto-Repair.
  Walk = hammer. Sneak = vein / tree mode.
  Perks (ON/OFF): Haste, Speed, Jump Boost, Night Vision, Water Breathing, Fire Resistance, Regeneration, Resistance, No Hunger.
- client/UpgradesScreen.java (new): list with level, price, Unlock/Upgrade, ON/OFF. Opened from Tablet > Upgrades and Converter.
- net/UpgradesPayload.java (new), ServerNet actions 50 (buy), 51 (toggle), 52 (sync).
- Names NOT checked against mappings (fix first if the build complains): field_13974, method_14266, method_26214, method_26215,
  method_8321, method_36454, method_36455, method_5715, method_6092, class_1293 ctor, class_1294.field_*, class_1291, method_12832.

## Round 5: EMC HUD
- client/EmcHud.java (new): always-on balance box in the world (animated number, +/- popups, EMC value of the item in hand).
  Hidden with F1 and while a UEMC screen is open. Default: top-left.
  Client commands: /emchud (toggle), /emchud on|off, /emchud topleft|topright|bottomleft|bottomright.
  Saved in config/uemc_hud.properties.
- emc/HudSync.java (new): server sends your balance every 5 ticks when it changed (and once after joining).
- net/BalancePayload.java (new): the packet for that.
- UniversalEmc.java calls HudSync.init(); client/UniversalEmcClient.java calls EmcHud.init(), receives BalancePayload, resets on disconnect.
- Uses Fabric API HudElementRegistry (needs Fabric API 0.116+; build uses 0.141.x).
- UNTESTED like the rest: all Minecraft names were checked against the real 1.21.11 mappings, but nothing was compiled.

## Round 6: workstations removed, new Enchanting Table
REMOVED: crafting table, stonecutter, grindstone, anvil, smithing table and ender chest screens (tablet + converter), their
server logic, packets and EMC open fees.
- Deleted: emc/Workbench.java, net/WorkbenchPayload.java, client/WorkbenchScreen.java, client/DisenchantScreen.java, menu/Handlers.java
- Cleaned: ServerNet (actions 20-26, 40, 41 and converter buttons gone), Services (open() gone), Fees (OPEN/OPEN_NAMES gone),
  UniversalEmc, UniversalEmcClient, ServicesScreen, ConverterMenuScreen, TabletScreen text.

NEW client/EnchantScreen.java (Enchanting Table), opened from Tablet > Upgrades > Enchanting and from the Converter menu:
- Search box + 8 big rows per page (name + level already on the item). Conflicts greyed out with the reason.
- Click an enchant -> level jumps to X (10). One click on a level chip 1-10 to pick another level.
- Price, "After" balance and the Enchant button are always visible. You only pay the difference to what the item has.
- Every enchant is capped at X (Fees.MAX_ENCHANT_LEVEL = 10); single-level enchants (Mending, Silk Touch...) stay at 1.
  Unbreaking X = 102,000 EMC (1000*L^2 + 2000).
- Server action 7 (Services.enchant) is unchanged and still validates item, level cap, conflicts and EMC.
- Same UNTESTED caveat: only intermediary names already used in your sources were used (class_342 search box copied from TabletScreen).

## Round 7: easier tablet, tablet can't be sold, buy anything with a price
- The EMC Tablet can never be sold or converted (EmcLogic.valueOf returns 0 for it, EmcRegistry removes its price,
  so "Sell all", "Sell offhand" and the sell screen all skip it; its tooltip says "EMC: none").
- Buying no longer needs scanner discovery: every item that has an EMC price is in the Buy list and can be bought
  (EmcLogic.buy lost the "Not discovered yet" check). Items with no price still can't be bought; set one in config/uemc_values.json.
  The list is built on the client from the price list already synced on join (ClientEmc.all()).
- client/TabletScreen.java rewritten as a simple hub:
  big top buttons Buy / Sell / XP Shop / Services; readable category tabs (All, Blocks, Gear, Food, Mats); search;
  click an item, then Buy 1 / 16 / 64 / Max (Max = everything you can afford, shown as "Max x37").
  Buttons you can't afford are greyed out and say what they cost. "Sell offhand item" stays at the bottom right.
- client/TeleportScreen.java: bigger page arrows and buttons; deleting a checkpoint now needs a second press ("Del" -> "Sure?").

## Round 8: 7 new perks (emc/Upgrades.java only)
Appended to Upgrades.DEFS (same ON/OFF perk rows, new pages in Tablet > Upgrades and the Converter menu). Order = network order, so only ever append.
- Magnet (3 lv, 6k / 20k / 60k): pulls dropped items to you, radius 4 / 8 / 16. Skips items still on pickup delay. Sneak = paused.
- Strength (2 lv, 8k / 30k): Strength I / II.
- Slow Fall (4k): Slow Falling (no fall damage).
- Dolphin's Grace (3k).
- Luck (3 lv, 10k / 30k / 80k): Luck I-III (loot, fishing).
- Health Boost (3 lv, 10k / 30k / 80k): +2 hearts per level.
- Flight (150k): survival/adventure flying. Creative/spectator untouched. Switching it OFF (or leaving) takes flight back and gives slow fall for a few seconds.
- New effects are looked up by registry id (strength, slow_falling, dolphins_grace, luck, health_boost), so no unverified field numbers.
- Names checked against Yarn 1.21.11: field_41174 (Registries.STATUS_EFFECT), method_10223 (Registry.getEntry(Identifier)), method_8390, method_6977, method_6983,
  method_5814, method_5649, method_5805, method_7325, method_51469, method_31549, method_7355, field_7478, field_7479, method_14267, class_1542, class_238.
- Still UNTESTED in-game (no Minecraft jar available to compile against). Existing saves are fine: new perks start at level 0.

## Ready-to-use pack (0.2.0)
- Version 0.2.0. Gradle wrapper added (gradlew, gradlew.bat, gradle/wrapper/*, Gradle 9.2.1).
- build.sh / build.bat: check JDK 21, build (retries with intermediary mappings), copy jar to dist/.
- github.sh: init + commit + push (creates the repo with `gh` if logged in). The existing .github/workflows/build.yml then builds and publishes a release.

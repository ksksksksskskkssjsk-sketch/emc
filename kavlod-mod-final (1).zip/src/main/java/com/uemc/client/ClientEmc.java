package com.uemc.client;

import com.uemc.emc.Fees;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Client copy of all EMC values (synced from server on join). */
public final class ClientEmc {
    private static volatile Map<class_2960, Long> VALUES = new HashMap<>();

    public static volatile long balance = 0;
    /** Auto-Repair (Repair screen) switched on for this player. */
    public static volatile boolean autoFix = false;

    private ClientEmc() {}

    public static void set(Map<class_2960, Long> m) { VALUES = m; }
    public static void clear() { VALUES = new HashMap<>(); balance = 0; autoFix = false; ClientTp.home = null; ClientTp.checkpoints = new java.util.ArrayList<>(); }

    /** Every item that has an EMC price (what the phone's Buy list shows). */
    public static Map<class_2960, Long> all() { return VALUES; }

    /** Price to BUY one of this item (0 = not for sale). */
    public static long buyPrice(class_1799 s) {
        if (s.method_7960()) return 0;
        return Fees.buyUnit(VALUES.getOrDefault(class_7923.field_41178.method_10221(s.method_7909()), 0L));
    }

    /** SELL value of ONE item (damaged tools scale by durability, same as server). */
    public static long unit(class_1799 s) {
        if (s.method_7960()) return 0;
        if (Fees.unsellable(class_7923.field_41178.method_10221(s.method_7909()))) return 0;
        long base = Fees.sellUnit(VALUES.getOrDefault(class_7923.field_41178.method_10221(s.method_7909()), 0L));
        if (base <= 0) return 0;
        if (s.method_7963() && s.method_7936() > 0) {
            long left = Math.max(0, s.method_7936() - s.method_7919());
            base = base * left / s.method_7936();
        }
        return base;
    }
}

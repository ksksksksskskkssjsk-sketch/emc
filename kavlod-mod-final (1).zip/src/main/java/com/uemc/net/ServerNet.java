package com.uemc.net;

import com.uemc.ModItems;
import com.uemc.emc.*;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import java.util.*;

public final class ServerNet {
    private ServerNet() {}

    public static void init() {
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ValuesPayload.ID, ValuesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TeleportListPayload.ID, TeleportListPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(UpgradesPayload.ID, UpgradesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TimeStatePayload.ID, TimeStatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(AutoSellPayload.ID, AutoSellPayload.CODEC);
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendValues(handler.field_14140));
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, ctx) -> {
            class_3222 p = ctx.player();
            if (!hasAccess(p)) return;
            switch (payload.action()) {
                case 1 -> {
                    class_2960 id = class_2960.method_12829(payload.item());
                    if (id == null || !class_7923.field_41178.method_10250(id)) return;
                    String err = EmcLogic.buy(p, class_7923.field_41178.method_63535(id), payload.count());
                    if (err != null) p.method_7353(class_2561.method_43470(err), true);
                    else p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 2 -> {
                    long g = EmcLogic.convert(p, p.method_6079());
                    p.method_7353(class_2561.method_43470(g > 0 ? "+" + g + " EMC" : "Offhand item has no EMC value"), true);
                }
                case 3 -> {
                    long g = EmcLogic.sellSlot(p, payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold +" + g + " EMC" : "Can't sell that"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 4 -> {
                    long g = EmcLogic.sellAll(p);
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold everything: +" + g + " EMC" : "Nothing to sell"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 5 -> {
                    long g = EmcLogic.sellXp(p, payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold XP: +" + g + " EMC" : "No XP to sell"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 6 -> {
                    String err = EmcLogic.buyXp(p, payload.count());
                    if (err != null) p.method_7353(class_2561.method_43470(err), true);
                    else p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 7 -> Services.enchant(p, payload.item(), payload.count());
                case 10 -> Services.repair(p);
                case 11 -> {}
                case 12 -> Services.enchantSlot(p, payload.item(), payload.count());
                case 13 -> Services.enchantAll(p, payload.count());
                case 14 -> Services.lowerSlot(p, payload.item(), payload.count());
                case 15 -> Services.timeSkip(p, payload.item(), payload.count());
                case 16 -> Services.timeSpeed(p, payload.count());
                case 17 -> Services.weather(p, payload.count());
                case 18 -> Services.sendTimeState(p);
                case 19 -> Services.repairSlot(p, payload.count());
                case 20 -> Services.repairAll(p);
                case 21 -> Services.toggleAutoFix(p);
                case 42 -> {
                    long g = EmcLogic.sellSlots(p, payload.item(), payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold +" + g + " EMC" : "Nothing sold"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 43 -> { AutoSell.toggleOn(p); return; }
                case 44 -> { AutoSell.toggleItem(p, payload.item()); return; }
                case 45 -> { AutoSell.preset(p, payload.item()); return; }
                case 46 -> { AutoSell.send(p); return; }
                case 50 -> { com.uemc.emc.Upgrades.buy(p, payload.item()); sendUpgrades(p); }
                case 51 -> { com.uemc.emc.Upgrades.toggle(p, payload.item()); sendUpgrades(p); }
                case 52 -> sendUpgrades(p);
                case 53 -> { com.uemc.emc.Upgrades.setLevel(p, payload.item(), payload.count()); sendUpgrades(p); }
                case 54 -> { com.uemc.emc.Upgrades.setAll(p, payload.count()); sendUpgrades(p); }
                case 30 -> { Services.tpSetHome(p); return; }
                case 31 -> { Services.tpGo(p, -1); return; }
                case 32 -> { Services.tpAdd(p, payload.item()); return; }
                case 33 -> { Services.tpDelete(p, payload.count()); return; }
                case 34 -> { Services.tpGo(p, payload.count()); return; }
                case 35 -> { Services.sendTp(p); return; }
                default -> { return; }
            }
            p.field_7512.method_7623();   // push inventory changes to the client now
            sendState(p);
        });
    }

    /** You need the EMC Phone in your inventory. */
    public static boolean hasAccess(class_3222 p) {
        return hasTablet(p);
    }

    public static boolean hasTablet(class_3222 p) {
        var inv = p.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) if (inv.method_5438(i).method_31574(ModItems.EMC_TABLET)) return true;
        return false;
    }

    public static void sendValues(class_3222 p) {
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        EmcRegistry.all().forEach((id, v) -> { ids.add(id.toString()); vals.add(v); });
        ServerPlayNetworking.send(p, new ValuesPayload(ids, vals));
    }

    public static void sendUpgrades(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<Integer> lv = new ArrayList<>(), on = new ArrayList<>(), act = new ArrayList<>();
        for (com.uemc.emc.Upgrades.Def u : com.uemc.emc.Upgrades.DEFS) {
            lv.add(d.upgrades.getOrDefault(u.id(), 0));
            on.add(d.off.contains(u.id()) ? 0 : 1);
            act.add(d.active.getOrDefault(u.id(), 0));
        }
        ServerPlayNetworking.send(p, new UpgradesPayload(lv, on, act));
    }

    public static void sendState(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        for (class_2960 id : d.discovered) {
            if (!class_7923.field_41178.method_10250(id)) continue;   // item removed since it was discovered
            long v = EmcRegistry.get(class_7923.field_41178.method_63535(id));
            if (v > 0) { ids.add(id.toString()); vals.add(v); }
        }
        List<Long> slots = new ArrayList<>(36);
        for (int i = 0; i < 36; i++) {
            var st = p.method_31548().method_5438(i);
            slots.add(st.method_7960() ? 0L : EmcLogic.valueOf(st));
        }
        ServerPlayNetworking.send(p, new StatePayload(d.emc, EmcRegistry.size(), ids, vals, slots));
    }
}

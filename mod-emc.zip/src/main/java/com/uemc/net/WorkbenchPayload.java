package com.uemc.net;

import com.uemc.UniversalEmc;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Server -> client: open a click-style workstation screen.
 * which: 0 crafting, 2 stonecutter, 3 grindstone, 5 enchanting.
 * sets    = shared ingredient option lists, each "ns:item,ns:item,...".
 * recipes = "recipeId|resultItem|resultCount|setIndex:qty;setIndex:qty" (empty for grindstone/enchanting).
 */
public record WorkbenchPayload(int which, List<String> sets, List<String> recipes) implements class_8710 {
    public static final class_8710.class_9154<WorkbenchPayload> ID = new class_8710.class_9154<>(class_2960.method_60655(UniversalEmc.ID, "workbench"));

    public static final class_9139<class_9129, WorkbenchPayload> CODEC = new class_9139<>() {
        @Override
        public WorkbenchPayload decode(class_9129 buf) {
            int which = buf.method_10816();
            int n = buf.method_10816();
            List<String> sets = new ArrayList<>(n);
            for (int i = 0; i < n; i++) sets.add(buf.method_19772());
            int m = buf.method_10816();
            List<String> recipes = new ArrayList<>(m);
            for (int i = 0; i < m; i++) recipes.add(buf.method_19772());
            return new WorkbenchPayload(which, sets, recipes);
        }

        @Override
        public void encode(class_9129 buf, WorkbenchPayload p) {
            buf.method_10804(p.which);
            buf.method_10804(p.sets.size());
            for (String s : p.sets) buf.method_10814(s);
            buf.method_10804(p.recipes.size());
            for (String s : p.recipes) buf.method_10814(s);
        }
    };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}

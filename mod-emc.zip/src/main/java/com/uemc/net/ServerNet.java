package com.uemc.net;

import com.uemc.ModItems;
import com.uemc.block.ConverterBlock;
import com.uemc.emc.*;
import com.uemc.menu.Handlers;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3914;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import java.util.*;

public final class ServerNet {
    private ServerNet() {}

    /** Converter each player last opened (validated again on every packet). */
    private record Open(class_3218 world, class_2338 pos) {}
    private static final Map<UUID, Open> OPEN = new HashMap<>();

    public static void init() {
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenMenuPayload.ID, OpenMenuPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ValuesPayload.ID, ValuesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(TeleportListPayload.ID, TeleportListPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WorkbenchPayload.ID, WorkbenchPayload.CODEC);
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendValues(handler.field_14140));
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MenuActionPayload.ID, MenuActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, ctx) -> {
            class_3222 p = ctx.player();
            if (!hasAccess(p)) return;
            switch (payload.action()) {
                case 1 -> {
                    class_2960 id = class_2960.method_12829(payload.item());
                    if (id == null || !class_7923.field_41178.method_10250(id)) return;
                    String err = EmcLogic.buy(p, class_7923.field_41178.method_63535(id), payload.count());
                    if (err != null) p.method_7353(class_2561.method_43470(err), true);
                    else p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 2 -> {
                    long g = EmcLogic.convert(p, p.method_6079());
                    p.method_7353(class_2561.method_43470(g > 0 ? "+" + g + " EMC" : "Offhand item has no EMC value"), true);
                }
                case 3 -> {
                    long g = EmcLogic.sellSlot(p, payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold +" + g + " EMC" : "Can't sell that"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 4 -> {
                    long g = EmcLogic.sellAll(p);
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold everything: +" + g + " EMC" : "Nothing to sell"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 5 -> {
                    long g = EmcLogic.sellXp(p, payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold XP: +" + g + " EMC" : "No XP to sell"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 6 -> {
                    String err = EmcLogic.buyXp(p, payload.count());
                    if (err != null) p.method_7353(class_2561.method_43470(err), true);
                    else p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.0f);
                }
                case 7 -> Services.enchant(p, payload.item(), payload.count());
                case 8 -> Services.startSmelt(p, payload.count());
                case 9 -> Services.stopSmelt(p);
                case 10 -> Services.repair(p);
                case 11 -> {}
                case 20, 21, 22, 23, 24, 25, 26 -> { Services.open(p, payload.action() - 20); return; }
                case 42 -> {
                    long g = EmcLogic.sellSlots(p, payload.item(), payload.count());
                    p.method_7353(class_2561.method_43470(g > 0 ? "Sold +" + g + " EMC" : "Nothing sold"), true);
                    if (g > 0) p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 1.2f);
                }
                case 40 -> { Workbench.craft(p, payload.item(), payload.count()); return; }
                case 41 -> { Workbench.disenchant(p); return; }
                case 30 -> { Services.tpSetHome(p); return; }
                case 31 -> { Services.tpGo(p, -1); return; }
                case 32 -> { Services.tpAdd(p, payload.item()); return; }
                case 33 -> { Services.tpDelete(p, payload.count()); return; }
                case 34 -> { Services.tpGo(p, payload.count()); return; }
                case 35 -> { Services.sendTp(p); return; }
                default -> { return; }
            }
            sendState(p);
        });

        ServerPlayNetworking.registerGlobalReceiver(MenuActionPayload.ID, (payload, ctx) -> {
            class_3222 p = ctx.player();
            Open o = OPEN.get(p.method_5667());
            class_2338 pos = class_2338.method_10092(payload.pos());
            if (o == null || !o.pos.equals(pos) || !valid(p, o)) return;
            ConverterBlock.pulse(o.world, pos);
            class_3914 sc = class_3914.method_17392(o.world, pos);
            switch (payload.which()) {
                case 0 -> Workbench.open(p, Workbench.CRAFT);
                case 1 -> {
                    if (Workbench.CONVERTER_CUSTOM_ENCHANT) Workbench.open(p, Workbench.ENCHANT);
                    else p.method_17355(new class_747((id, inv, pl) -> new Handlers.Enchant(id, inv, sc), class_2561.method_43470("Enchant")));
                }
                case 2 -> p.method_17355(new class_747((id, inv, pl) -> new Handlers.Anvil(id, inv, sc), class_2561.method_43470("Anvil")));
                case 3 -> Workbench.open(p, Workbench.STONECUT);
                case 4 -> Workbench.open(p, Workbench.GRIND);
                case 5 -> p.method_17355(new class_747((id, inv, pl) -> new Handlers.Smith(id, inv, sc), class_2561.method_43470("Smithing")));
                case 8 -> sendState(p);
                default -> {}
            }
        });
    }

    public static void openMenu(class_3222 p, class_3218 w, class_2338 pos) {
        OPEN.put(p.method_5667(), new Open(w, pos.method_10062()));
        ServerPlayNetworking.send(p, new OpenMenuPayload(pos.method_10063()));
    }

    private static boolean valid(class_3222 p, Open o) {
        return p.method_5649(o.pos.method_10263() + 0.5, o.pos.method_10264() + 0.5, o.pos.method_10260() + 0.5) <= 64
                && o.world.method_8320(o.pos).method_26204() instanceof ConverterBlock;
    }

    /** Tablet in inventory, or standing next to the converter you opened. */
    public static boolean hasAccess(class_3222 p) {
        if (hasTablet(p)) return true;
        Open o = OPEN.get(p.method_5667());
        return o != null && valid(p, o);
    }

    public static boolean hasTablet(class_3222 p) {
        var inv = p.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) if (inv.method_5438(i).method_31574(ModItems.EMC_TABLET)) return true;
        return false;
    }

    public static void sendValues(class_3222 p) {
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        EmcRegistry.all().forEach((id, v) -> { ids.add(id.toString()); vals.add(v); });
        ServerPlayNetworking.send(p, new ValuesPayload(ids, vals));
    }

    public static void sendState(class_3222 p) {
        EmcData.Player d = EmcData.get(p.method_5667());
        List<String> ids = new ArrayList<>();
        List<Long> vals = new ArrayList<>();
        for (class_2960 id : d.discovered) {
            long v = EmcRegistry.get(class_7923.field_41178.method_63535(id));
            if (v > 0) { ids.add(id.toString()); vals.add(v); }
        }
        List<Long> slots = new ArrayList<>(36);
        for (int i = 0; i < 36; i++) {
            var st = p.method_31548().method_5438(i);
            slots.add(st.method_7960() ? 0L : EmcLogic.valueOf(st));
        }
        ServerPlayNetworking.send(p, new StatePayload(d.emc, EmcRegistry.size(), ids, vals, slots));
    }
}

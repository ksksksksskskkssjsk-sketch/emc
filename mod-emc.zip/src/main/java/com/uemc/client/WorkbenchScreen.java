package com.uemc.client;

import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.*;

/**
 * Crafting table / stonecutter without slots: search every recipe, see what you can make right now,
 * pick a result and click Craft. The server consumes the ingredients from your inventory and re-checks everything.
 */
public class WorkbenchScreen extends ServiceScreen {
    private record Need(List<class_1792> items, Set<class_2960> ids, int qty) {}
    private record Rec(String id, class_1792 out, int count, List<Need> needs) {}

    private static final class Group {
        final String key, name;
        final class_1799 icon;
        final List<Rec> recs = new ArrayList<>();
        int craftable = 0, bestVariant = 0;
        Group(String key, class_1799 icon) {
            this.key = key;
            this.icon = icon;
            this.name = icon.method_7964().getString();
        }
    }

    private static final int COLS = 7, ROWS = 6, PER = COLS * ROWS;

    private final int which;
    private final List<Group> all = new ArrayList<>(), shown = new ArrayList<>();
    private final List<GlowButton> cells = new ArrayList<>();
    private final Map<class_2960, Integer> have = new HashMap<>();
    private int haveHash = 0, page = 0, variant = 0, ticks = 0;
    private String query = "", selKey = null;
    private boolean onlyCraftable = false;
    private float pageT = Fx.t();
    private GlowButton prev, next, filter, c1, c2, c3;
    private class_342 search;

    public WorkbenchScreen(int which, List<String> sets, List<String> recipes) {
        super(which == 0 ? "CRAFTING" : "STONECUTTER");
        this.which = which;
        H = 232;
        accent = which == 0 ? Fx.GOLD : Fx.GREEN;

        List<List<class_1792>> setItems = new ArrayList<>();
        for (String s : sets) {
            List<class_1792> l = new ArrayList<>();
            for (String id : s.split(",")) {
                class_2960 r = class_2960.method_12829(id);
                if (r != null && class_7923.field_41178.method_10250(r)) l.add(class_7923.field_41178.method_63535(r));
            }
            setItems.add(l);
        }
        Map<String, Group> groups = new LinkedHashMap<>();
        for (String s : recipes) {
            try {
                String[] f = s.split("\\|", -1);
                if (f.length < 4) continue;
                class_2960 oid = class_2960.method_12829(f[1]);
                if (oid == null || !class_7923.field_41178.method_10250(oid)) continue;
                class_1792 out = class_7923.field_41178.method_63535(oid);
                int count = Integer.parseInt(f[2]);
                List<Need> needs = new ArrayList<>();
                boolean ok = !f[3].isEmpty();
                if (ok) for (String n : f[3].split(";")) {
                    String[] q = n.split(":");
                    List<class_1792> items = setItems.get(Integer.parseInt(q[0]));
                    if (items.isEmpty()) { ok = false; break; }
                    Set<class_2960> ids = new HashSet<>();
                    for (class_1792 it : items) ids.add(class_7923.field_41178.method_10221(it));
                    needs.add(new Need(items, ids, Integer.parseInt(q[1])));
                }
                if (!ok) continue;
                Group g = groups.computeIfAbsent(oid.toString(), k -> new Group(k, new class_1799(out)));
                g.recs.add(new Rec(f[0], out, count, needs));
            } catch (RuntimeException ignored) {}
        }
        all.addAll(groups.values());
        scanInv();
        recount();
    }

    // ---------- inventory + recipe maths (display only; the server re-checks) ----------
    private boolean scanInv() {
        have.clear();
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return false;
        int h = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960()) continue;
            have.merge(class_7923.field_41178.method_10221(s.method_7909()), s.method_7947(), Integer::sum);
            h = h * 31 + s.method_7947() + i * 7 + s.method_7909().hashCode();
        }
        boolean changed = h != haveHash;
        haveHash = h;
        return changed;
    }

    private int have(Need n) {
        int sum = 0;
        for (class_2960 id : n.ids) sum += have.getOrDefault(id, 0);
        return sum;
    }

    private int crafts(Rec r) {
        int best = Integer.MAX_VALUE;
        for (Need n : r.needs) best = Math.min(best, have(n) / n.qty);
        return best == Integer.MAX_VALUE ? 0 : best;
    }

    private void recount() {
        for (Group g : all) {
            g.craftable = 0;
            g.bestVariant = 0;
            for (int i = 0; i < g.recs.size(); i++) {
                int c = crafts(g.recs.get(i));
                if (c > g.craftable) { g.craftable = c; g.bestVariant = i; }
            }
        }
    }

    private Group sel() {
        if (selKey == null) return null;
        for (Group g : all) if (g.key.equals(selKey)) return g;
        return null;
    }

    private Rec selRec() {
        Group g = sel();
        if (g == null) return null;
        return g.recs.get(Math.max(0, Math.min(variant, g.recs.size() - 1)));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        cells.clear();
        ClientPlayNetworking.send(new ActionPayload(11, "", 0)); // sync EMC balance for the header

        search = new class_342(field_22793, left + 8, top + 22, 140, 14, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; page = 0; pageT = Fx.t(); refilter(); });
        method_37063(search);

        filter = GlowButton.of("", left + 152, top + 22, 90, 14, b -> { onlyCraftable = !onlyCraftable; page = 0; pageT = Fx.t(); refilter(); });
        filter.method_47400(class_7919.method_47407(class_2561.method_43470("Show only what you can craft right now")));
        method_37063(filter);

        for (int i = 0; i < PER; i++) {
            final int idx = i;
            GlowButton b = GlowButton.slot(left + 8 + (i % COLS) * 18, top + 40 + (i / COLS) * 18, x -> pick(idx));
            b.accent = accent;
            cells.add(b);
            method_37063(b);
        }
        method_37063(GlowButton.of("<", left + 8, top + 150, 20, 16, b -> { if (page > 0) { page--; pageT = Fx.t(); refilter(); } }));
        method_37063(GlowButton.of(">", left + 114, top + 150, 20, 16, b -> { if ((page + 1) * PER < shown.size()) { page++; pageT = Fx.t(); refilter(); } }));

        int bx = left + 152;
        prev = GlowButton.of("<", bx, top + 104, 18, 14, b -> cycle(-1));
        next = GlowButton.of(">", bx + 72, top + 104, 18, 14, b -> cycle(1));
        prev.method_47400(class_7919.method_47407(class_2561.method_43470("Previous recipe for this item")));
        next.method_47400(class_7919.method_47407(class_2561.method_43470("Next recipe for this item")));
        method_37063(prev);
        method_37063(next);

        c1 = GlowButton.of("Craft 1", left + 8, top + 208, 74, 18, b -> craft(1));
        c2 = GlowButton.of("Craft 10", left + 88, top + 208, 74, 18, b -> craft(10));
        c3 = GlowButton.of("Craft max", left + 168, top + 208, 74, 18, b -> craft(0));
        c1.accent = c2.accent = c3.accent = accent;
        method_37063(c1);
        method_37063(c2);
        method_37063(c3);
        refilter();
    }

    private void cycle(int d) {
        Group g = sel();
        if (g == null || g.recs.size() < 2) return;
        variant = (variant + d + g.recs.size()) % g.recs.size();
    }

    private void pick(int idx) {
        int i = page * PER + idx;
        if (i >= shown.size()) return;
        Group g = shown.get(i);
        selKey = g.key;
        variant = g.bestVariant;
    }

    private void craft(int n) {
        Rec r = selRec();
        if (r != null) ClientPlayNetworking.send(new ActionPayload(40, r.id, n));
    }

    private void refilter() {
        shown.clear();
        String q = query.toLowerCase();
        for (Group g : all) {
            if (onlyCraftable && g.craftable <= 0) continue;
            if (q.isEmpty() || g.name.toLowerCase().contains(q) || g.key.contains(q)) shown.add(g);
        }
        shown.sort((a, b) -> {
            int ca = a.craftable > 0 ? 0 : 1, cb = b.craftable > 0 ? 0 : 1;
            return ca != cb ? ca - cb : a.name.compareToIgnoreCase(b.name);
        });
        page = Math.max(0, Math.min(page, (Math.max(1, shown.size()) - 1) / PER));
        for (int i = 0; i < cells.size(); i++) {
            GlowButton c = cells.get(i);
            int idx = page * PER + i;
            c.field_22763 = idx < shown.size();
            if (idx < shown.size()) {
                Group g = shown.get(idx);
                c.method_47400(class_7919.method_47407(class_2561.method_43470(g.name + (g.craftable > 0 ? "\nYou can craft " + g.craftable : "\nMissing ingredients"))));
            } else c.method_47400(null);
        }
        filter.method_25355(class_2561.method_43470(onlyCraftable ? "Can craft: ON" : "Can craft: OFF"));
        filter.selected = onlyCraftable;
        filter.accent = accent;
        syncButtons();
    }

    private void syncButtons() {
        Group g = sel();
        Rec r = selRec();
        int c = r == null ? 0 : crafts(r);
        c1.field_22763 = c >= 1;
        c2.field_22763 = c >= 2;
        c3.field_22763 = c >= 1;
        boolean multi = g != null && g.recs.size() > 1;
        prev.field_22764 = next.field_22764 = multi;
    }

    @Override
    public void method_25393() {
        if (++ticks % 5 == 0 && scanInv()) { recount(); refilter(); }
        syncButtons();
    }

    // ---------- drawing ----------
    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        float now = Fx.t();
        ctx.method_25296(left + 148, top + 40, left + 149, top + 166, Fx.argb(0, accent), Fx.argb(200, accent));

        for (int i = 0; i < cells.size(); i++) {
            int idx = page * PER + i;
            if (idx >= shown.size()) break;
            Group g = shown.get(idx);
            int x = left + 8 + (i % COLS) * 18 + 1, y = top + 40 + (i / COLS) * 18 + 1;
            float appear = Fx.ease((now - pageT) * 4f - ((i % COLS) + (i / COLS)) * 0.08f);
            Fx.item(ctx, g.icon, x, y, cells.get(i).method_49606(), g.key.equals(selKey), appear, accent);
            if (appear > 0.9f) {
                if (g.craftable > 0) ctx.method_25294(x + 13, y + 13, x + 16, y + 16, Fx.argb(255, Fx.GREEN));
                else ctx.method_25294(x, y, x + 16, y + 16, 0x99101820);
            }
        }
        int pages = Math.max(1, (shown.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 64, top + 154, GREY);

        int bx = left + 152;
        Group g = sel();
        Rec r = selRec();
        if (g == null || r == null) {
            txt(ctx, shown.isEmpty() ? "No recipes found" : "Pick an item", bx, top + 60, GREY);
            return;
        }
        Fx.showcase(ctx, g.icon, bx + 14, top + 62, 1.6f, accent);
        txt(ctx, field_22793.method_27523(g.name, 58), bx + 32, top + 46, WHITE);
        txt(ctx, "Makes x" + r.count, bx + 32, top + 60, GREY);
        int c = crafts(r);
        if (c > 0) txt(ctx, "Can craft " + c, bx + 32, top + 74, 0xFF7FFFB0);
        else txt(ctx, "Missing items", bx + 32, top + 74, 0xFFFF7070);
        if (g.recs.size() > 1) {
            String v = "Recipe " + (variant + 1) + "/" + g.recs.size();
            txt(ctx, v, bx + 45 - field_22793.method_1727(v) / 2, top + 107, GREY);
        }

        // ingredient strip: icon + have/need, cycles through tag options (e.g. any planks)
        txt(ctx, "Needs", left + 8, top + 168, GREY);
        int n = Math.min(6, r.needs.size());
        for (int i = 0; i < n; i++) {
            Need nd = r.needs.get(i);
            int x = left + 8 + i * 38, y = top + 178;
            int h = have(nd);
            boolean ok = h >= nd.qty;
            Fx.ring(ctx, x, y, 20, 20, Fx.argb(150, ok ? Fx.GREEN : Fx.RED));
            ctx.method_51427(new class_1799(nd.items.get((int) now % nd.items.size())), x + 2, y + 2);
            String t = h + "/" + nd.qty;
            txt(ctx, t, x + 10 - field_22793.method_1727(t) / 2, y + 22, ok ? 0xFF7FFFB0 : 0xFFFF7070);
        }
        if (r.needs.size() > n) txt(ctx, "+" + (r.needs.size() - n) + " more", left + 8 + n * 38, top + 184, GREY);
    }
}

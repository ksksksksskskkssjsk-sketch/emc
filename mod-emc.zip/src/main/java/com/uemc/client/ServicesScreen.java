package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.List;

/** Tablet upgrades menu: big two-line cards (name + price). Server charges the EMC. */
public class ServicesScreen extends ServiceScreen {
    private record Card(String title, String sub, long fee, int x, int y, int w, int h, String icon) {}

    private final List<Card> cards = new ArrayList<>();

    public ServicesScreen() {
        super("TABLET UPGRADES");
        W = 304;
        H = 104;
    }

    private void card(String title, String sub, long fee, String tip, int x, int y, int w, int color, String icon, Runnable r) {
        GlowButton b = GlowButton.of("", left + x, top + y, w, 26, bb -> r.run());
        b.accent = color;
        b.method_47400(class_7919.method_47407(class_2561.method_43470(tip)));
        method_37063(b);
        cards.add(new Card(title, sub, fee, left + x, top + y, w, 26, icon));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        cards.clear();
        card("Enchanting", "any item, MAX ALL", 0, "Enchanting table: click any item, pick an enchant, or MAX ALL in one click",
                10, 36, 92, Fx.PURPLE, "minecraft:enchanting_table", () -> class_310.method_1551().method_1507(new EnchantScreen(
                        () -> class_310.method_1551().method_1507(new ServicesScreen()))));
        card("Furnace", "no fuel needed", 0, "Smelt with no fuel. Pick the speed.",
                106, 36, 92, Fx.ORANGE, "minecraft:furnace", () -> class_310.method_1551().method_1507(new FurnaceScreen()));
        card("Repair hand", Fees.REPAIR_PER_POINT + " EMC / point", 0, "Fully repair the held item. " + Fees.REPAIR_PER_POINT + " EMC per durability point",
                202, 36, 92, Fx.GREEN, "minecraft:iron_pickaxe", () -> ClientPlayNetworking.send(new ActionPayload(10, "", 0)));
        card("Teleport", "home + checkpoints", 0, "Set a home and checkpoints, teleport for EMC",
                10, 66, 92, Fx.GREEN, "minecraft:ender_pearl", () -> class_310.method_1551().method_1507(new TeleportScreen()));
        card("Upgrades", "tools + perks", 0, "Hammer 3x3, vein miner, lumberjack, auto-repair, haste, speed and more",
                106, 66, 92, Fx.PURPLE, "minecraft:diamond_pickaxe", () -> class_310.method_1551().method_1507(new UpgradesScreen(
                        () -> class_310.method_1551().method_1507(new ServicesScreen()))));

        GlowButton back = GlowButton.of("Back to tablet", left + 202, top + 66, 92, 26, b -> {
            class_310.method_1551().method_1507(null);
            ClientPlayNetworking.send(new ActionPayload(11, "", 0));
        });
        back.accent = Fx.GOLD;
        method_37063(back);
    }

    /** Smaller text (0.75x) centred on cx. */
    private void small(class_332 c, String s, int cx, int y, int color) {
        var m = c.method_51448();
        m.pushMatrix();
        m.scale(0.75f, 0.75f);
        int w = field_22793.method_1727(s);
        c.method_51439(field_22793, class_2561.method_43470(s), (int) (cx / 0.75f - w / 2f), (int) (y / 0.75f), color, false);
        m.popMatrix();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        txt(ctx, "SERVICES", left + 10, top + 24, 0xFF7A8A99);
        for (Card c : cards) {
            int cx = c.x + c.w / 2 + 9;
            Icons.draw(ctx, c.icon, c.x + 12, c.y + 13, 0.9f);
            String t = field_22793.method_27523(c.title, c.w - 26);
            ctx.method_51439(field_22793, class_2561.method_43470(t), cx - field_22793.method_1727(t) / 2, c.y + 5, WHITE, true);
            boolean ok = c.fee <= 0 || c.fee <= ClientEmc.balance;
            small(ctx, c.sub, cx, c.y + 16, ok ? 0xFFE0B040 : 0xFFFF7070);
        }
    }
}

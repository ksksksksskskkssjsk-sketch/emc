package com.uemc.client;

import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import java.util.ArrayList;
import java.util.List;

/** Grindstone without slots: shows the held item's enchants, one click strips them (curses stay) for a little XP. */
public class DisenchantScreen extends ServiceScreen {
    private record Line(String name, int lvl, boolean curse) {}

    private final List<Line> lines = new ArrayList<>();
    private class_1799 last = class_1799.field_8037;
    private int xp = 0, removable = 0;
    private GlowButton go;

    public DisenchantScreen() {
        super("GRINDSTONE");
        H = 186;
        accent = Fx.ORANGE;
    }

    private void rebuild() {
        lines.clear();
        xp = 0;
        removable = 0;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        class_1799 held = mc.field_1724.method_6047();
        last = held.method_7972();
        if (!held.method_7960()) {
            var reg = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
            class_9304 cur = class_1890.method_57532(held);
            for (class_6880<class_1887> e : cur.method_57534()) {
                class_2960 id = reg.method_10221(e.comp_349());
                boolean curse = id != null && id.method_12832().endsWith("_curse");
                int lv = cur.method_57536(e);
                lines.add(new Line(e.comp_349().comp_2686().getString(), lv, curse));
                if (!curse) { xp += com.uemc.emc.Workbench.XP_PER_LEVEL * lv; removable++; }
            }
        }
        if (go != null) go.field_22763 = removable > 0;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        ClientPlayNetworking.send(new ActionPayload(11, "", 0)); // sync EMC balance for the header
        go = GlowButton.of("Disenchant held item", left + 10, top + 160, 230, 18,
                b -> ClientPlayNetworking.send(new ActionPayload(41, "", 0)));
        go.accent = Fx.ORANGE;
        method_37063(go);
        rebuild();
    }

    @Override
    public void method_25393() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && !class_1799.method_7973(last, mc.field_1724.method_6047())) rebuild();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        class_310 mc = class_310.method_1551();
        class_1799 st = mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
        if (st.method_7960()) { txt(ctx, "Hold an enchanted item", left + 8, top + 28, GREY); return; }
        Fx.showcase(ctx, st, left + 18, top + 36, 1.0f, accent);
        txt(ctx, field_22793.method_27523(st.method_7964().getString(), 200), left + 36, top + 32, WHITE);
        if (lines.isEmpty()) { txt(ctx, "This item has no enchantments", left + 10, top + 58, GREY); return; }
        for (int i = 0; i < lines.size() && i < 7; i++) {
            Line l = lines.get(i);
            String s = l.name + " " + l.lvl + (l.curse ? "  (curse stays)" : "");
            txt(ctx, field_22793.method_27523(s, 226), left + 12, top + 54 + i * 11, l.curse ? 0xFF6A7580 : CYAN);
        }
        if (lines.size() > 7) txt(ctx, "+" + (lines.size() - 7) + " more", left + 12, top + 54 + 7 * 11, GREY);
        if (removable > 0) Fx.glowText(ctx, field_22793, "You get +" + xp + " XP", left + 10, top + 146, Fx.ORANGE);
        else txt(ctx, "Nothing to remove", left + 10, top + 146, GREY);
    }
}

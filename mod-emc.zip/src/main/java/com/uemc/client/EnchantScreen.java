package com.uemc.client;

import com.uemc.emc.EnchantPlan;
import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_6880;
import net.minecraft.class_7919;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import java.util.ArrayList;
import java.util.List;

/**
 * Enchanting Table, easy mode.
 *   RIGHT: click ANY item in your inventory (no need to hold it). Your held item is picked for you.
 *   LEFT : click an enchant (type in the search box to find it). Level jumps to the max (X); click a lower number if you want less.
 *   Then press the big button. The price is always shown; you only pay the difference to what the item already has.
 *   "MAX ALL" adds every enchant that fits at max level in one click.
 * Enchants that clash with something already on the item are greyed out and say why.
 * The server re-checks everything (item, level cap, conflicts, EMC).
 */
public class EnchantScreen extends ServiceScreen {
    private record Row(class_6880<class_1887> e, String id, String name, int max, String conflict) {}

    private static final int PER = 8, ROW_H = 20, LIST_Y = 42, LIST_W = 138, CHIPS = 10;
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private final Runnable back;
    private final List<Row> all = new ArrayList<>();
    private final List<Row> shown = new ArrayList<>();
    private final GlowButton[] slots = new GlowButton[PER];
    private final GlowButton[] chips = new GlowButton[CHIPS];
    private final GlowButton[] cell = new GlowButton[36];
    private final class_1799[] snap = new class_1799[36];
    private final boolean[] fits = new boolean[36];
    private class_342 search;
    private GlowButton apply, maxAll, prev, next;
    private String query = "";
    private long lastBal = Long.MIN_VALUE;
    private int page = 0, lvl = 0, slot = -1;
    private Row sel;
    private EnchantPlan plan = null;
    private boolean synced = false, picked = false;

    public EnchantScreen(Runnable back) {
        super("ENCHANTING TABLE");
        this.back = back;
        W = 360;
        H = 240;
        accent = Fx.PURPLE;
        for (int i = 0; i < 36; i++) snap[i] = class_1799.field_8037;
    }

    private static String roman(int k) { return k >= 0 && k < ROMAN.length ? ROMAN[k] : String.valueOf(k); }

    private static String shortNum(long v) {
        if (v >= 10_000_000) return (v / 1_000_000) + "M";
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000.0);
        if (v >= 10_000) return (v / 1000) + "k";
        return String.valueOf(v);
    }

    private int rx() { return left + 158; }
    private int cellX(int s) { return rx() + (s < 9 ? s : (s - 9) % 9) * 18; }
    private int cellY(int s) { return s < 9 ? top + 82 : top + 28 + ((s - 9) / 9) * 18; }

    private class_1799 stack(int s) {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null || s < 0 || s > 35 ? class_1799.field_8037 : mc.field_1724.method_31548().method_5438(s);
    }

    private class_1799 item() { return stack(slot); }

    private class_2378<class_1887> reg() {
        class_310 mc = class_310.method_1551();
        return mc.field_1687 == null ? null : mc.field_1687.method_30349().method_30530(class_7924.field_41265);
    }

    private int have(Row r) {
        class_1799 st = item();
        return st.method_7960() ? 0 : class_1890.method_8225(r.e, st);
    }

    private long price(int level) { return sel == null ? 0 : Math.max(0, Fees.enchant(level) - Fees.enchant(have(sel))); }

    // ---------- data ----------
    /** Which inventory slots can take any enchant at all, and the default pick (the item in your hand). */
    private void scanInventory() {
        class_2378<class_1887> reg = reg();
        for (int i = 0; i < 36; i++) {
            snap[i] = stack(i).method_7972();
            fits[i] = reg != null && EnchantPlan.fits(reg, snap[i]);
        }
        if (!picked) {
            picked = true;
            class_310 mc = class_310.method_1551();
            class_1799 held = mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
            for (int i = 0; i < 36 && slot < 0; i++) if (!held.method_7960() && stack(i) == held && fits[i]) slot = i;
            for (int i = 0; i < 36 && slot < 0; i++) if (fits[i]) slot = i;
        }
        if (slot >= 0 && !fits[slot]) slot = -1;
    }

    private boolean inventoryChanged() {
        for (int i = 0; i < 36; i++) if (!class_1799.method_7973(snap[i], stack(i))) return true;
        return false;
    }

    /** Everything that can go on the picked item (sorted: usable first, then A-Z). */
    private void rebuildRows() {
        all.clear();
        class_2378<class_1887> reg = reg();
        class_1799 st = item();
        plan = null;
        if (reg != null && !st.method_7960()) {
            plan = EnchantPlan.make(reg, st);
            class_9304 cur = class_1890.method_57532(st);
            reg.method_42017().forEach(ref -> {
                class_1887 en = ref.comp_349();
                if (!en.method_8192(st)) return;
                String conflict = null;
                for (class_6880<class_1887> o : cur.method_57534()) {
                    if (!o.equals(ref) && !class_1887.method_60033(ref, o)) { conflict = o.comp_349().comp_2686().getString(); break; }
                }
                all.add(new Row(ref, ref.method_40237().method_29177().toString(), en.comp_2686().getString(),
                        Fees.maxLevel(en.method_8183()), conflict));
            });
            all.sort((a, b) -> {
                int ca = a.conflict == null ? 0 : 1, cb = b.conflict == null ? 0 : 1;
                return ca != cb ? ca - cb : a.name.compareToIgnoreCase(b.name);
            });
        }
        if (sel != null) {
            Row keep = null;
            for (Row r : all) if (r.id.equals(sel.id)) keep = r;
            sel = keep;
        }
        refilter();
    }

    private void refilter() {
        shown.clear();
        String q = query.trim().toLowerCase();
        for (Row r : all) if (q.isEmpty() || r.name.toLowerCase().contains(q) || r.id.contains(q)) shown.add(r);
        page = Math.max(0, Math.min(page, (Math.max(1, shown.size()) - 1) / PER));
        if (sel != null) lvl = Math.max(1, Math.min(sel.max, lvl));
    }

    // ---------- widgets ----------
    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); } // sync EMC balance

        search = new class_342(field_22793, left + 8, top + 24, LIST_W, 14, class_2561.method_43470("Search"));
        search.method_1852(query);
        search.method_1863(t -> { query = t; page = 0; refilter(); refresh(); });
        method_37063(search);

        for (int i = 0; i < PER; i++) {
            final int idx = i;
            slots[i] = GlowButton.of("", left + 8, top + LIST_Y + i * ROW_H, LIST_W, 18, b -> pickRow(idx));
            method_37063(slots[i]);
        }

        prev = GlowButton.of("<", left + 8, top + 208, 20, 16, b -> { if (page > 0) { page--; refresh(); } });
        next = GlowButton.of(">", left + 30, top + 208, 20, 16, b -> { if ((page + 1) * PER < shown.size()) { page++; refresh(); } });
        method_37063(prev);
        method_37063(next);

        for (int s = 0; s < 36; s++) {
            final int sl = s;
            cell[s] = GlowButton.slot(cellX(s), cellY(s), b -> pickItem(sl));
            cell[s].accent = Fx.PURPLE;
            method_37063(cell[s]);
        }

        for (int k = 0; k < CHIPS; k++) {
            final int level = k + 1;
            chips[k] = GlowButton.of(String.valueOf(level), rx() + (k % 5) * 38, top + 128 + (k / 5) * 22, 36, 20, b -> { lvl = level; refresh(); });
            method_37063(chips[k]);
        }

        apply = GlowButton.of("", rx(), top + 192, 190, 22, b -> {
            if (sel != null && slot >= 0) ClientPlayNetworking.send(new ActionPayload(12, sel.id, slot * 100 + lvl));
        });
        apply.accent = Fx.PURPLE;
        method_37063(apply);

        maxAll = GlowButton.of("", rx(), top + 218, 126, 16, b -> {
            if (slot >= 0 && plan != null && !plan.entries.isEmpty()) ClientPlayNetworking.send(new ActionPayload(13, "", slot));
        });
        maxAll.accent = Fx.GOLD;
        method_37063(maxAll);

        GlowButton close = GlowButton.of("Back", rx() + 130, top + 218, 60, 16, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);

        scanInventory();
        rebuildRows();
        refresh();
    }

    private void pickItem(int s) {
        if (!fits[s]) return;
        slot = s;
        sel = null;
        rebuildRows();
        refresh();
    }

    private void pickRow(int slotIdx) {
        int idx = page * PER + slotIdx;
        if (idx >= shown.size()) return;
        sel = shown.get(idx);
        lvl = sel.max;               // jump straight to the top level (X); click a lower chip if you want less
        refresh();
    }

    private static void tip(GlowButton b, String s) {
        b.method_47400(s == null ? null : class_7919.method_47407(class_2561.method_43470(s)));
    }

    /** Re-style every widget from the current state (cheap). */
    private void refresh() {
        if (apply == null) return;
        lastBal = ClientEmc.balance;

        for (int s = 0; s < 36; s++) {
            GlowButton b = cell[s];
            class_1799 st = snap[s];
            b.field_22763 = fits[s];
            b.selected = s == slot;
            tip(b, st.method_7960() ? null : st.method_7964().getString() + (fits[s] ? "" : "\nNo enchants fit"));
        }

        for (int i = 0; i < PER; i++) {
            GlowButton b = slots[i];
            int idx = page * PER + i;
            if (idx >= shown.size()) { b.field_22764 = false; continue; }
            Row r = shown.get(idx);
            int h = have(r);
            b.field_22764 = true;
            b.method_25355(class_2561.method_43470(field_22793.method_27523(r.name, 104) + (h > 0 ? "  " + roman(h) : "")));
            boolean blocked = r.conflict != null, maxed = h >= r.max;
            b.field_22763 = !blocked && !maxed;
            b.selected = sel != null && sel.id.equals(r.id);
            b.accent = maxed ? Fx.GREEN : h > 0 ? Fx.CYAN : Fx.PURPLE;
            tip(b, blocked ? "Conflicts with " + r.conflict : maxed ? "Already at max level" : null);
        }

        for (int k = 0; k < CHIPS; k++) {
            GlowButton c = chips[k];
            int level = k + 1;
            if (sel == null || level > sel.max) { c.field_22764 = false; continue; }
            c.field_22764 = true;
            int h = have(sel);
            boolean owned = level <= h;
            long p = price(level);
            c.field_22763 = !owned;
            c.selected = level == lvl;
            c.accent = owned ? Fx.GREEN : p <= ClientEmc.balance ? Fx.PURPLE : Fx.RED;
            tip(c, owned ? "Already on the item" : sel.name + " " + roman(level) + "\n" + Fx.num(p) + " EMC");
        }

        int pages = Math.max(1, (shown.size() + PER - 1) / PER);
        prev.field_22763 = page > 0;
        next.field_22763 = page + 1 < pages;

        // MAX ALL button
        if (plan == null || plan.entries.isEmpty()) {
            maxAll.method_25355(class_2561.method_43470(slot < 0 ? "MAX ALL" : "Fully maxed"));
            maxAll.field_22763 = false;
            tip(maxAll, null);
        } else {
            boolean ok = plan.fee <= ClientEmc.balance;
            maxAll.method_25355(class_2561.method_43470("MAX ALL  " + shortNum(plan.fee)));
            maxAll.field_22763 = ok;
            maxAll.accent = ok ? Fx.GOLD : Fx.RED;
            StringBuilder sb = new StringBuilder("All enchants at max level\n" + Fx.num(plan.fee) + " EMC" + (ok ? "" : "  (not enough)"));
            for (EnchantPlan.Entry e : plan.entries) sb.append('\n').append(e.name()).append(' ').append(roman(e.level()));
            tip(maxAll, sb.toString());
        }

        if (slot < 0) { apply.method_25355(class_2561.method_43470("Pick an item")); apply.field_22763 = false; return; }
        if (sel == null) { apply.method_25355(class_2561.method_43470("Pick an enchant")); apply.field_22763 = false; return; }
        if (have(sel) >= lvl) { apply.method_25355(class_2561.method_43470("Already has it")); apply.field_22763 = false; return; }
        long c = price(lvl);
        if (c > ClientEmc.balance) { apply.method_25355(class_2561.method_43470("Need " + Fx.num(c) + " EMC")); apply.field_22763 = false; return; }
        apply.method_25355(class_2561.method_43470("ENCHANT  " + Fx.num(c) + " EMC"));
        apply.field_22763 = true;
    }

    @Override
    public void method_25393() {
        boolean changed = inventoryChanged();
        if (changed) {
            scanInventory();
            rebuildRows();
        }
        if (changed || ClientEmc.balance != lastBal) refresh();
    }

    // ---------- drawing ----------
    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        int x0 = rx();
        ctx.method_25294(left + 150, top + 24, left + 151, top + H - 8, Fx.argb(110, Fx.PURPLE));

        // inventory picker
        for (int s = 0; s < 36; s++) {
            class_1799 st = snap[s];
            if (st.method_7960()) continue;
            int x = cellX(s) + 1, y = cellY(s) + 1;
            Fx.item(ctx, st, x, y, cell[s] != null && cell[s].method_49606() && fits[s], s == slot, 1f, Fx.PURPLE);
            if (!fits[s]) ctx.method_25294(x, y, x + 16, y + 16, 0xA0000000);
        }

        class_1799 st = item();
        if (slot < 0 || st.method_7960()) {
            txt(ctx, "Click an item above", x0, top + 110, WHITE);
            if (all.isEmpty()) txt(ctx, "Nothing here can be enchanted", left + 10, top + 60, GREY);
            return;
        }

        if (all.isEmpty()) txt(ctx, "No enchants fit this item", left + 10, top + 60, GREY);
        else if (shown.isEmpty()) txt(ctx, "No match", left + 10, top + 60, GREY);

        if (sel == null) {
            txt(ctx, field_22793.method_27523(st.method_7964().getString(), 190), x0, top + 104, WHITE);
            txt(ctx, "Pick an enchant on the left", x0, top + 116, CYAN);
            txt(ctx, "or press MAX ALL", x0, top + 128, GREY);
        } else {
            txt(ctx, field_22793.method_27523(sel.name + " " + roman(lvl) + "  ->  " + st.method_7964().getString(), 190), x0, top + 104, CYAN);
            int h = have(sel);
            txt(ctx, "On item: " + (h > 0 ? roman(h) : "-") + "    Max: " + roman(sel.max), x0, top + 116, GREY);
            if (h < lvl) {
                long c = price(lvl);
                boolean ok = c <= ClientEmc.balance;
                txt(ctx, "Price: " + Fx.num(c) + " EMC", x0, top + 174, ok ? 0xFFE0B040 : 0xFFFF7070);
                txt(ctx, "After: " + Fx.num(ClientEmc.balance - c), x0 + 110, top + 174, ok ? GREY : 0xFFFF7070);
            }
        }
        int pages = Math.max(1, (shown.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 56, top + 212, GREY);
    }
}

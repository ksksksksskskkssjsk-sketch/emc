package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;
import net.minecraft.class_7919;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import java.util.ArrayList;
import java.util.List;

/**
 * Enchant the item in your hand. Every enchant is one row: click its name for the next level,
 * or click a level chip (I, II, III...) to pick that level directly. The big button shows the price.
 * Enchants that clash with something already on the item are greyed out and say why.
 */
public class EnchantScreen extends ServiceScreen {
    private record Row(class_6880<class_1887> e, String id, String name, int max, String conflict) {}

    private static final int PER = 6, ROW_H = 21, LIST_Y = 52, MAX_CHIPS = 7;
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII"};

    private final boolean standalone;
    private final List<Row> rows = new ArrayList<>();
    private class_1799 last = class_1799.field_8037;
    private int page = 0, lvl = 1;
    private Row sel;
    private GlowButton apply;
    private boolean synced = false;

    public EnchantScreen() { this(false); }

    public EnchantScreen(boolean standalone) {
        super("ENCHANT HELD ITEM");
        this.standalone = standalone;
        W = 300;
        H = 220;
        accent = Fx.PURPLE;
    }

    private static String roman(int k) { return k < ROMAN.length ? ROMAN[k] : String.valueOf(k); }

    private class_1799 held() {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
    }

    private void rebuild() {
        rows.clear();
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        class_1799 st = held();
        last = st.method_7972();
        if (!st.method_7960()) {
            var reg = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
            class_9304 cur = class_1890.method_57532(st);
            reg.method_42017().forEach(ref -> {
                class_1887 en = ref.comp_349();
                if (!en.method_8192(st)) return;
                String conflict = null;
                for (class_6880<class_1887> o : cur.method_57534()) {
                    if (!o.equals(ref) && !class_1887.method_60033(ref, o)) { conflict = o.comp_349().comp_2686().getString(); break; }
                }
                rows.add(new Row(ref, ref.method_40237().method_29177().toString(), en.comp_2686().getString(), en.method_8183(), conflict));
            });
            rows.sort((a, b) -> {
                int ca = a.conflict == null ? 0 : 1, cb = b.conflict == null ? 0 : 1;
                return ca != cb ? ca - cb : a.name.compareToIgnoreCase(b.name);
            });
        }
        if (sel != null) {
            Row keep = null;
            for (Row r : rows) if (r.id.equals(sel.id)) keep = r;
            sel = keep;
        }
        if (sel != null) {
            lvl = Math.max(1, Math.min(sel.max, lvl));
            if (have(sel) >= lvl) lvl = Math.min(sel.max, have(sel) + 1);
        }
        page = Math.max(0, Math.min(page, (Math.max(1, rows.size()) - 1) / PER));
    }

    private int have(Row r) {
        class_1799 st = held();
        return st.method_7960() ? 0 : class_1890.method_8225(r.e, st);
    }

    private long cost() { return sel == null ? 0 : Math.max(0, Fees.enchant(lvl) - Fees.enchant(have(sel))); }

    private void choose(Row r, int level) {
        sel = r;
        lvl = level;
        method_41843();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); } // sync EMC balance
        rebuild();

        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= rows.size()) break;
            final Row r = rows.get(idx);
            final int h = have(r);
            final int y = top + LIST_Y + i * ROW_H;
            boolean blocked = r.conflict != null;
            boolean isSel = sel != null && sel.id.equals(r.id);

            String label = field_22793.method_27523(r.name, 112);
            GlowButton nb = GlowButton.of(label, left + 8, y, 120, 18, b -> choose(r, Math.max(1, Math.min(r.max, h + 1))));
            nb.accent = Fx.PURPLE;
            nb.selected = isSel;
            nb.field_22763 = !blocked && h < r.max;
            if (blocked) nb.method_47400(class_7919.method_47407(class_2561.method_43470("Conflicts with " + r.conflict)));
            else if (h >= r.max) nb.method_47400(class_7919.method_47407(class_2561.method_43470("Already at max level")));
            method_37063(nb);

            int chips = Math.min(r.max, MAX_CHIPS);
            for (int k = 1; k <= chips; k++) {
                final int level = k;
                GlowButton c = GlowButton.of(roman(k), left + 134 + (k - 1) * 23, y, 21, 18, b -> choose(r, level));
                long price = Math.max(0, Fees.enchant(k) - Fees.enchant(h));
                boolean owned = k <= h;
                c.accent = owned ? Fx.GREEN : price <= ClientEmc.balance ? Fx.PURPLE : Fx.RED;
                c.selected = isSel && lvl == k;
                c.field_22763 = !blocked && !owned;
                if (blocked) c.method_47400(class_7919.method_47407(class_2561.method_43470("Conflicts with " + r.conflict)));
                else if (owned) c.method_47400(class_7919.method_47407(class_2561.method_43470("Already on the item")));
                else c.method_47400(class_7919.method_47407(class_2561.method_43470(r.name + " " + roman(k) + "\n" + Fx.num(price) + " EMC")));
                method_37063(c);
            }
        }

        int by = top + 190;
        method_37063(GlowButton.of("<", left + 8, by, 20, 18, b -> { if (page > 0) { page--; method_41843(); } }));
        method_37063(GlowButton.of(">", left + 32, by, 20, 18, b -> { if ((page + 1) * PER < rows.size()) { page++; method_41843(); } }));
        GlowButton back = GlowButton.of(standalone ? "Close" : "Back", left + 84, by, 56, 18,
                b -> class_310.method_1551().method_1507(standalone ? null : new ServicesScreen()));
        back.accent = Fx.GOLD;
        method_37063(back);
        apply = GlowButton.of("", left + 146, by, 146, 18, b -> { if (sel != null) ClientPlayNetworking.send(new ActionPayload(7, sel.id, lvl)); });
        apply.accent = Fx.PURPLE;
        method_37063(apply);
        syncApply();
    }

    private void syncApply() {
        if (apply == null) return;
        if (sel == null) { apply.method_25355(class_2561.method_43470("Pick an enchant")); apply.field_22763 = false; return; }
        if (have(sel) >= lvl) { apply.method_25355(class_2561.method_43470("Already has it")); apply.field_22763 = false; return; }
        long c = cost();
        if (c > ClientEmc.balance) { apply.method_25355(class_2561.method_43470("Need " + Fx.num(c) + " EMC")); apply.field_22763 = false; return; }
        apply.method_25355(class_2561.method_43470("Enchant  " + Fx.num(c) + " EMC"));
        apply.field_22763 = true;
    }

    @Override
    public void method_25393() {
        if (!class_1799.method_7973(last, held())) method_41843();
        else syncApply();
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        class_1799 st = held();
        if (st.method_7960()) {
            txt(ctx, "Hold the item you want to enchant", left + 8, top + 28, GREY);
            return;
        }
        Fx.showcase(ctx, st, left + 20, top + 36, 1.0f, Fx.PURPLE);
        txt(ctx, field_22793.method_27523(st.method_7964().getString(), 120), left + 38, top + 26, WHITE);
        txt(ctx, "Click a name or a level", left + 38, top + 38, GREY);
        if (sel != null) {
            txt(ctx, field_22793.method_27523(sel.name + " " + roman(lvl), 140), left + 156, top + 26, CYAN);
            txt(ctx, "Has " + have(sel) + " / " + sel.max, left + 156, top + 38, GREY);
        }
        if (rows.isEmpty()) { txt(ctx, "No enchants fit this item", left + 10, top + 80, GREY); return; }
        int pages = Math.max(1, (rows.size() + PER - 1) / PER);
        txt(ctx, (page + 1) + "/" + pages, left + 58, top + 195, GREY);
    }
}

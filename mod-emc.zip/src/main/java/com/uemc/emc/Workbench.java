package com.uemc.emc;

import com.google.gson.*;
import com.uemc.UniversalEmc;
import com.uemc.net.WorkbenchPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3298;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.server.MinecraftServer;
import java.io.Reader;
import java.util.*;

/**
 * Click-style workstations (no slots): crafting, stonecutter, grindstone (disenchant).
 * Recipes come from the same recipe JSONs RecipeEmc reads, so datapack/mod recipes work too.
 * Everything is validated here; the client only displays.
 */
public final class Workbench {
    private Workbench() {}

    public static final int CRAFT = 0, STONECUT = 2, GRIND = 3, ENCHANT = 5;

    /** true: the converter's "Enchanting" button opens the pick-your-enchant screen (costs EMC). false: vanilla table. */
    public static final boolean CONVERTER_CUSTOM_ENCHANT = true;

    public record Need(Set<class_2960> options, int qty) {}
    public record Rec(String id, int kind, class_1792 out, int count, List<Need> needs) {}

    private static MinecraftServer SERVER;
    private static List<Rec> RECIPES;
    private static Map<String, Rec> BY_ID;
    /** Which workstation each player opened last (set when it opens, required to craft/disenchant). */
    private static final Map<UUID, Integer> SESSION = new HashMap<>();

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> { SERVER = s; RECIPES = null; BY_ID = null; });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> { SERVER = null; RECIPES = null; BY_ID = null; SESSION.clear(); });
    }

    private static void msg(class_3222 p, String s) { p.method_7353(class_2561.method_43470(s), true); }

    // ---------- opening ----------
    public static void open(class_3222 p, int which) {
        SESSION.put(p.method_5667(), which);
        ServerPlayNetworking.send(p, payload(which));
    }

    private static WorkbenchPayload payload(int which) {
        List<String> sets = new ArrayList<>(), recs = new ArrayList<>();
        if (which == CRAFT || which == STONECUT) {
            ensure();
            Map<String, Integer> idx = new HashMap<>();
            if (RECIPES != null) for (Rec r : RECIPES) {
                if (r.kind() != which) continue;
                StringBuilder sb = new StringBuilder();
                sb.append(r.id()).append('|').append(class_7923.field_41178.method_10221(r.out())).append('|').append(r.count()).append('|');
                boolean first = true;
                for (Need n : r.needs()) {
                    StringBuilder o = new StringBuilder();
                    for (class_2960 id : n.options()) { if (o.length() > 0) o.append(','); o.append(id); }
                    String key = o.toString();
                    Integer i = idx.get(key);
                    if (i == null) { i = sets.size(); sets.add(key); idx.put(key, i); }
                    if (!first) sb.append(';');
                    sb.append(i).append(':').append(n.qty());
                    first = false;
                }
                recs.add(sb.toString());
            }
        }
        return new WorkbenchPayload(which, sets, recs);
    }

    // ---------- recipe loading ----------
    private static synchronized void ensure() {
        if (RECIPES != null || SERVER == null) return;
        List<Rec> out = new ArrayList<>();
        var found = SERVER.method_34864().method_14488("recipe", id -> id.method_12832().endsWith(".json"));
        for (Map.Entry<class_2960, class_3298> e : found.entrySet()) {
            try (Reader r = e.getValue().method_43039()) {
                JsonElement el = JsonParser.parseReader(r);
                if (el.isJsonObject()) parse(cleanId(e.getKey().toString()), el.getAsJsonObject(), out);
            } catch (Exception ex) {
                UniversalEmc.LOG.debug("Workbench skipped recipe {}: {}", e.getKey(), ex.toString());
            }
        }
        out.sort(Comparator.comparing(Rec::id));
        Map<String, Rec> map = new HashMap<>();
        for (Rec r : out) map.put(r.id(), r);
        BY_ID = map;
        RECIPES = out;
        UniversalEmc.LOG.info("Workbench recipes: {}", out.size());
    }

    private static String cleanId(String s) {
        s = s.replace(":recipe/", ":");
        return s.endsWith(".json") ? s.substring(0, s.length() - 5) : s;
    }

    private static void parse(String id, JsonObject o, List<Rec> out) {
        if (!o.has("type")) return;
        String type = o.get("type").getAsString().replace("minecraft:", "");
        List<Set<class_2960>> ings = new ArrayList<>();
        int kind = -1;
        switch (type) {
            case "crafting_shaped" -> {
                kind = CRAFT;
                Map<String, Set<class_2960>> k = new HashMap<>();
                for (var e : o.getAsJsonObject("key").entrySet()) k.put(e.getKey(), ing(e.getValue()));
                for (JsonElement row : o.getAsJsonArray("pattern"))
                    for (char c : row.getAsString().toCharArray()) {
                        if (c == ' ') continue;
                        Set<class_2960> x = k.get(String.valueOf(c));
                        if (x == null) return;
                        ings.add(x);
                    }
            }
            case "crafting_shapeless" -> {
                kind = CRAFT;
                for (JsonElement i : o.getAsJsonArray("ingredients")) ings.add(ing(i));
            }
            case "crafting_transmute" -> {
                kind = CRAFT;
                ings.add(ing(o.get("input")));
                ings.add(ing(o.get("material")));
            }
            case "stonecutting" -> {
                kind = STONECUT;
                ings.add(ing(o.get("ingredient")));
            }
            default -> { }
        }
        if (kind < 0 || ings.isEmpty()) return;
        for (Set<class_2960> s : ings) if (s.isEmpty()) return;

        JsonElement res = o.get("result");
        if (res == null) return;
        String rid; int count = 1;
        if (res.isJsonPrimitive()) {
            rid = res.getAsString();
            if (o.has("count")) count = Math.max(1, o.get("count").getAsInt());
        } else {
            JsonObject r = res.getAsJsonObject();
            rid = r.has("id") ? r.get("id").getAsString() : r.get("item").getAsString();
            if (r.has("count")) count = Math.max(1, r.get("count").getAsInt());
        }
        class_2960 oid = class_2960.method_60654(rid);
        if (!class_7923.field_41178.method_10250(oid)) return;

        Map<String, Set<class_2960>> opt = new LinkedHashMap<>();
        Map<String, int[]> qty = new LinkedHashMap<>();
        for (Set<class_2960> s : ings) {
            String key = s.toString();
            opt.putIfAbsent(key, s);
            qty.computeIfAbsent(key, x -> new int[1])[0]++;
        }
        List<Need> needs = new ArrayList<>();
        for (var e : opt.entrySet()) needs.add(new Need(e.getValue(), qty.get(e.getKey())[0]));
        out.add(new Rec(id, kind, class_7923.field_41178.method_63535(oid), count, needs));
    }

    /** Ingredient -> candidate item ids (string, "#tag", array, or legacy {item}/{tag}). */
    private static Set<class_2960> ing(JsonElement e) {
        Set<class_2960> res = new LinkedHashSet<>();
        if (e == null) return res;
        if (e.isJsonArray()) { for (JsonElement x : e.getAsJsonArray()) res.addAll(ing(x)); return res; }
        String s;
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("item")) s = o.get("item").getAsString();
            else if (o.has("tag")) s = "#" + o.get("tag").getAsString();
            else return res;
        } else s = e.getAsString();
        if (s.startsWith("#")) {
            class_6862<class_1792> tag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60654(s.substring(1)));
            for (class_6880<class_1792> en : class_7923.field_41178.method_40286(tag)) res.add(class_7923.field_41178.method_10221(en.comp_349()));
        } else {
            class_2960 id = class_2960.method_60654(s);
            if (class_7923.field_41178.method_10250(id)) res.add(id);
        }
        return res;
    }

    // ---------- crafting ----------
    /** times <= 0 means "as many as possible". */
    public static void craft(class_3222 p, String recipeId, int times) {
        ensure();
        Rec r = BY_ID == null ? null : BY_ID.get(recipeId);
        Integer sess = SESSION.get(p.method_5667());
        if (r == null || sess == null || sess != r.kind()) { msg(p, "Open the workstation first"); return; }
        int max = times <= 0 ? 1000 : Math.min(times, 1000);
        int crafted = 0;
        long outTotal = 0;
        List<class_1792> back = new ArrayList<>();
        while (crafted < max && outTotal + r.count() <= 2304) {
            if (!consume(p, r, back)) break;
            crafted++;
            outTotal += r.count();
        }
        if (crafted == 0) { msg(p, "Missing ingredients"); return; }
        give(p, r.out(), (int) outTotal);
        for (class_1792 b : back) give(p, b, 1);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.5f, 1.5f);
        msg(p, "Crafted " + outTotal + " " + new class_1799(r.out()).method_7964().getString());
    }

    private static boolean consume(class_3222 p, Rec r, List<class_1792> back) {
        var inv = p.method_31548();
        int[] left = new int[36];
        class_2960[] ids = new class_2960[36];
        for (int i = 0; i < 36; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7960()) continue;
            left[i] = s.method_7947();
            ids[i] = class_7923.field_41178.method_10221(s.method_7909());
        }
        int[] take = new int[36];
        for (Need n : r.needs()) {
            int rem = n.qty();
            for (int i = 0; i < 36 && rem > 0; i++) {
                if (left[i] > 0 && n.options().contains(ids[i])) {
                    int t = Math.min(left[i], rem);
                    left[i] -= t; take[i] += t; rem -= t;
                }
            }
            if (rem > 0) return false;
        }
        for (int i = 0; i < 36; i++) {
            if (take[i] <= 0) continue;
            class_1799 s = inv.method_5438(i);
            class_1792 rest = remainder(s.method_7909());
            s.method_7934(take[i]);
            if (rest != null) for (int k = 0; k < take[i]; k++) back.add(rest);
        }
        return true;
    }

    /** Container items that come back after crafting (milk bucket in a cake, etc). */
    private static class_1792 remainder(class_1792 it) {
        String path = class_7923.field_41178.method_10221(it).method_12832();
        String back = switch (path) {
            case "milk_bucket", "water_bucket", "lava_bucket" -> "minecraft:bucket";
            case "honey_bottle" -> "minecraft:glass_bottle";
            default -> null;
        };
        return back == null ? null : class_7923.field_41178.method_63535(class_2960.method_60654(back));
    }

    private static void give(class_3222 p, class_1792 item, int total) {
        int left = total;
        while (left > 0) {
            int n = Math.min(left, item.method_7882());
            class_1799 st = new class_1799(item, n);
            p.method_31548().method_7394(st);
            if (!st.method_7960()) p.method_7328(st, false);
            left -= n;
        }
    }

    // ---------- grindstone: strip non-curse enchants from the held item, get a little XP ----------
    public static final int XP_PER_LEVEL = 4;

    public static void disenchant(class_3222 p) {
        Integer sess = SESSION.get(p.method_5667());
        if (sess == null || sess != GRIND) { msg(p, "Open the grindstone first"); return; }
        class_1799 st = p.method_6047();
        if (st.method_7960()) { msg(p, "Hold an enchanted item"); return; }
        var reg = SERVER.method_30611().method_30530(class_7924.field_41265);
        class_9304 cur = class_1890.method_57532(st);
        List<class_6880<class_1887>> remove = new ArrayList<>();
        int xp = 0;
        for (class_6880<class_1887> e : cur.method_57534()) {
            class_2960 id = reg.method_10221(e.comp_349());
            if (id != null && id.method_12832().endsWith("_curse")) continue;
            remove.add(e);
            xp += XP_PER_LEVEL * cur.method_57536(e);
        }
        if (remove.isEmpty()) { msg(p, "Nothing to remove (curses stay)"); return; }
        class_1890.method_57531(st, b -> { for (class_6880<class_1887> e : remove) b.method_57547(e, 0); });
        EmcLogic.addXp(p, xp);
        p.method_5783(com.uemc.ModSounds.EMC_TRANSACT, 0.6f, 0.8f);
        msg(p, "Disenchanted, +" + xp + " XP");
    }
}

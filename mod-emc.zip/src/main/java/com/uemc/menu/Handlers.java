package com.uemc.menu;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1714;
import net.minecraft.class_1718;
import net.minecraft.class_3803;
import net.minecraft.class_3914;
import net.minecraft.class_3971;
import net.minecraft.class_4862;
import net.minecraft.screen.*;

/** Vanilla workstation handlers whose canUse doesn't depend on the block being a vanilla workstation. */
public final class Handlers {
    private Handlers() {}

    public static class Craft extends class_1714 {
        public Craft(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
    public static class Enchant extends class_1718 {
        public Enchant(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
    public static class Anvil extends class_1706 {
        public Anvil(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
    public static class Stonecut extends class_3971 {
        public Stonecut(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
    public static class Grind extends class_3803 {
        public Grind(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
    public static class Smith extends class_4862 {
        public Smith(int id, class_1661 inv, class_3914 c) { super(id, inv, c); }
        @Override public boolean method_7597(class_1657 p) { return true; }
    }
}

package com.uemc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.uemc.emc.*;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2287;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class EmcCommands {
    private EmcCommands() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((d, access, env) -> d.register(
            class_2170.method_9247("emc")
                .then(class_2170.method_9247("balance").executes(c -> {
                    class_1657 p = c.getSource().method_9207();
                    msg(p, "EMC: " + EmcData.get(p.method_5667()).emc + " | Discovered: " + EmcData.get(p.method_5667()).discovered.size());
                    return 1;
                }))
                .then(class_2170.method_9247("convert").executes(c -> {
                    class_1657 p = c.getSource().method_9207();
                    class_1799 s = p.method_6047();
                    long g = EmcLogic.convert(p, s);
                    msg(p, g > 0 ? "+" + g + " EMC" : "Item has no EMC value");
                    return 1;
                }))
                .then(class_2170.method_9247("give")
                    .then(class_2170.method_9244("item", class_2287.method_9776(access))
                        .executes(c -> give(c, 1))
                        .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, 2304))
                            .executes(c -> give(c, IntegerArgumentType.getInteger(c, "count"))))))
                .then(class_2170.method_9247("sellall").executes(c -> {
                    class_1657 p = c.getSource().method_9207();
                    long g = EmcLogic.sellAll(p);
                    msg(p, g > 0 ? "Sold everything: +" + g + " EMC" : "Nothing to sell");
                    return 1;
                }))
                .then(class_2170.method_9247("sellxp").executes(c -> {
                    class_1657 p = c.getSource().method_9207();
                    long g = EmcLogic.sellXp(p, 0);
                    msg(p, g > 0 ? "Sold XP: +" + g + " EMC" : "No XP to sell");
                    return 1;
                }))
                .then(class_2170.method_9247("buyxp")
                    .then(class_2170.method_9244("levels", IntegerArgumentType.integer(1, 100)).executes(c -> {
                        class_1657 p = c.getSource().method_9207();
                        String err = EmcLogic.buyXp(p, IntegerArgumentType.getInteger(c, "levels"));
                        msg(p, err == null ? "Bought XP levels" : err);
                        return err == null ? 1 : 0;
                    })))
                .then(class_2170.method_9247("list").executes(c -> {
                    class_1657 p = c.getSource().method_9207();
                    var set = EmcData.get(p.method_5667()).discovered;
                    msg(p, set.isEmpty() ? "Nothing discovered" : String.join(", ", set.stream().map(Object::toString).sorted().toList()));
                    return 1;
                }))
        ));
    }

    private static int give(com.mojang.brigadier.context.CommandContext<net.minecraft.class_2168> c, int n) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_1657 p = c.getSource().method_9207();
        class_1792 item = class_2287.method_9777(c, "item").method_9785();
        String err = EmcLogic.buy(p, item, n);
        msg(p, err == null ? "Got " + n + "x " + class_7923.field_41178.method_10221(item) : err);
        return err == null ? 1 : 0;
    }

    private static void msg(class_1657 p, String s) { p.method_7353(class_2561.method_43470(s), false); }
}

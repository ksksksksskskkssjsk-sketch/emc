package com.uemc.emc;

import com.google.gson.*;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import com.uemc.UniversalEmc;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Central EMC values. Defaults + config/uemc_values.json overrides. Value 0 = excluded. */
public final class EmcRegistry {
    private static final Map<class_2960, Long> VALUES = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private EmcRegistry() {}

    public static void load(MinecraftServer server) {
        VALUES.clear();
        java.util.Set<class_2960> locked = new java.util.HashSet<>();
        try (var in = EmcRegistry.class.getResourceAsStream("/data/uemc/base_values.json")) {
            JsonObject o = JsonParser.parseReader(new java.io.InputStreamReader(in)).getAsJsonObject();
            for (var e : o.entrySet()) { class_2960 id = class_2960.method_60654(e.getKey()); VALUES.put(id, e.getValue().getAsLong()); locked.add(id); }
        } catch (Exception ex) {
            UniversalEmc.LOG.error("Failed reading base_values.json", ex);
        }
        Path file = server.method_3758("config").resolve("uemc_values.json");
        try {
            if (!Files.exists(file)) {
                Files.createDirectories(file.getParent());
                JsonObject o = new JsonObject();
                o.addProperty("_comment", "Overrides. \"minecraft:diamond\": 5000. Set 0 to exclude an item.");
                Files.writeString(file, GSON.toJson(o));
            } else {
                JsonObject o = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
                for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                    if (e.getKey().startsWith("_")) continue;
                    class_2960 id = class_2960.method_60654(e.getKey());
                    VALUES.put(id, Math.max(0, e.getValue().getAsLong()));
                    locked.add(id);
                }
            }
        } catch (IOException | RuntimeException ex) {
            UniversalEmc.LOG.error("Failed reading EMC config", ex);
        }
        RecipeEmc.compute(server, VALUES, locked);
        VALUES.values().removeIf(v -> v <= 0);
        VALUES.remove(class_2960.method_60655(UniversalEmc.ID, "emc_tablet"));   // the tablet is never for sale, whatever the recipe/config says
    }

    public static long get(class_1792 item) {
        return VALUES.getOrDefault(class_7923.field_41178.method_10221(item), 0L);
    }

    public static Map<class_2960, Long> all() { return Collections.unmodifiableMap(VALUES); }

    public static boolean hasValue(class_1792 item) { return get(item) > 0; }
    public static int size() { return VALUES.size(); }
}

package com.uemc.client;

import com.uemc.emc.Fees;
import com.uemc.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7919;

/**
 * Repair, used like an anvil.
 *   RIGHT: click any damaged item in your inventory / armor / offhand (no need to hold it). It goes in the left slot.
 *   LEFT : the result slot shows the repaired item and the price. Click it (or the big button) to take it.
 *   REPAIR ALL fixes everything damaged at once. The server re-checks item and EMC.
 */
public class RepairScreen extends ServiceScreen {
    private static final int N = 41;   // 36 inventory + 4 armor + offhand

    private final Runnable back;
    private final GlowButton[] cell = new GlowButton[N];
    private final class_1799[] snap = new class_1799[N];
    private final boolean[] dmg = new boolean[N];
    private GlowButton in, out, repair, all;
    private int slot = -1, allCount = 0;
    private long allFee = 0, lastBal = Long.MIN_VALUE;
    private boolean synced = false, picked = false;

    public RepairScreen(Runnable back) {
        super("REPAIR");
        this.back = back;
        W = 330;
        H = 184;
        accent = Fx.GREEN;
        for (int i = 0; i < N; i++) snap[i] = class_1799.field_8037;
    }

    private static String shortNum(long v) {
        if (v >= 10_000_000) return (v / 1_000_000) + "M";
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000.0);
        if (v >= 10_000) return (v / 1000) + "k";
        return String.valueOf(v);
    }

    private int rx() { return left + 154; }
    private int cellX(int s) { return s >= 36 ? rx() + (s - 36) * 18 : rx() + (s % 9) * 18; }
    private int cellY(int s) { return s >= 36 ? top + 30 : s < 9 ? top + 112 : top + 54 + ((s - 9) / 9) * 18; }

    private class_1799 stack(int s) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || s < 0) return class_1799.field_8037;
        var inv = mc.field_1724.method_31548();
        return s >= inv.method_5439() ? class_1799.field_8037 : inv.method_5438(s);
    }

    private static boolean damaged(class_1799 st) { return !st.method_7960() && st.method_7963() && st.method_7919() > 0; }

    private class_1799 item() { return slot < 0 ? class_1799.field_8037 : snap[slot]; }

    private long fee(class_1799 st) { return damaged(st) ? Fees.repairFee(st.method_7919()) : 0; }

    private void scan() {
        allCount = 0;
        allFee = 0;
        for (int i = 0; i < N; i++) {
            snap[i] = stack(i).method_7972();
            dmg[i] = damaged(snap[i]);
            if (dmg[i]) { allCount++; allFee += fee(snap[i]); }
        }
        if (!picked) {
            picked = true;
            class_310 mc = class_310.method_1551();
            class_1799 held = mc.field_1724 == null ? class_1799.field_8037 : mc.field_1724.method_6047();
            for (int i = 0; i < N && slot < 0; i++) if (dmg[i] && !held.method_7960() && stack(i) == held) slot = i;
            for (int i = 0; i < N && slot < 0; i++) if (dmg[i]) slot = i;
        }
        if (slot >= 0 && !dmg[slot]) slot = -1;
    }

    private boolean inventoryChanged() {
        for (int i = 0; i < N; i++) if (!class_1799.method_7973(snap[i], stack(i))) return true;
        return false;
    }

    private static void tip(GlowButton b, String s) {
        b.method_47400(s == null ? null : class_7919.method_47407(class_2561.method_43470(s)));
    }

    private void take() {
        if (slot >= 0 && fee(item()) <= ClientEmc.balance) ClientPlayNetworking.send(new ActionPayload(19, "", slot));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!synced) { synced = true; ClientPlayNetworking.send(new ActionPayload(11, "", 0)); }   // sync EMC balance

        for (int s = 0; s < N; s++) {
            final int sl = s;
            cell[s] = GlowButton.slot(cellX(s), cellY(s), b -> { if (dmg[sl]) { slot = sl; refresh(); } });
            cell[s].accent = Fx.GREEN;
            method_37063(cell[s]);
        }

        in = GlowButton.of("", left + 22, top + 44, 28, 28, b -> { slot = -1; refresh(); });
        in.cell = true;
        in.accent = Fx.GREEN;
        method_37063(in);

        out = GlowButton.of("", left + 100, top + 44, 28, 28, b -> take());
        out.cell = true;
        out.accent = Fx.GOLD;
        method_37063(out);

        repair = GlowButton.of("", left + 10, top + 130, 134, 22, b -> take());
        repair.accent = Fx.GREEN;
        method_37063(repair);

        all = GlowButton.of("", rx(), top + 140, 162, 22, b -> { if (allCount > 0) ClientPlayNetworking.send(new ActionPayload(20, "", 0)); });
        all.accent = Fx.GOLD;
        method_37063(all);

        GlowButton close = GlowButton.of("Back", left + 10, top + 160, 134, 16, b -> back.run());
        close.accent = Fx.GOLD;
        method_37063(close);

        scan();
        refresh();
    }

    private void refresh() {
        if (all == null) return;
        lastBal = ClientEmc.balance;

        for (int s = 0; s < N; s++) {
            class_1799 st = snap[s];
            cell[s].field_22763 = dmg[s];
            cell[s].selected = s == slot;
            tip(cell[s], st.method_7960() ? null : st.method_7964().getString()
                    + (dmg[s] ? "\nRepair: " + Fx.num(fee(st)) + " EMC" : "\nNot damaged"));
        }

        class_1799 st = item();
        tip(in, st.method_7960() ? "Click a damaged item on the right" : "Click to take it out");
        long c = fee(st);
        boolean ok = slot >= 0 && c <= ClientEmc.balance;
        out.field_22763 = ok;
        tip(out, slot < 0 ? null : ok ? "Click to repair  (" + Fx.num(c) + " EMC)" : "Need " + Fx.num(c) + " EMC");

        if (slot < 0) { repair.method_25355(class_2561.method_43470("Pick an item")); repair.field_22763 = false; }
        else if (!ok) { repair.method_25355(class_2561.method_43470("Need " + Fx.num(c) + " EMC")); repair.field_22763 = false; repair.accent = Fx.RED; }
        else { repair.method_25355(class_2561.method_43470("REPAIR  " + Fx.num(c) + " EMC")); repair.field_22763 = true; repair.accent = Fx.GREEN; }

        if (allCount == 0) {
            all.method_25355(class_2561.method_43470("Nothing to repair"));
            all.field_22763 = false;
            tip(all, null);
        } else {
            boolean aok = allFee <= ClientEmc.balance;
            all.method_25355(class_2561.method_43470("REPAIR ALL (" + allCount + ")  " + shortNum(allFee)));
            all.field_22763 = aok;
            all.accent = aok ? Fx.GOLD : Fx.RED;
            tip(all, "Repair every damaged item you carry\n" + Fx.num(allFee) + " EMC" + (aok ? "" : "  (not enough)"));
        }
    }

    @Override
    public void method_25393() {
        boolean changed = inventoryChanged();
        if (changed) scan();
        if (changed || ClientEmc.balance != lastBal) refresh();
    }

    private static float frac(class_1799 st) {
        int max = st.method_7936();
        return max <= 0 ? 1f : Math.max(0f, 1f - st.method_7919() / (float) max);
    }

    @Override
    protected void drawContent(class_332 ctx, int mx, int my, float delta) {
        ctx.method_25294(left + 150, top + 24, left + 151, top + H - 8, Fx.argb(110, Fx.GREEN));

        // inventory picker
        for (int s = 0; s < N; s++) {
            class_1799 st = snap[s];
            if (st.method_7960()) continue;
            int x = cellX(s) + 1, y = cellY(s) + 1;
            Fx.item(ctx, st, x, y, cell[s] != null && cell[s].method_49606() && dmg[s], s == slot, 1f, Fx.GREEN);
            if (!dmg[s]) ctx.method_25294(x, y, x + 16, y + 16, 0xA0000000);
            else Fx.bar(ctx, x, y + 14, 16, 2, frac(st), Fx.mix(Fx.RED, Fx.GREEN, frac(st)));
        }

        class_1799 st = item();
        txt(ctx, "PUT IN", left + 14, top + 30, 0xFF7A8A99);
        txt(ctx, "RESULT", left + 94, top + 30, 0xFF7A8A99);
        txt(ctx, ">>", left + 64, top + 54, Fx.argb(255, Fx.mix(Fx.GREEN, Fx.WHITE, 0.5f + 0.5f * Fx.sin(Fx.t() * 5f))));

        if (slot < 0 || st.method_7960()) {
            txt(ctx, allCount == 0 ? "Nothing is damaged" : "Click a damaged item", left + 10, top + 84, allCount == 0 ? GREY : CYAN);
            txt(ctx, allCount == 0 ? "" : "on the right", left + 10, top + 96, GREY);
            return;
        }

        Fx.itemScaled(ctx, st, left + 36, top + 58, 1.5f);
        class_1799 res = st.method_7972();
        res.method_7974(0);
        Fx.itemScaled(ctx, res, left + 114, top + 58, 1.5f);
        Fx.sparkle(ctx, left + 124, top + 48, 3, Fx.WHITE, 0.5f + 0.5f * Fx.sin(Fx.t() * 7f));

        int max = st.method_7936();
        txt(ctx, field_22793.method_27523(st.method_7964().getString(), 134), left + 10, top + 78, WHITE);
        Fx.bar(ctx, left + 10, top + 90, 134, 5, frac(st), Fx.mix(Fx.RED, Fx.GREEN, frac(st)));
        txt(ctx, "Durability " + (max - st.method_7919()) + " / " + max, left + 10, top + 99, GREY);
        long c = fee(st);
        boolean ok = c <= ClientEmc.balance;
        txt(ctx, "Price: " + Fx.num(c) + " EMC", left + 10, top + 111, ok ? 0xFFE0B040 : 0xFFFF7070);
        if (ok) txt(ctx, "After: " + Fx.num(ClientEmc.balance - c), left + 10, top + 120, GREY);
    }
}

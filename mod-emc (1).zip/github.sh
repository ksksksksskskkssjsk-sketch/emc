#!/usr/bin/env bash
# Puts this project on GitHub. GitHub Actions then builds the jar for you (Actions tab -> newest run -> Artifacts, or the Releases tab).
#   ./github.sh yourname/universal-emc            private repo (default)
#   ./github.sh yourname/universal-emc --public   public repo
#   ./github.sh https://github.com/yourname/universal-emc.git   push to a repo you already created
set -euo pipefail
cd "$(dirname "$0")"

REPO="${1:-}"
VIS="--private"; [ "${2:-}" = "--public" ] && VIS="--public"
if [ -z "$REPO" ]; then read -rp "GitHub repo (owner/name, e.g. yourname/universal-emc): " REPO; fi
[ -n "$REPO" ] || { echo "No repo given"; exit 1; }
command -v git >/dev/null 2>&1 || { echo "Install git first: https://git-scm.com"; exit 1; }

if [ -z "$(git config user.name || true)" ] || [ -z "$(git config user.email || true)" ]; then
  echo "Tell git who you are first (once):"
  echo '  git config --global user.name  "Your Name"'
  echo '  git config --global user.email "you@example.com"'
  exit 1
fi

[ -d .git ] || git init -q -b main
git add -A
if git diff --cached --quiet; then echo "Nothing new to commit"; else git commit -q -m "Universal EMC $(grep '^mod_version' gradle.properties | cut -d= -f2)"; fi
git branch -M main

case "$REPO" in
  *://*|git@*|/*|./*|../*) URL="$REPO"; SLUG="" ;;
  *) URL="https://github.com/$REPO.git"; SLUG="$REPO" ;;
esac

if [ -n "$SLUG" ] && ! git remote get-url origin >/dev/null 2>&1 \
   && command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
  echo "==> Creating $SLUG ($VIS) with the GitHub CLI and pushing"
  gh repo create "$SLUG" "$VIS" --source=. --remote=origin --push
else
  if git remote get-url origin >/dev/null 2>&1; then git remote set-url origin "$URL"; else git remote add origin "$URL"; fi
  echo "==> Pushing to $URL"
  if ! git push -u origin main; then
    echo
    echo "Push failed. Fix one of these, then run this script again:"
    echo "  1. Create an EMPTY repo at https://github.com/new (no README), name: ${SLUG##*/}"
    echo "  2. Log in:  gh auth login      (or use a Personal Access Token with 'repo' scope as the password)"
    exit 1
  fi
fi

if [ -n "$SLUG" ]; then
  echo
  echo "Pushed. The build starts now:"
  echo "  https://github.com/$SLUG/actions"
  echo "When it is green, the jar is under:"
  echo "  https://github.com/$SLUG/releases"
fi

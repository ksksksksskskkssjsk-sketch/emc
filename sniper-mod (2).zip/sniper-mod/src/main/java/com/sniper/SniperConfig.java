package com.sniper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Editable at config/sniper.json (restart the game / server after changes). */
public class SniperConfig {
    public float bodyDamage = 20.0f;        // 10 hearts
    public float headDamage = 40.0f;        // 20 hearts
    public int cooldownTicks = 40;          // 20 ticks = 1 second
    public double baseSpeed = 8.0;          // bullet speed, blocks per tick
    public float gravity = 0.02f;           // bullet drop, blocks per tick^2 (0 = laser-straight)
    public int maxTicks = 30;               // flight time; range ~ baseSpeed * maxTicks
    public float hipSpread = 0.06f;         // inaccuracy when not sneaking (0 = perfect)
    public float recoilMult = 1.0f;         // 0 = no recoil
    public float explosionPowerMult = 1.0f; // 0 = explosive rounds don't explode
    public boolean requireAmmo = true;      // false = infinite ammo
    public int maxDurability = 500;
    public int durabilityPerShot = 1;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static SniperConfig INSTANCE;

    public static SniperConfig get() {
        if (INSTANCE == null) load();
        return INSTANCE;
    }

    public static synchronized void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("sniper.json");
        SniperConfig cfg = new SniperConfig();
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                SniperConfig read = GSON.fromJson(r, SniperConfig.class);
                if (read != null) cfg = read;
            } catch (Exception e) {
                System.err.println("[sniper] Bad config, using defaults: " + e);
            }
        }
        cfg.sanitize();
        INSTANCE = cfg;
        try (Writer w = Files.newBufferedWriter(file)) { // rewrite so new options appear
            GSON.toJson(cfg, w);
        } catch (IOException e) {
            System.err.println("[sniper] Could not write config: " + e);
        }
    }

    private void sanitize() {
        bodyDamage = Math.max(0, bodyDamage);
        headDamage = Math.max(0, headDamage);
        cooldownTicks = Math.max(0, cooldownTicks);
        baseSpeed = Math.max(0.5, baseSpeed);
        gravity = Math.max(0, gravity);
        maxTicks = Math.max(1, Math.min(200, maxTicks));
        hipSpread = Math.max(0, hipSpread);
        recoilMult = Math.max(0, recoilMult);
        explosionPowerMult = Math.max(0, explosionPowerMult);
        maxDurability = Math.max(1, maxDurability);
        durabilityPerShot = Math.max(0, durabilityPerShot);
    }
}

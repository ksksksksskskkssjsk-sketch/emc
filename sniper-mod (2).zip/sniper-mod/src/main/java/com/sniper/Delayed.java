package com.sniper;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-side scheduler used for bolt-cycle / echo sounds. */
public final class Delayed {
    private static final class Task {
        int ticks;
        final Runnable run;
        Task(int ticks, Runnable run) { this.ticks = ticks; this.run = run; }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Delayed() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Task> it = TASKS.iterator();
            List<Runnable> ready = new ArrayList<>();
            while (it.hasNext()) {
                Task t = it.next();
                if (--t.ticks <= 0) {
                    ready.add(t.run);
                    it.remove();
                }
            }
            ready.forEach(Runnable::run);
        });
    }

    public static void after(int ticks, Runnable run) {
        TASKS.add(new Task(ticks, run));
    }
}

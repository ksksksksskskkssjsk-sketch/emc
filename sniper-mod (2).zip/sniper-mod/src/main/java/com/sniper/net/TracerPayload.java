package com.sniper.net;

import com.sniper.SniperMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.List;

/** Server -> clients: bullet path as flat x,y,z doubles (muzzle first), ammo ordinal, and whether it hit something. */
public record TracerPayload(int ammo, boolean hit, List<Double> pts) implements CustomPayload {
    public static final CustomPayload.Id<TracerPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SniperMod.MOD_ID, "tracer"));
    public static final PacketCodec<RegistryByteBuf, TracerPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, TracerPayload::ammo,
            PacketCodecs.BOOLEAN, TracerPayload::hit,
            PacketCodecs.DOUBLE.collect(PacketCodecs.toList()), TracerPayload::pts,
            TracerPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

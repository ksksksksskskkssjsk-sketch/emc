package com.sniper.net;

import com.sniper.SniperMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client: kick the camera up (pitch) and sideways (yaw), in degrees. */
public record RecoilPayload(float pitch, float yaw) implements CustomPayload {
    public static final CustomPayload.Id<RecoilPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SniperMod.MOD_ID, "recoil"));
    public static final PacketCodec<RegistryByteBuf, RecoilPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.FLOAT, RecoilPayload::pitch,
            PacketCodecs.FLOAT, RecoilPayload::yaw,
            RecoilPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.sniper.item;

import net.minecraft.item.Item;

public class SniperAmmoItem extends Item {
    private final AmmoType type;

    public SniperAmmoItem(Settings settings, AmmoType type) {
        super(settings);
        this.type = type;
    }

    public AmmoType type() {
        return type;
    }
}

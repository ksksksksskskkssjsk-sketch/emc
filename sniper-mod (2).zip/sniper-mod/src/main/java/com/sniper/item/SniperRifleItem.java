package com.sniper.item;

import com.sniper.Delayed;
import com.sniper.SniperConfig;
import com.sniper.net.HitMarkerPayload;
import com.sniper.net.RecoilPayload;
import com.sniper.net.TracerPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public class SniperRifleItem extends Item {
    private static SniperConfig cfg() {
        return SniperConfig.get();
    }

    public SniperRifleItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        ItemStack ammo = findAmmo(player);

        if (ammo == null && !player.isCreative() && cfg().requireAmmo) {
            if (!world.isClient()) {
                world.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.PLAYERS, 1.0f, 1.5f);
            }
            return ActionResult.FAIL;
        }

        if (world instanceof ServerWorld serverWorld) {
            AmmoType type = ammo != null ? ((SniperAmmoItem) ammo.getItem()).type() : AmmoType.STANDARD;
            if (ammo != null && !player.isCreative() && cfg().requireAmmo) ammo.decrement(1);
            player.getItemCooldownManager().set(stack, cfg().cooldownTicks);
            fire(serverWorld, player, type);
            stack.damage(cfg().durabilityPerShot, player, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        }
        return ActionResult.SUCCESS;
    }

    private static void fire(ServerWorld world, PlayerEntity player, AmmoType type) {
        var rng = player.getRandom();
        boolean steady = player.isSneaking();

        Vec3d dir = player.getRotationVec(1.0f);
        if (!steady) {
            dir = dir.add((rng.nextDouble() - 0.5) * cfg().hipSpread,
                          (rng.nextDouble() - 0.5) * cfg().hipSpread,
                          (rng.nextDouble() - 0.5) * cfg().hipSpread).normalize();
        }

        Vec3d eye = player.getEyePos();
        Vec3d muzzle = eye.add(dir.multiply(1.2)).add(0, -0.15, 0);

        Vec3d pos = eye;
        Vec3d vel = dir.multiply(cfg().baseSpeed * type.speedMult);
        Set<Entity> hitSet = new HashSet<>();
        List<Double> pts = new ArrayList<>();
        addPoint(pts, muzzle);
        Vec3d impact = null;
        boolean anyHead = false, anyKill = false;
        boolean done = false;

        for (int tick = 0; tick < cfg().maxTicks && !done; tick++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bh = world.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            boolean blockStop = bh.getType() != HitResult.Type.MISS;
            Vec3d stop = blockStop ? bh.getPos() : next;

            Box box = new Box(pos, stop).expand(1.0);
            Predicate<Entity> filter = e -> !e.isSpectator() && e.canHit() && e != player && !hitSet.contains(e);
            double maxSq = pos.squaredDistanceTo(stop) + 1.0;

            while (true) {
                EntityHitResult eh = ProjectileUtil.raycast(player, pos, stop, box, filter, maxSq);
                if (eh == null) break;

                Entity target = eh.getEntity();
                Vec3d p = eh.getPos();
                boolean head = target instanceof LivingEntity living && p.y >= living.getEyeY() - 0.3;
                float dmg = (head ? cfg().headDamage : cfg().bodyDamage) * type.damageMult;
                target.damage(world, world.getDamageSources().playerAttack(player), dmg);
                if (type.fireSeconds > 0) target.setOnFireFor(type.fireSeconds);

                if (head) anyHead = true;
                if (target instanceof LivingEntity le && le.isDead()) anyKill = true;

                world.spawnParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 12, 0.15, 0.15, 0.15, 0.3);
                world.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, p.x, p.y, p.z, head ? 6 : 3, 0.2, 0.2, 0.2, 0.1);

                hitSet.add(target);
                impact = p;
                if (hitSet.size() >= type.pierce) {
                    done = true;
                    stop = p;
                    break;
                }
            }

            if (!done && blockStop) {
                impact = stop;
                done = true;
                BlockState st = world.getBlockState(bh.getBlockPos());
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, st),
                        stop.x, stop.y, stop.z, 14, 0.1, 0.1, 0.1, 0.15);
                world.playSound(null, stop.x, stop.y, stop.z, st.getSoundGroup().getBreakSound(),
                        SoundCategory.BLOCKS, 1.0f, 1.3f);
            }

            addPoint(pts, stop);
            pos = next;
            vel = vel.add(0, -cfg().gravity, 0); // bullet drop
        }

        float boomPower = type.explosionPower * cfg().explosionPowerMult;
        if (boomPower > 0 && impact != null) {
            world.createExplosion(null, impact.x, impact.y, impact.z, boomPower,
                    World.ExplosionSourceType.NONE); // damages entities, never breaks blocks
        }

        // --- Tracer, muzzle blast and impact sparks are rendered client-side (see ShotFx) so they show at any distance ---
        TracerPayload tracer = new TracerPayload(type.ordinal(), impact != null, pts);
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.squaredDistanceTo(muzzle) < 320.0 * 320.0) ServerPlayNetworking.send(p, tracer);
        }

        // --- Hit marker for the shooter ---
        if (player instanceof ServerPlayerEntity sp) {
            if (!hitSet.isEmpty()) {
                ServerPlayNetworking.send(sp, new HitMarkerPayload(anyKill ? 2 : anyHead ? 1 : 0));
            }
            float kick = (steady ? 2.0f : 4.5f) * type.recoilMult * cfg().recoilMult;
            float yawKick = (rng.nextFloat() - 0.5f) * (steady ? 0.6f : 1.4f);
            ServerPlayNetworking.send(sp, new RecoilPayload(kick, yawKick));
        }

        // --- Layered shot sound ---
        boolean boom = type == AmmoType.EXPLOSIVE;
        play(world, player, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 4.0f, boom ? 0.4f : 0.5f);      // crack
        play(world, player, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 2.5f, boom ? 0.5f : 0.7f); // body
        // Distant echo + bolt-action cycle + ready click
        Delayed.after(10, () -> play(world, player, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.5f, 0.4f));
        Delayed.after(12, () -> play(world, player, SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, 0.6f, 1.8f));  // bolt up
        Delayed.after(17, () -> play(world, player, SoundEvents.BLOCK_PISTON_CONTRACT, 0.5f, 1.8f));      // bolt back (eject)
        Delayed.after(24, () -> play(world, player, SoundEvents.BLOCK_PISTON_EXTEND, 0.5f, 1.9f));        // bolt forward
        Delayed.after(29, () -> play(world, player, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 0.6f, 1.8f));  // bolt down
        Delayed.after(cfg().cooldownTicks, () -> play(world, player, SoundEvents.BLOCK_LEVER_CLICK, 0.5f, 1.6f)); // ready
    }

    private static void play(ServerWorld world, PlayerEntity player, SoundEvent sound, float volume, float pitch) {
        if (player.isRemoved()) return;
        world.playSound(null, player.getX(), player.getY(), player.getZ(), sound, SoundCategory.PLAYERS, volume, pitch);
    }

    private static void addPoint(List<Double> pts, Vec3d v) {
        pts.add(v.x);
        pts.add(v.y);
        pts.add(v.z);
    }

    /** Ammo in the offhand wins; otherwise the first ammo stack in the inventory. */
    private static ItemStack findAmmo(PlayerEntity player) {
        ItemStack off = player.getOffHandStack();
        if (off.getItem() instanceof SniperAmmoItem) return off;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack s = player.getInventory().getStack(i);
            if (s.getItem() instanceof SniperAmmoItem) return s;
        }
        return null;
    }
}

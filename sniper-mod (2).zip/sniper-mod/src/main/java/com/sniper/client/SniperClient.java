package com.sniper.client;

import com.sniper.item.ModItems;
import com.sniper.SniperConfig;
import com.sniper.item.AmmoType;
import com.sniper.item.SniperAmmoItem;
import net.fabricmc.fabric.api.item.v1.ItemTooltipCallback;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import com.sniper.net.HitMarkerPayload;
import com.sniper.net.RecoilPayload;
import com.sniper.net.TracerPayload;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.math.MathHelper;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class SniperClient implements ClientModInitializer {
    /** FOV multipliers: 2x, 4x, 8x, 16x. Scroll while scoped to change. */
    private static final float[] LEVELS = {0.5f, 0.25f, 0.125f, 0.0625f};
    private static int level = 1;

    private static float zoom = 1.0f;
    private static boolean scoped = false;

    // Hit marker state
    private static long markerStart = 0;
    private static int markerKind = -1;

    // Breath / sway state
    private static long tickCount = 0;
    private static float breath = 1.0f;       // 1 = full lungs
    private static int exhaustTicks = 0;      // gasping after running out of breath
    private static boolean breathHeld = false;
    private static float swayMult = 1.0f;
    private static float appliedYaw = 0, appliedPitch = 0;

    // Recoil easing state (degrees)
    private static float pendingUp = 0, pendingDown = 0, pendingYaw = 0;

    public static float zoomFactor() {
        return zoom;
    }

    /** Called from the Mouse mixin; returns true if the scroll was used for zoom. */
    public static boolean handleScroll(double vertical) {
        if (!scoped || vertical == 0) return false;
        level = Math.max(0, Math.min(LEVELS.length - 1, level + (vertical > 0 ? 1 : -1)));
        return true;
    }

    @Override
    public void onInitializeClient() {
        // Tooltips
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipType, lines) -> {
            SniperConfig c = SniperConfig.get();
            if (stack.isOf(ModItems.SNIPER_RIFLE)) {
                lines.add(Text.literal("Damage: " + (int) c.bodyDamage + " (" + (int) c.headDamage + " headshot)")
                        .formatted(Formatting.GOLD));
                lines.add(Text.literal(String.format("Cooldown: %.1fs", c.cooldownTicks / 20.0))
                        .formatted(Formatting.GRAY));
                lines.add(Text.literal("Sneak: scope + steady aim  |  Scroll: zoom").formatted(Formatting.GRAY));
                lines.add(Text.literal("Ammo in offhand is used first").formatted(Formatting.DARK_GRAY));
                lines.add(Text.literal("Bullets drop with distance - aim high").formatted(Formatting.DARK_GRAY));
            } else if (stack.getItem() instanceof SniperAmmoItem ammo) {
                String desc = switch (ammo.type()) {
                    case STANDARD -> "Balanced round";
                    case PIERCING -> "Hits up to 3 targets | faster, 85% damage";
                    case EXPLOSIVE -> "Explodes on impact, no block damage | slower, 50% damage";
                    case INCENDIARY -> "Sets targets on fire | 80% damage";
                };
                lines.add(Text.literal(desc).formatted(Formatting.GRAY));
            }
        });

        // Tracer + muzzle blast + impact sparks (see ShotFx)
        ClientPlayNetworking.registerGlobalReceiver(TracerPayload.ID, (payload, context) -> {
            ClientWorld w = context.client().world;
            if (w == null) return;
            AmmoType[] types = AmmoType.values();
            ShotFx.play(w, types[MathHelper.clamp(payload.ammo(), 0, types.length - 1)], payload.hit(), payload.pts());
        });

        // Hit marker + shooter-only hit sound
        ClientPlayNetworking.registerGlobalReceiver(HitMarkerPayload.ID, (payload, context) -> {
            markerKind = payload.kind();
            markerStart = System.currentTimeMillis();
            var pl = context.player();
            if (pl == null) return;
            switch (markerKind) {
                case 2 -> pl.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.5f);
                case 1 -> pl.playSound(SoundEvents.ENTITY_ARROW_HIT_PLAYER, 1.0f, 0.7f);
                default -> pl.playSound(SoundEvents.ENTITY_ARROW_HIT_PLAYER, 1.0f, 1.3f);
            }
        });

        // Recoil from server: scale down while zoomed so a 16x scope isn't thrown off the target.
        ClientPlayNetworking.registerGlobalReceiver(RecoilPayload.ID, (payload, context) -> {
            float f = Math.max(0.2f, zoom);
            pendingUp += payload.pitch() * f;
            pendingDown += payload.pitch() * f * 0.4f;   // partial recovery back down
            pendingYaw += payload.yaw() * f;
        });

        // Hold SNEAK with the sniper in main hand to scope in.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            scoped = client.player != null
                    && client.currentScreen == null
                    && client.player.isSneaking()
                    && client.player.getMainHandStack().isOf(ModItems.SNIPER_RIFLE);
            float target = scoped ? LEVELS[level] : 1.0f;
            zoom += (target - zoom) * 0.35f;
            if (Math.abs(zoom - target) < 0.003f) zoom = target;

            if (client.player != null) {
                if (pendingUp > 0.01f) {
                    float st = pendingUp * 0.5f;
                    pendingUp -= st;
                    client.player.setPitch(MathHelper.clamp(client.player.getPitch() - st, -90f, 90f));
                } else if (pendingDown > 0.01f) {
                    float st = pendingDown * 0.12f;
                    pendingDown -= st;
                    client.player.setPitch(MathHelper.clamp(client.player.getPitch() + st, -90f, 90f));
                }
                if (Math.abs(pendingYaw) > 0.01f) {
                    float st = pendingYaw * 0.5f;
                    pendingYaw -= st;
                    client.player.setYaw(client.player.getYaw() + st);
                }

                // ---- Breathing: hold SPRINT (Ctrl) while scoped to steady the crosshair (~4 s), then you gasp.
                tickCount++;
                boolean wantHold = scoped && client.options.sprintKey.isPressed();
                boolean holding = false;
                if (exhaustTicks > 0) {
                    exhaustTicks--;
                } else if (wantHold && breath > 0f) {
                    holding = true;
                    breath -= 0.0125f;
                    if (breath <= 0f) {
                        breath = 0f;
                        holding = false;
                        exhaustTicks = 60;
                        client.player.playSound(SoundEvents.ENTITY_PLAYER_BREATH, 1.0f, 0.9f);
                    }
                }
                if (!holding) breath = Math.min(1.0f, breath + (exhaustTicks > 0 ? 0.004f : 0.01f));
                breathHeld = holding;

                // ---- Sway: two slow sines per axis + a heartbeat pulse; deltas applied so the view never drifts away.
                float swayTarget = !scoped ? 0f : exhaustTicks > 0 ? 2.2f : holding ? 0.1f : 1.0f;
                swayMult += (swayTarget - swayMult) * 0.12f;
                if (scoped) {
                    double t = tickCount;
                    float amp = 0.18f * swayMult;
                    float sy = (float) ((Math.sin(t * 0.050 + 2.0) * 0.6 + Math.sin(t * 0.117) * 0.4) * amp);
                    float sp = (float) ((Math.sin(t * 0.070) * 0.6 + Math.sin(t * 0.131 + 1.3) * 0.4) * amp
                            + Math.pow(Math.max(0.0, Math.sin(t * 0.31)), 12) * 0.07 * swayMult);
                    client.player.setYaw(client.player.getYaw() + (sy - appliedYaw));
                    client.player.setPitch(MathHelper.clamp(client.player.getPitch() + (sp - appliedPitch), -90f, 90f));
                    appliedYaw = sy;
                    appliedPitch = sp;
                } else {
                    appliedYaw = 0;
                    appliedPitch = 0;
                }
            }
        });

        HudRenderCallback.EVENT.register(SniperClient::renderScope);
        HudRenderCallback.EVENT.register(SniperClient::renderHitMarker);
    }

    private static void renderScope(DrawContext ctx, RenderTickCounter tickCounter) {
        if (zoom > 0.7f) return;
        float fade = MathHelper.clamp((0.7f - zoom) / 0.3f, 0f, 1f);   // fades in while the zoom ramps up
        int aa = (int) (fade * 255);
        int black = aa << 24;
        int ringCol = (aa << 24) | 0x1A1A1A;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int cx = w / 2, cy = h / 2;

        int r = (int) (h * 0.46f);   // outer lens radius
        int t = 3;                    // scope ring thickness
        int ri = r - t;

        // Radial vignette: three nested dark bands near the lens edge (cumulative alpha -> smooth falloff)
        float sc = ri / 230.0f;
        int[] depth = {(int) (40 * sc), (int) (26 * sc), (int) (13 * sc)};
        int vig = ((int) (fade * 0x3A) << 24);

        for (int y = 0; y < h; y += 2) {
            int rowH = Math.min(2, h - y);
            int dy = Math.abs(y + rowH / 2 - cy);
            if (dy >= r) {
                ctx.fill(0, y, w, y + rowH, black);
                continue;
            }
            int dxo = (int) Math.sqrt((double) r * r - (double) dy * dy);
            ctx.fill(0, y, cx - dxo, y + rowH, black);
            ctx.fill(cx + dxo, y, w, y + rowH, black);
            if (dy >= ri) {
                ctx.fill(cx - dxo, y, cx + dxo, y + rowH, ringCol);
                continue;
            }
            int dxi = (int) Math.sqrt((double) ri * ri - (double) dy * dy);
            ctx.fill(cx - dxo, y, cx - dxi, y + rowH, ringCol);
            ctx.fill(cx + dxi, y, cx + dxo, y + rowH, ringCol);
            for (int d : depth) {
                int rk = ri - d;
                if (dy >= rk) {
                    ctx.fill(cx - dxi, y, cx + dxi, y + rowH, vig);
                } else {
                    int dxk = (int) Math.sqrt((double) rk * rk - (double) dy * dy);
                    ctx.fill(cx - dxi, y, cx - dxk, y + rowH, vig);
                    ctx.fill(cx + dxk, y, cx + dxi, y + rowH, vig);
                }
            }
        }

        // Mil-dot crosshair
        int gap = 6;
        ctx.fill(cx - ri, cy, cx - gap, cy + 1, black);
        ctx.fill(cx + gap, cy, cx + ri, cy + 1, black);
        ctx.fill(cx, cy - ri, cx + 1, cy - gap, black);
        ctx.fill(cx, cy + gap, cx + 1, cy + ri, black);
        ctx.fill(cx - ri, cy - 1, cx - ri + 40, cy + 2, black);
        ctx.fill(cx + ri - 40, cy - 1, cx + ri, cy + 2, black);
        ctx.fill(cx - 1, cy - ri, cx + 2, cy - ri + 40, black);
        ctx.fill(cx - 1, cy + ri - 40, cx + 2, cy + ri, black);
        for (int i = 1; i <= 5; i++) {
            int d = gap + i * 14;
            ctx.fill(cx - d, cy + 2, cx - d + 1, cy + 5, black);
            ctx.fill(cx + d, cy + 2, cx + d + 1, cy + 5, black);
            ctx.fill(cx - 2, cy + d, cx - 5, cy + d + 1, black);
            ctx.fill(cx + 2, cy + d, cx + 5, cy + d + 1, black);
        }
        ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, (aa << 24) | 0xFF2020);

        // Lens glint: soft crescent along the upper-left rim + a twinkling 4-point star
        double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 700.0);
        for (int i = 0; i < 16; i++) {
            double ang = Math.toRadians(205 + i * 3.2);
            int gx = cx + (int) (Math.cos(ang) * ri * 0.90);
            int gy = cy + (int) (Math.sin(ang) * ri * 0.90);
            float edge = 1.0f - Math.abs(i - 7.5f) / 8.0f;            // brightest in the middle of the arc
            int ga = (int) (fade * edge * 120);
            ctx.fill(gx, gy, gx + 2, gy + 2, (ga << 24) | 0xFFFFFF);
        }
        int sx = cx - (int) (ri * 0.60), sy = cy - (int) (ri * 0.52);
        int sa = (int) (fade * (70 + 120 * pulse));
        int sCol = (sa << 24) | 0xFFFFFF;
        ctx.fill(sx - 7, sy, sx + 8, sy + 1, sCol);
        ctx.fill(sx, sy - 7, sx + 1, sy + 8, sCol);
        ctx.fill(sx - 1, sy - 1, sx + 2, sy + 2, (Math.min(255, sa + 50) << 24) | 0xFFFFFF);

        // Breath meter
        if (breath < 0.999f || breathHeld || exhaustTicks > 0) {
            int bw = 70, bx = cx - bw / 2, by = cy + (int) (ri * 0.72);
            ctx.fill(bx - 1, by - 1, bx + bw + 1, by + 4, ((int) (fade * 140) << 24));
            int fillW = (int) (bw * breath);
            int bc = exhaustTicks > 0 ? 0xE03030 : breathHeld ? 0x9FE8FF : 0xE8E8E8;
            ctx.fill(bx, by, bx + fillW, by + 3, (aa << 24) | bc);
        }

        // Zoom label
        MinecraftClient mc = MinecraftClient.getInstance();
        String label = (int) Math.round(1.0f / LEVELS[level]) + "x";
        ctx.drawText(mc.textRenderer, label, cx + ri - 28, cy + ri - 18, (aa << 24) | 0xFFFFFF, true);
    }

    /** White X = hit, gold = headshot, big red = kill. Fades out over 350 ms. */
    private static void renderHitMarker(DrawContext ctx, RenderTickCounter tickCounter) {
        if (markerKind < 0) return;
        long age = System.currentTimeMillis() - markerStart;
        if (age > 350) return;
        int alpha = (int) ((1.0f - age / 350.0f) * 255);
        int rgb = markerKind == 2 ? 0xFF2020 : markerKind == 1 ? 0xFFD020 : 0xFFFFFF;
        int col = (alpha << 24) | rgb;
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int in = 4, out = markerKind == 2 ? 13 : 9;
        for (int i = in; i <= out; i++) {
            ctx.fill(cx + i, cy + i, cx + i + 2, cy + i + 2, col);
            ctx.fill(cx - i - 2, cy + i, cx - i, cy + i + 2, col);
            ctx.fill(cx + i, cy - i - 2, cx + i + 2, cy - i, col);
            ctx.fill(cx - i - 2, cy - i - 2, cx - i, cy - i, col);
        }
    }
}

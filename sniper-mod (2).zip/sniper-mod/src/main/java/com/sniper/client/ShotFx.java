package com.sniper.client;

import com.sniper.item.AmmoType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** All client-side shot visuals. Uses "important" particles so they render at any distance. */
public final class ShotFx {
    private static final Vec3d ZERO = Vec3d.ZERO;

    private ShotFx() {}

    public static void play(ClientWorld w, AmmoType type, boolean hit, List<Double> d) {
        if (d.size() < 6) return;
        List<Vec3d> pts = new ArrayList<>();
        for (int i = 0; i + 2 < d.size(); i += 3) pts.add(new Vec3d(d.get(i), d.get(i + 1), d.get(i + 2)));

        Vec3d dir = pts.get(1).subtract(pts.get(0)).normalize();
        muzzle(w, type, pts.get(0), dir);
        trail(w, type, pts);
        if (hit) impact(w, type, pts.get(pts.size() - 1));
    }

    // ---------------------------------------------------------------- muzzle blast
    private static void muzzle(ClientWorld w, AmmoType type, Vec3d m, Vec3d dir) {
        Vec3d[] b = basis(dir);
        // expanding shock ring
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI * 2 / 16;
            Vec3d out = b[0].multiply(Math.cos(a)).add(b[1].multiply(Math.sin(a)));
            fx(w, ParticleTypes.CLOUD, m, out.multiply(0.22).add(dir.multiply(0.06)));
        }
        // directional flame cone + sparks
        for (int i = 0; i < 10; i++) fx(w, ParticleTypes.FLAME, m, dir.multiply(0.4).add(rand(w, 0.07)));
        for (int i = 0; i < 6; i++) fx(w, ParticleTypes.END_ROD, m, dir.multiply(0.55).add(rand(w, 0.1)));
        // drifting powder smoke
        for (int i = 0; i < 5; i++) fx(w, ParticleTypes.LARGE_SMOKE, m, dir.multiply(0.1).add(rand(w, 0.03)));
        // coloured flash matching the loaded round
        burst(w, tint(type, 1.3f), m, 8, 0.18);
        fx(w, ParticleTypes.EXPLOSION, m, new Vec3d(1.2, 0, 0)); // small flash puff
    }

    // ---------------------------------------------------------------- tracer
    private static void trail(ClientWorld w, AmmoType type, List<Vec3d> pts) {
        ParticleEffect core = tint(type, 1.0f);
        ParticleEffect helix = tint(type, 0.55f);
        int n = 0;
        for (int i = 1; i < pts.size(); i++) {
            Vec3d a = pts.get(i - 1), bb = pts.get(i);
            Vec3d seg = bb.subtract(a);
            double len = seg.length();
            if (len < 0.01) continue;
            Vec3d dir = seg.multiply(1.0 / len);
            Vec3d[] ba = basis(dir);
            int steps = (int) Math.max(1, len / 0.6);
            for (int k = 0; k < steps; k++) {
                Vec3d p = a.lerp(bb, (double) k / steps);
                n++;
                fx(w, type.trail, p, ZERO);                       // glowing core line
                fx(w, core, p.add(rand(w, 0.02)), ZERO);           // coloured fading haze
                double ang = n * 0.75;                             // double helix around the path
                Vec3d off = ba[0].multiply(Math.cos(ang)).add(ba[1].multiply(Math.sin(ang))).multiply(0.14);
                fx(w, helix, p.add(off), ZERO);
                fx(w, helix, p.subtract(off), ZERO);
            }
        }
    }

    // ---------------------------------------------------------------- impact
    private static void impact(ClientWorld w, AmmoType type, Vec3d p) {
        burst(w, tint(type, 1.2f), p, 8, 0.2);
        switch (type) {
            case STANDARD -> {
                burst(w, ParticleTypes.CRIT, p, 10, 0.25);
                burst(w, ParticleTypes.CLOUD, p, 4, 0.05);
            }
            case PIERCING -> burst(w, ParticleTypes.ELECTRIC_SPARK, p, 22, 0.4);
            case EXPLOSIVE -> {
                burst(w, ParticleTypes.LARGE_SMOKE, p, 8, 0.12);
                burst(w, ParticleTypes.FLAME, p, 12, 0.25);
                fx(w, ParticleTypes.EXPLOSION, p, new Vec3d(0.5, 0, 0));
            }
            case INCENDIARY -> {
                burst(w, ParticleTypes.FLAME, p, 16, 0.18);
                burst(w, ParticleTypes.LAVA, p, 6, 0.05);
                burst(w, ParticleTypes.SMOKE, p, 6, 0.05);
            }
        }
    }

    // ---------------------------------------------------------------- helpers
    private static DustColorTransitionParticleEffect tint(AmmoType t, float scale) {
        return new DustColorTransitionParticleEffect(t.colorFrom, t.colorTo, scale);
    }

    private static void burst(ClientWorld w, ParticleEffect e, Vec3d p, int count, double speed) {
        for (int i = 0; i < count; i++) fx(w, e, p, rand(w, speed));
    }

    private static void fx(ClientWorld w, ParticleEffect e, Vec3d p, Vec3d v) {
        w.addImportantParticleClient(e, p.x, p.y, p.z, v.x, v.y, v.z);
    }

    private static Vec3d rand(ClientWorld w, double s) {
        return new Vec3d(w.random.nextGaussian() * s, w.random.nextGaussian() * s, w.random.nextGaussian() * s);
    }

    /** Two unit vectors perpendicular to d (and to each other). */
    private static Vec3d[] basis(Vec3d d) {
        Vec3d ref = Math.abs(d.y) < 0.99 ? new Vec3d(0, 1, 0) : new Vec3d(1, 0, 0);
        Vec3d u = d.crossProduct(ref).normalize();
        Vec3d v = d.crossProduct(u).normalize();
        return new Vec3d[]{u, v};
    }
}

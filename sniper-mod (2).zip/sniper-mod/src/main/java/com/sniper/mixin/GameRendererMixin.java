package com.sniper.mixin;

import com.sniper.client.SniperClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void sniper$zoom(CallbackInfoReturnable<Float> cir) {
        float z = SniperClient.zoomFactor();
        if (z < 1.0f) cir.setReturnValue(cir.getReturnValue() * z);
    }
}

# Sniper (Fabric 1.21.11)
Build: create a template at https://fabricmc.net/develop (1.21.11), copy `src/` over it (match versions in gradle.properties), then `./gradlew build` -> build/libs/sniper-1.0.0.jar

Craft: Sniper Rifle (spyglass, 2 iron, lever, planks); Sniper Rounds (iron + gunpowder = 8).
Special rounds (4 Sniper Rounds + 1 item -> 4): Piercing (diamond), Explosive (TNT), Incendiary (blaze powder).

Right-click = shoot. Ammo held in OFFHAND is used first, else first ammo in inventory.
Sneak = scope (round lens, mil-dot reticle, mouse wheel = 2x/4x/8x/16x) and steady aim.
Hip-fire (not sneaking) = spread + heavy recoil. Bullets drop over distance: aim above far targets.
Rounds: Standard 20 dmg/40 headshot; Piercing 85%, hits up to 3 targets, faster; Explosive 50% + blast (no block damage), slower; Incendiary 80% + sets target on fire.

Effects: muzzle flash, layered shot sound + echo, bolt-action cycle sounds and a ready click, long-range particle tracer
(per-ammo colour), block-fragment impacts, hit markers (white hit / gold headshot / red kill) with shooter-only hit sounds.

Config: config/sniper.json is created on first launch (damage, cooldown, bullet speed/drop, range, hip spread, recoil,
explosion strength, infinite ammo, durability). Restart after editing.
Durability: rifle can be repaired with iron ingots in an anvil and takes Unbreaking / Mending from the enchanting table.
Tooltips: hover the rifle / rounds for stats and controls.

Animation: the rifle animates through the 2s cooldown (item-model frames driven by `minecraft:cooldown`, synced to the sounds):
muzzle-kick, settle, bolt up, bolt back, bolt forward, bolt down. Edit assets/sniper/items/sniper_rifle.json to retime.

Particles (client-side, visible at any range): shock-ring + flame-cone muzzle blast, glowing core tracer with a
colour-fading double helix per ammo type, per-ammo impact bursts (sparks / fire+lava / smoke+flash).

Look: the rifle is now a 3D model (~60 cubes: olive chassis, vented handguard, muzzle brake, folded bipod, magazine,
scope with lenses/turrets/rings, bolt + handle) on a 64x64 palette texture. The bolt cycles in 3D during the cooldown.
Held-pose numbers are in each model's "display" block (assets/sniper/models/item/sniper_rifle*.json) - tweak rotation/translation if the angle feels off.

Scope polish: radial lens vignette, fade-in, lens glint (rim crescent + twinkling star), breath sway with heartbeat pulse.
Hold SPRINT (Ctrl) while scoped to hold your breath (~4 s, crosshair nearly still); run out and you gasp (extra sway) before it recovers.

Ammo: each round is now a 3D cartridge (rim, groove, bottle-neck brass casing, ogive bullet) with a per-type bullet
(copper / purple-banded tungsten / red-tipped explosive / orange incendiary) on a shared 64x64 palette texture.
Rifle texture v2: camo-splotched polymer, parkerized brushed metal with scratches, coated lenses.

GitHub build: push this folder to a repo -> Actions tab -> "build" -> download the `sniper-mod` artifact (the jar).
